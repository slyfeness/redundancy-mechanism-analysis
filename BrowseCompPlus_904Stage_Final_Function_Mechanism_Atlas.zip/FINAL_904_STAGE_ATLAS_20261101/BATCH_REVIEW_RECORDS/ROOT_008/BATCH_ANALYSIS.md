# ROOT_008 批次归纳

10 Stage / 10题 / 10原轨迹 / 40续跑；组别{'A': 5, 'B': 5}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "当前具体缺口的一次取证及失败反馈，可能仍给局部线索，但成功候选采用并未在该U完成。",
  "members": [
    "980__rep2__S005__FIRST_SENTENCE",
    "1023__rep3__S002__FIRST_SENTENCE",
    "1046__rep1__S002__FIRST_SENTENCE",
    "299__rep2__S003__FIRST_SENTENCE"
  ],
  "distinction": "980泛争端没片名，1023广告没结果且协会仅计划，1046改名宽搜没目标，299实际又回正确建筑但原Z未采用。无新被接受事实不等失败反馈没有行动价值，G有时直接替代下一方向。"
}
```

```json
{
  "description": "把已回材料对应题目并采用人物/论文，解释框架或条件状态，随后据此补具体证据。",
  "members": [
    "1095__rep1__S002__FIRST_SENTENCE",
    "1096__rep1__S002__FIRST_SENTENCE"
  ],
  "distinction": "1095全十条件接受但随后仍核特定纪录片，原补证前后两次完整盘点；1096把认知框架解释为SFL替代并确定论文/词表，再查参会/排名。无Call的认知工作不能漏掉。"
}
```

```json
{
  "description": "从无有效身份到通过特定返回和具体查询获得人物/书目材料，或明确首次个案不匹配。",
  "members": [
    "353__rep2__S001__FIRST_SENTENCE",
    "377__rep3__S002__FIRST_SENTENCE",
    "773__rep3__S001__FIRST_SENTENCE"
  ],
  "distinction": "353扩到gossip才取得书，采用在Z；377八Call里关键是AHIS→家族真实Query→Beko采用；773首Return只有错误个案，U是明确不符反馈而非成功识别，不与前两成功产物混同。"
}
```

```json
{
  "description": "已有公司后，两个真实缺值反复变成并行取证任务，直到上下文止，无最终提交。",
  "members": [
    "1138__rep3__S002__TERMINAL_DROP_NO_ANCHOR"
  ],
  "distinction": "末Stage无G，P已确定公司；16Call都查合同期限/应收款而非发现公司。功能可重建同时重复实例减少，不能用REBUILT抹掉实际少查。"
}
```


## comparisons

```json
{
  "id": "ROOT008_C1",
  "cases": [
    "1095__rep1__S002__FIRST_SENTENCE",
    "1096__rep1__S002__FIRST_SENTENCE",
    "1046__rep1__S002__FIRST_SENTENCE"
  ],
  "finding": "A成本下降的落点不同。1095四支把两次完整盘点合成补证后一次，搜索/Actor都不变而少生成；1096候选判断重建，费用主要少会议失败/末确认；1046更早有效入口及实体查询可少宽搜，但有正确名C伴定罪年份错误。",
  "counter": "不能用U字数当净省，或因功能重建就排除真实压缩；同C的证据质量仍需单查。"
}
```

```json
{
  "id": "ROOT008_C2",
  "cases": [
    "980__rep2__S005__FIRST_SENTENCE",
    "299__rep2__S003__FIRST_SENTENCE",
    "1046__rep1__S002__FIRST_SENTENCE",
    "377__rep3__S002__FIRST_SENTENCE"
  ],
  "finding": "失败尝试恢复与否不是结果区分变量；真实材料是否转成具体对象才解释后续路线。980具名兄弟关系、299业主建筑师、1046Benko、377Rev家族Query都可追踪，没出现该转换的分支各有不同未解/错误对象。",
  "counter": "1046新3没取得目标材料，不是忽略已见；377三N确有同份Rev材料而未用；299新4早P有线索但新目标晚到，不能把全宽查都算新Return被忽略。"
}
```

```json
{
  "id": "ROOT008_C3",
  "cases": [
    "1023__rep3__S002__FIRST_SENTENCE",
    "1138__rep3__S002__TERMINAL_DROP_NO_ANCHOR",
    "773__rep3__S001__FIRST_SENTENCE"
  ],
  "finding": "未闭缺口有本质差别：1023帽针身份有独立协会支持但广告未证；1138公司特异首事件已证但两值未给；773连题目同人身份未确认，白色只是其它个案属性。三者都可能有限提交或持续取证，却不能统一为辅助细节不用核。",
  "counter": "773三W不等正常完成，1138三C不等两值补齐；1023新1N机器资料也弱于其它支，停止差异非唯一共变量。"
}
```

```json
{
  "id": "ROOT008_C4",
  "cases": [
    "353__rep2__S001__FIRST_SENTENCE",
    "377__rep3__S002__FIRST_SENTENCE",
    "773__rep3__S001__FIRST_SENTENCE"
  ],
  "finding": "根部切点应单列：353/773空P近重新起跑，377已有一轮真实材料；353G还在书名内部感叹号截断，先给部分题名与已找到框架，另外两G无实体。不能用三个B三变化当相同纯干预。",
  "counter": "353新2真实搜索修复早期假书C，新3真搜N，两W零Call；起初错误不充分预测最终状态。"
}
```

```json
{
  "id": "ROOT008_C5",
  "cases": [
    "299__rep2__S003__FIRST_SENTENCE",
    "1046__rep1__S002__FIRST_SENTENCE",
    "980__rep2__S005__FIRST_SENTENCE"
  ],
  "finding": "错误中间解释既可被真实核查修复，也可继续派发错误任务或直接排除：299错1921有支带Query而修复，另一支直接排；1046正确人名Query后仍把行为年2009绑定定罪并再查；980错误producer措辞仍能实际具名查出片。",
  "counter": "不能以出现一次错解释判必败，也不能以实际查正确人名认全部关系已纠正。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT008_T1",
  "description": "具体返回的实体/关系实际进入下一Query，使后续从宽假设转为可验证对象；取得、采用、行动四层不能混同。",
  "links": [
    {
      "case_id": "980__rep2__S005__FIRST_SENTENCE",
      "local_id": "RETURNED_FEUD_RELATION_USED_AS_MOVIE_QUERY_KEY"
    },
    {
      "case_id": "1046__rep1__S002__FIRST_SENTENCE",
      "local_id": "COMPANY_RELATION_MATERIAL_BECOMES_ENTITY_VERIFICATION_QUERY"
    },
    {
      "case_id": "353__rep2__S001__FIRST_SENTENCE",
      "local_id": "GOSSIP_ENTRY_RETURNS_BOOK_THEN_UPDATES_AUTHOR_QUERY"
    },
    {
      "case_id": "377__rep3__S002__FIRST_SENTENCE",
      "local_id": "RETURNED_EDUCATOR_FOUNDER_BECOMES_REAL_FAMILY_QUERY"
    },
    {
      "case_id": "299__rep2__S003__FIRST_SENTENCE",
      "local_id": "RETURNED_BUILDING_PERSON_RELATION_BECOMES_TARGETED_VERIFICATION"
    }
  ],
  "relation": "P2_R1显式新增，保留三种反侧：材料根本未回、已回未用、已用但其它解释仍错。不同Stage同题不另增问题数，结果支持非纯删除因果。",
  "counterexamples": [
    "1046新1已经接受正确公司直接C却无再具名核验，不等没采用。",
    "299新3实际核验得C仍把2022勾在区间内，定向行动不是全部质量充分条件。",
    "353G异常/部分正确题名使成功恢复不能计严格可省。"
  ],
  "unresolved": "相似Query不同召回及教师方向共同变化，不用观察链证明唯一因果。",
  "deterministic_counts": {
    "observed_stage_count": 5,
    "different_questions": 5,
    "original_runs": 5,
    "observed_rollouts": 10,
    "not_observed_rollouts": 10,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 10,
    "not_observed_local_chain_occurrences": 10,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 20,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep1__S002__FIRST_SENTENCE",
      "299__rep2__S003__FIRST_SENTENCE",
      "353__rep2__S001__FIRST_SENTENCE",
      "377__rep3__S002__FIRST_SENTENCE",
      "980__rep2__S005__FIRST_SENTENCE"
    ],
    "question_ids": [
      "299",
      "353",
      "377",
      "980",
      "1046"
    ]
  }
}
```

```json
{
  "id": "ROOT008_T2",
  "description": "完整条件比较从补证前后两次改为补证后一次，保留真实相同局部证据与后续判断，减少的是展开实例/篇幅。",
  "links": [
    {
      "case_id": "1095__rep1__S002__FIRST_SENTENCE",
      "local_id": "ONE_POST_EVIDENCE_FULL_COMPARISON_REPLACES_PRE_AND_POST_REVIEWS"
    }
  ],
  "relation": "具体认知重组候选，当前一题四支，不因四次都支持冒充跨题。和上一批353比较后移但更多Call不同，不能粗合所有总结省略。",
  "counterexamples": [
    "G提前给应核CNBC条件，未检验无引导是否能自主选缺口。",
    "后段仍列十条件且Final再解释，不能说所有总结都消失。",
    "学校/讲师支持共享不全，姓名/片名不代完整质量。"
  ],
  "unresolved": "需要其它题有相同前后完整实例证据才决定推广，不先冻结模式。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 4,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1095__rep1__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1095"
    ]
  }
}
```

```json
{
  "id": "ROOT008_T3",
  "description": "候选与词表已采用、身份认证已补后，仍真实查已知关键词确认，未改答案但增加一次交互。",
  "links": [
    {
      "case_id": "1096__rep1__S002__FIRST_SENTENCE",
      "local_id": "ALREADY_EXTRACTED_KEYWORD_RECONFIRMED_AFTER_AUTHENTICATION"
    }
  ],
  "relation": "P2_R2支持，真实会议未返回前的检索不属于此已知再确认。与ROOT007建筑/作者关系对照可扩不同问题但不改定义。",
  "counterexamples": [
    "新2同认证后直接C，无末查；新4之前会议真实未解不能把全部六Call算重核。",
    "新1先理论疑点广搜有真实全文不足因素，不归此类。"
  ],
  "unresolved": "确认的潜在价值未做独立随机测试，只记未改变候选及实际费用。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 3,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 3,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1096__rep1__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1096"
    ]
  }
}
```

```json
{
  "id": "ROOT008_T4",
  "description": "已采用核心主体后真正剩余缺口继续派发或不再阻止提交，保留继续与停止的不同local含义及支持质量。",
  "links": [
    {
      "case_id": "1023__rep3__S002__FIRST_SENTENCE",
      "local_id": "ADOPTED_ACCESSORY_ADVERTISEMENT_GAP_CONTINUES_REAL_SEARCH"
    },
    {
      "case_id": "1138__rep3__S002__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "KNOWN_COMPANY_UNRESOLVED_VALUES_STOP_BLOCKING_SUBMISSION"
    }
  ],
  "relation": "P2_R3本批两个执行形式，前者正支继续N、后者正支有限提交C，不能合总OBSERVED当同向改进。末端无G和首句有G分开。",
  "counterexamples": [
    "1023三C仍缺广告/Ruby；1138三C仍缺期限/135%，少工具不等完整证据不变。",
    "1138新2核心核查与缺口状态重建并同规模N；功能恢复不能解释停止本身。"
  ],
  "unresolved": "何时觉得足够的可见判断有据，隐藏阈值/信心无直接证据；不替研究者补机制终因。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 4,
    "not_observed_rollouts": 4,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 4,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1023__rep3__S002__FIRST_SENTENCE",
      "1138__rep3__S002__TERMINAL_DROP_NO_ANCHOR"
    ],
    "question_ids": [
      "1023",
      "1138"
    ]
  }
}
```

```json
{
  "id": "ROOT008_T5",
  "description": "直接证据缺失或截断被承认后，Final把局部暗示/题面数值升级为已证事实。",
  "links": [
    {
      "case_id": "1023__rep3__S002__FIRST_SENTENCE",
      "local_id": "TRUNCATED_GENERAL_SOURCE_UPGRADED_TO_SPECIFIC_ADVERTISEMENT_FACT"
    },
    {
      "case_id": "1138__rep3__S002__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "EXPLICITLY_MISSING_RECEIVABLE_VALUE_PROMOTED_TO_CONFIRMED_FINAL"
    }
  ],
  "relation": "两个不同子链的上位比较：截断1919句→具体电影广告；年报目录→135%已确认。先保存共同证据地位变化，不自动覆盖N002教师虚构来源定义。",
  "counterexamples": [
    "1023新2/3缺广告也答但未逐证同截断升级，保留不确定；1138新4勾选但具体数值确认不明。",
    "两题都可持续查到N而不发生正式Final升级，缺证本身不充分。"
  ],
  "unresolved": "应否合为同一细机制还需跨案例具体解释和反例，当前不批量生成新标签。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 3,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 3,
    "excluded_rollouts": 2,
    "observed_local_chain_occurrences": 3,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 3,
    "excluded_local_chain_occurrences": 2,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1023__rep3__S002__FIRST_SENTENCE",
      "1138__rep3__S002__TERMINAL_DROP_NO_ANCHOR"
    ],
    "question_ids": [
      "1023",
      "1138"
    ]
  }
}
```

```json
{
  "id": "ROOT008_T6",
  "description": "未经确认的个案属性被当重新识别同人的Query前提，最后部分资料可被提升为题目答案或持续缺口检索。",
  "links": [
    {
      "case_id": "773__rep3__S001__FIRST_SENTENCE",
      "local_id": "UNVERIFIED_CASE_ATTRIBUTE_ENTERED_AS_REIDENTIFICATION_QUERY_CONSTRAINT"
    },
    {
      "case_id": "773__rep3__S001__FIRST_SENTENCE",
      "local_id": "PARTIAL_CASE_COLOR_SUBMITTED_WITH_IDENTITY_CHAIN_UNPROVEN"
    }
  ],
  "relation": "本批一题，不能把两个local算两题；一个为行动前提、一个为提交升级，下游互有先后但不同。与已有错误对象补属性线索比较，不强并其它核心已证而缺辅助条件案例。",
  "counterexamples": [
    "新2也Query限定个案但持续N，无正式颜色接受；其它三W少耗不是准确率改善。",
    "原U也已识别时间不匹配却原后仍用白色查询，非删后才出现。"
  ],
  "unresolved": "正确Red与同人身份从未被确认，不写正确证据被忽略。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 4,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 7,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": true,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "773__rep3__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "773"
    ]
  }
}
```

```json
{
  "id": "ROOT008_T7",
  "description": "不完整教师成功叙述被补成无据书名/作者履历，0真实检索便提交；实际搜索又可纠正初猜。",
  "links": [
    {
      "case_id": "353__rep2__S001__FIRST_SENTENCE",
      "local_id": "INCOMPLETE_FOUND_BOOK_GUIDE_COMPLETED_AS_UNSUPPORTED_PROFILE"
    }
  ],
  "relation": "干预提取异常审计，非自然Stage机制正例，不纳严格可省。原句在书名内感叹号停下，不能修改旧输入来制造干净案例。",
  "counterexamples": [
    "同G新2真实搜索改正确书C、新3真实搜索无果N，不能由G异常唯一预测虚构提交。"
  ],
  "unresolved": "引导结构/采样/空P重启影响无法分离，不重跑、不改旧标签或Frozen。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 2,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 2,
    "not_observed_local_chain_occurrences": 2,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "353__rep2__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "353"
    ]
  }
}
```


## unresolved

```json
{
  "case_id": "980__rep2__S005__FIRST_SENTENCE",
  "issue": "新2没有Dosti返回，冲突已识别却旧片接受；不可归忘记条件或已见正确片拒绝。"
}
```

```json
{
  "case_id": "1023__rep3__S002__FIRST_SENTENCE",
  "issue": "广告/Ruby缺证，73556只截到1919开头；CHAR原生成不可精确净算。"
}
```

```json
{
  "case_id": "1046__rep1__S002__FIRST_SENTENCE",
  "issue": "三C的早期定罪支持不同：新1只2025指控，新4错绑2009，新2直接早期定罪有据；不以公司名覆盖。"
}
```

```json
{
  "case_id": "1095__rep1__S002__FIRST_SENTENCE",
  "issue": "G提供核哪条方向，前比较省实例非省判断；仅一题不能宣称通用总结冗余。"
}
```

```json
{
  "case_id": "1096__rep1__S002__FIRST_SENTENCE",
  "issue": "全文SFL段未回，疑点检查不全算伪任务；真实会议重试与已知关键词再核不同。"
}
```

```json
{
  "case_id": "353__rep2__S001__FIRST_SENTENCE",
  "issue": "首句提取在书名内!误停，ORACLE部分书名/成功框架；两0CallW不有效节省。"
}
```

```json
{
  "case_id": "377__rep3__S002__FIRST_SENTENCE",
  "issue": "同份Rev片段返回但三支未用，地域过滤为可见共现非唯一内部原因；新2病因支持弱于原。"
}
```

```json
{
  "case_id": "1138__rep3__S002__TERMINAL_DROP_NO_ANCHOR",
  "issue": "无G三C仍缺数值，生成全增加而Search少；不把末guard未发请求计Actor。"
}
```

```json
{
  "case_id": "299__rep2__S003__FIRST_SENTENCE",
  "issue": "错年份可作为待核也可无证排除；新3名字C仍2022错误，支持不完整。"
}
```

```json
{
  "case_id": "773__rep3__S001__FIRST_SENTENCE",
  "issue": "四支未证同人身份，三W/一N不准确率变化；可见颜色属于不匹配个案，未得到正确Red。"
}
```


## 限制
10Stage/10题/10原轨迹/40支，含9FIRST_SENTENCE和1TERMINAL无G，分别统计；既往同题Stage不冒充新增题。七个检验含组件重叠，续跑按case+repeat去重，各local保留定义和方向。Codex审阅不等研究者金标准，不从有限分支识别纯因果。