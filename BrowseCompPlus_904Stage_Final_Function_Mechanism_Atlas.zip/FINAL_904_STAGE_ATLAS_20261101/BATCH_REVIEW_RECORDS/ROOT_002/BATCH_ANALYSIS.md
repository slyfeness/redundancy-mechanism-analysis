# ROOT_002 批次归纳

10 Stage / 10题 / 10原轨迹 / 40续跑；组别{'A': 5, 'B': 5}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "将材料已返回但尚未采用的对象变成条件比较和后继核查对象。",
  "members": [
    "69__rep1__S003__FIRST_SENTENCE",
    "78__rep1__S002__FIRST_SENTENCE",
    "87__rep1__S002__FIRST_SENTENCE"
  ],
  "distinction": "都为无Call认知U；G随后又提供具名核查方向，87甚至完整预填后继推理句。稳定C不等于采用无价值，Call前比较可后置重建。"
}
```

```json
{
  "description": "已有明确候选时首次补待查事实或核尚未证的关系。",
  "members": [
    "55__rep2__S003__FIRST_SENTENCE",
    "83__rep1__S004__FIRST_SENTENCE",
    "228__rep1__S002__FIRST_SENTENCE"
  ],
  "distinction": "55首次核1951真填槽，83两缺口没补齐并另确认已知姓名，228一次联合泛查没建筑关系。均叫核验会掩盖产物和信息状态差异。"
}
```

```json
{
  "description": "当前探索失败后改证据入口或维持特定假设范围，保留失败反馈供后继选择。",
  "members": [
    "226__rep1__S002__FIRST_SENTENCE",
    "257__rep1__S003__FIRST_SENTENCE",
    "261__rep2__S002__FIRST_SENTENCE",
    "270__rep2__S002__FIRST_SENTENCE"
  ],
  "distinction": "226商铺定位返局部地址却没用；257旧作者别名失败后原后继改描述；261期刊失败仍回未证领域；270把未证地区/年代持续写入Query。失败取证的作用不能只看有无新事实，也要看反馈后真实行动。"
}
```


## comparisons

```json
{
  "id": "ROOT002_C1",
  "cases": [
    "69__rep1__S003__FIRST_SENTENCE",
    "87__rep1__S002__FIRST_SENTENCE",
    "78__rep1__S002__FIRST_SENTENCE"
  ],
  "finding": "三个纯认知U都用P材料进行候选采用，删除后G指名或限定王国使实际核查可直接开始，比较又在返回后恢复。69/87多数Call前无新盘点不等于功能消失；78在同样方向下大学假说和末代/现任称号关系仍可分叉。",
  "counter": "87完整后继推理预填方法限制最强；78新4正确称号返回被误读导致W，不能说G保证正确。"
}
```

```json
{
  "id": "ROOT002_C2",
  "cases": [
    "55__rep2__S003__FIRST_SENTENCE",
    "69__rep1__S003__FIRST_SENTENCE",
    "83__rep1__S004__FIRST_SENTENCE",
    "87__rep1__S002__FIRST_SENTENCE"
  ],
  "finding": "相似的再次核查须查已知状态：55学校1951在U前没证，四支恢复是必要功能重做；69新4第三查是已明确确认后重开，但第二查仍有增量；83姓名在P已有，可不另查，两个未证条件仍实际查；87新4资料已返却直到最后才明确接受，不能确定已采纳事实重开。",
  "counter": "不把所有相近Query归R2，87新2/4仍不确定；不把恢复工作归冗余，也不把单项减少当全资源减少。"
}
```

```json
{
  "id": "ROOT002_C3",
  "cases": [
    "226__rep1__S002__FIRST_SENTENCE",
    "257__rep1__S003__FIRST_SENTENCE",
    "270__rep2__S002__FIRST_SENTENCE"
  ],
  "finding": "B中的改善和退化可同有对象进入行动这一观察变量，但实际节点不同：226晚地标题名采用才具名核查；270有证新菜采用结束无对象猜菜；257虽四支都找到新书，书目角色仍会在获取、解释或行动承接三个节点失败。",
  "counter": "257新4已说正确后版关系却仍查D&Q，不能将正确复述当行动更新；226早商业地址没采用仍可能晚宽查询成功，转化非单一既定路径。"
}
```

```json
{
  "id": "ROOT002_C4",
  "cases": [
    "228__rep1__S002__FIRST_SENTENCE",
    "270__rep2__S002__FIRST_SENTENCE",
    "78__rep1__S002__FIRST_SENTENCE"
  ],
  "finding": "未证解释进入Query参数后会改变要补什么：母校被当受赠大学、Italian/古早被当菜范围、Timbuktu被当父亲大学。要区分把它当待检验猜测和当已成立前提，不能任何带假设的Query都叫错误。",
  "counter": "270新4仍有古典印象却用真实现代菜证据更新；78新1最后采用Cambridge仍C，Query框架可修；228新3另有真实一般捐款，不是纯母校唯一推断。"
}
```

```json
{
  "id": "ROOT002_C5",
  "cases": [
    "261__rep2__S002__FIRST_SENTENCE",
    "257__rep1__S003__FIRST_SENTENCE",
    "226__rep1__S002__FIRST_SENTENCE"
  ],
  "finding": "恢复一次失败尝试不保证恢复后续策略或停止：261四支期刊恢复仍N；257唯一C重做别名失败再换描述，但另三也发现Freddie；226恢复商业地址还可忽略，最终转化可从别入口发生。",
  "counter": "不能由257重建与C共变认旧失败Call必要；261 W→N全部仍未答对，不能套关键正确信息丢失。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT002_T1",
  "description": "真实对象/关系必须用于下一具体行动才缩小后继任务；新材料可见或正确关系被说出本身不是完成转换。",
  "links": [
    {
      "case_id": "226__rep1__S002__FIRST_SENTENCE",
      "local_id": "MONUMENT_IDENTITY_CHANGES_RELATION_QUERIES"
    },
    {
      "case_id": "257__rep1__S003__FIRST_SENTENCE",
      "local_id": "EDITION_RELATION_MUST_REACH_ACTUAL_PUBLISHER_QUERY"
    },
    {
      "case_id": "270__rep2__S002__FIRST_SENTENCE",
      "local_id": "NAMED_DISH_EVIDENCE_ENDS_OBJECTLESS_GUESSING"
    }
  ],
  "relation": "继续检验P2_R1，257是关系判断到行动的细分，保留各链环节而不把所有W归未采用。",
  "counterexamples": [
    "257新4正确关系识别却未进入Call；新1没有同等书目，不能混为同前态。",
    "270有证目标采用后仍城史缺口，226成功也未证全部100米，转换不是全质量充分条件。"
  ],
  "unresolved": "无法唯一解释何时某Query召回直接对象，不能将采用变量当删除纯因果。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 9,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 1,
    "observed_local_chain_occurrences": 9,
    "not_observed_local_chain_occurrences": 2,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 1,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "226__rep1__S002__FIRST_SENTENCE",
      "257__rep1__S003__FIRST_SENTENCE",
      "270__rep2__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "226",
      "257",
      "270"
    ]
  }
}
```

```json
{
  "id": "ROOT002_T2",
  "description": "明确已采用的事实重新派为真实确认任务，会增加执行；但缺口仍未被认为充分时的再查不自动满足这个定义。",
  "links": [
    {
      "case_id": "69__rep1__S003__FIRST_SENTENCE",
      "local_id": "CONFIRMED_BIRTH_RELATION_REDISPATCHED"
    },
    {
      "case_id": "87__rep1__S002__FIRST_SENTENCE",
      "local_id": "ALREADY_ACCEPTED_FACT_REDISPATCH_NOT_YET_PROVEN"
    }
  ],
  "relation": "69新4是P2_R2确定新题；87新2/4仅不确定边界，不计确定支持。83原姓名确认未再执行为另种少做观察，不自动混作新路径重复正例。",
  "counterexamples": [
    "69第二Call补丈夫资料确有新增，不能全部三查都叫重复；87新4前几轮没说已确认。"
  ],
  "unresolved": "R2的必要前提是事实已支持且采用，资料在Return里不能替代该前提。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 1,
    "not_observed_rollouts": 5,
    "uncertain_rollouts": 2,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 1,
    "not_observed_local_chain_occurrences": 5,
    "uncertain_local_chain_occurrences": 2,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "69__rep1__S003__FIRST_SENTENCE"
    ],
    "question_ids": [
      "69"
    ]
  }
}
```

```json
{
  "id": "ROOT002_T3",
  "description": "同一候选与缺口保留时，真实取证/比较可恢复或后置，费用由实际覆盖、联合组织、额外确认和表达决定。",
  "links": [
    {
      "case_id": "55__rep2__S003__FIRST_SENTENCE",
      "local_id": "RETAINED_SCHOOL_GAP_RESTORES_DIRECT_FACT"
    },
    {
      "case_id": "69__rep1__S003__FIRST_SENTENCE",
      "local_id": "COMPARISON_RESTORED_OR_REORDERED_WITH_GUIDE_BRIDGE"
    },
    {
      "case_id": "87__rep1__S002__FIRST_SENTENCE",
      "local_id": "GUIDED_ACTION_THEN_POST_RETURN_COMPARISON"
    }
  ],
  "relation": "55为P1_K2事实恢复；69/87为G桥接后认知比较换序，不将其等同自主恢复。共同是功能存在而执行形式可不同，须保留子状态。",
  "counterexamples": [
    "55四支恢复1951，仅第四总成本全降；69第四恢复后更贵，87第三比较恢复却错绑河流。"
  ],
  "unresolved": "G直接指定对象时不能识别无引导前置比较能否同样压缩。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 12,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 12,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "55__rep2__S003__FIRST_SENTENCE",
      "69__rep1__S003__FIRST_SENTENCE",
      "87__rep1__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "55",
      "69",
      "87"
    ]
  }
}
```

```json
{
  "id": "ROOT002_T4",
  "description": "未证解释被用作后继工作前提，持续向特定学校/国家/年代索要属性；应看该假设是否受返回反馈更新。",
  "links": [
    {
      "case_id": "228__rep1__S002__FIRST_SENTENCE",
      "local_id": "ALMA_MATER_ASSUMED_AS_BUILDING_RECIPIENT"
    },
    {
      "case_id": "270__rep2__S002__FIRST_SENTENCE",
      "local_id": "UNVERIFIED_REGION_ERA_CONSTRAINS_SEARCH_SPACE"
    },
    {
      "case_id": "78__rep1__S002__FIRST_SENTENCE",
      "local_id": "SPECULATIVE_UNIVERSITY_RESTRICTS_RECHECK_OBJECT"
    }
  ],
  "relation": "支持ROOT001_T2上位候选但子链分开：错误角色造待核建筑、范围先验限制发现、已有假设反复确认。这里统计观察链，不等于每一条都支持同一方向结果。",
  "counterexamples": [
    "270新2/3/4分别放宽后采用现代菜；78新1后来改正仍C。带假设查证本可合理，不一概判所有探索有害。"
  ],
  "unresolved": "查询范围与召回相关不是严格反事实因果，正负成员必须按实际四支作用链分列。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 8,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 1,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 8,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 1,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "228__rep1__S002__FIRST_SENTENCE",
      "270__rep2__S002__FIRST_SENTENCE",
      "78__rep1__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "78",
      "228",
      "270"
    ]
  }
}
```

```json
{
  "id": "ROOT002_T5",
  "description": "对象角色/时间关系误解释可能直接进入答案或匹配表，即使核心对象已恢复、工具也真实执行。",
  "links": [
    {
      "case_id": "78__rep1__S002__FIRST_SENTENCE",
      "local_id": "TRIBUTE_OBJECT_MISREAD_AS_ADOPTED_NAME"
    },
    {
      "case_id": "87__rep1__S002__FIRST_SENTENCE",
      "local_id": "OTHER_LANGUAGE_RELATION_COMPLETES_WRONG_CLUE"
    },
    {
      "case_id": "228__rep1__S002__FIRST_SENTENCE",
      "local_id": "GENERAL_GIFT_WITHOUT_BUILDING_PROMOTED_IN_FINAL"
    }
  ],
  "relation": "与关系如何派发工作是上下游可重叠但不等同的环节：这里作用落在正式答案/解释，不能用它直接解释所有多出的Call。",
  "counterexamples": [
    "87核心Kaixana仍C但解释错误；78称号角色错误使FinalW；228明确建筑未核后断言则W。结果字段和质量字段分别统计。"
  ],
  "unresolved": "原U并非都已有对应正确关系，不能把新自主解释错误当直接删掉了现成纠正。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 3,
    "not_observed_rollouts": 9,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 3,
    "not_observed_local_chain_occurrences": 9,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "228__rep1__S002__FIRST_SENTENCE",
      "78__rep1__S002__FIRST_SENTENCE",
      "87__rep1__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "78",
      "87",
      "228"
    ]
  }
}
```


## unresolved

```json
{
  "case_id": "55__rep2__S003__FIRST_SENTENCE",
  "issue": "首次填学校事实恢复，不识别其无G必要性；期刊关系仍未证。"
}
```

```json
{
  "case_id": "69__rep1__S003__FIRST_SENTENCE",
  "issue": "G替候选采用到行动；额外两查须分覆盖不足与已证重开。"
}
```

```json
{
  "case_id": "78__rep1__S002__FIRST_SENTENCE",
  "issue": "最后I/II误读不是原U已有正确称号判断被删；大学/学院年代仍欠直接证据。"
}
```

```json
{
  "case_id": "83__rep1__S004__FIRST_SENTENCE",
  "issue": "G确认性增强，姓名确认少做不等整U可省；草稿content带Call不是Final。"
}
```

```json
{
  "case_id": "87__rep1__S002__FIRST_SENTENCE",
  "issue": "完整后继Reasoning预填；分类再查未必已采纳条件重开；河流错绑核心C。"
}
```

```json
{
  "case_id": "226__rep1__S002__FIRST_SENTENCE",
  "issue": "宽Query何时得题名未知，商业关系后置并未完整证明距离/时点。"
}
```

```json
{
  "case_id": "228__rep1__S002__FIRST_SENTENCE",
  "issue": "母校/受赠关系错误与婚育时点混用，不说四退化同一原因。"
}
```

```json
{
  "case_id": "257__rep1__S003__FIRST_SENTENCE",
  "issue": "重做旧别名与唯一C共变不证明该Call必要；三W获取/解释/行动各异。"
}
```

```json
{
  "case_id": "261__rep2__S002__FIRST_SENTENCE",
  "issue": "四N都没答对，U恢复仍无论文；原W正式拒答不代表有正确答案丢失。"
}
```

```json
{
  "case_id": "270__rep2__S002__FIRST_SENTENCE",
  "issue": "G给错误Ribollita、成功城史日期未得文档、范围放宽与召回不能唯一归删除。"
}
```


## 限制
10Stage为10题但与ROOT001有同题不同切点，跨批题数必须全局去重。新增10Stage不是新增10个独立题目。教师/自然条件分列，比较过程支持不等纯删除因果，机械PASS不等独立研究者金标准。