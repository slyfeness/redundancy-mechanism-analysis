# ROOT_005 批次归纳

10 Stage / 10题 / 10原轨迹 / 40续跑；组别{'A': 5, 'B': 5}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "将范围或故事线索变成具体人物/建筑/书的真实核验对象，首次采用并取得关系资料。",
  "members": [
    "299__rep1__S001__FIRST_SENTENCE",
    "353__rep2__S002__FIRST_SENTENCE",
    "377__rep1__S001__FIRST_SENTENCE",
    "673__rep1__S002__FIRST_SENTENCE",
    "342__rep1__S001__FIRST_SENTENCE",
    "392__rep4__S003__FIRST_SENTENCE"
  ],
  "distinction": "299五查后才采用，353先用P书目再新增履历，377真实教育组织得家族但G也先给家族，673纯推理从P采用。342/392原U都有效定位但原后继不成功，不能从原W/N否认U产品。"
}
```

```json
{
  "description": "无真实资料时进行记忆枚举、题面重述和未执行查询设计。",
  "members": [
    "319__rep1__S001__FIRST_SENTENCE"
  ],
  "distinction": "U6618Token没有Call或可靠餐馆，后Z仍长猜；四新短准备后真实材料完成定位，但有两支背景缺证/错误，不能单凭核心C称无损压缩。"
}
```

```json
{
  "description": "身份或对象已定后，实际重复尝试取得所求尚未获得的具体数值。",
  "members": [
    "282__rep1__S003__FIRST_SENTENCE",
    "317__rep1__S005__FIRST_SENTENCE"
  ],
  "distinction": "282动物身份支持充分但所求编号未知；317赛事仅部分匹配且另一局未知。U都没有拿到正确数值，原/新失败方向不同，不能归为重要信息被删除。"
}
```

```json
{
  "description": "准确拆开多条件区间并用第一次宽搜启动候选筛选，尚未采用具体候选。",
  "members": [
    "427__rep1__S001__FIRST_SENTENCE"
  ],
  "distinction": "U正确拆题但Z固定Underwood，G又提前给该实体/来源；首工具被省后会发生假多源接受，不把它当独立发现功能成功替代。"
}
```


## comparisons

```json
{
  "id": "ROOT005_C1",
  "cases": [
    "299__rep1__S001__FIRST_SENTENCE",
    "342__rep1__S001__FIRST_SENTENCE",
    "392__rep4__S003__FIRST_SENTENCE"
  ],
  "finding": "同是发现并采用对象，结果不是由是否出现正确名词决定。299新1早转具体人名核验减少泛搜，新3迟采用更贵；342新2正确文章多次返回仍不转人物、新3/4采用正确人物后仍卡身体条件；392三支身份真实恢复但未知城市备选名被关联名称替代，W。",
  "counter": "不能把所有失败说没采用，也不能将A中的修复成功说原发现无用；G在342/392给了未来事实，归因与299泛承接不同。"
}
```

```json
{
  "id": "ROOT005_C2",
  "cases": [
    "353__rep2__S002__FIRST_SENTENCE",
    "377__rep1__S001__FIRST_SENTENCE",
    "673__rep1__S002__FIRST_SENTENCE"
  ],
  "finding": "三A都恢复U，真实省落点多在Z：353三支回用P书页省后书确认，新3改为具体毕业年；377全支少病因专查，前三少支持、新4联合取证却错亲属；673两降两增来自井/前代取证持续不同。",
  "counter": "功能重建不是否定节省，但也不是完整质量保持。P已有题材页、未取得病因、已返未采用病因三种状态必须区分。"
}
```

```json
{
  "id": "ROOT005_C3",
  "cases": [
    "353__rep2__S002__FIRST_SENTENCE",
    "673__rep1__S002__FIRST_SENTENCE",
    "282__rep1__S003__FIRST_SENTENCE",
    "317__rep1__S005__FIRST_SENTENCE",
    "342__rep1__S001__FIRST_SENTENCE"
  ],
  "finding": "剩余缺口的作用取决于它是所求答案本身、鉴别身份的条件还是支持性背景。353毕业年/673井关系未证仍核心C；282所求serial未知只能猜W或继续N；317总量缺另一局，20只是部分；342正确驾驶员可见仍因身体鉴别条件持续核验N。",
  "counter": "不能把全部缺口统一为停止阈值，也不能由A答对就说对应条件可忽略；原新证据标准与预算边界另记。"
}
```

```json
{
  "id": "ROOT005_C4",
  "cases": [
    "299__rep1__S001__FIRST_SENTENCE",
    "392__rep4__S003__FIRST_SENTENCE",
    "427__rep1__S001__FIRST_SENTENCE",
    "377__rep1__S001__FIRST_SENTENCE"
  ],
  "finding": "时间/主体关系解释改变真实工作前提：299页面日期作开放年份导致绕查后修复C；392儿童改名作城市备选，已识别不等仍提交W；427死亡或活动年代作成立年使固定对象继续；377新4拿到兄弟病因仍改成母亲死亡而核心名字C。",
  "counter": "这些不同子关系不自动是同一个细机制；相同错误解释既可能被后证修复，又可能只损支持不改主答，不能只按终态筛机制。"
}
```

```json
{
  "id": "ROOT005_C5",
  "cases": [
    "319__rep1__S001__FIRST_SENTENCE",
    "427__rep1__S001__FIRST_SENTENCE",
    "392__rep4__S003__FIRST_SENTENCE"
  ],
  "finding": "少实际工作要问凭何继续：319短准备真实取得事故而四C，背景补足程度不同；427新3零Call将G来源扩成三文档而W；392新3零Call是工具格式停顿N。",
  "counter": "同样低Token/少Search，分别是有效替代加支持缺口、虚构来源错误提交、技术停止，不可合成冗余省算。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT005_T1",
  "description": "相关材料必须被用于选择具体核验对象；转换时点改变后续泛搜数量，但转换恢复不保证剩余条件闭合。",
  "links": [
    {
      "case_id": "299__rep1__S001__FIRST_SENTENCE",
      "local_id": "BUILDING_EVIDENCE_BECOMES_PERSON_SPECIFIC_QUERY"
    },
    {
      "case_id": "319__rep1__S001__FIRST_SENTENCE",
      "local_id": "SPECIFIC_MENU_OR_STYLE_RETURN_UPDATES_RESTAURANT_QUERY"
    }
  ],
  "relation": "P2_R1正向比较，两题内均保留材料到采用再到真实Query。342另记录未转换负对照，不把未转换算正例。",
  "counterexamples": [
    "299新3最终转换但晚，资源仍多；319新4转换连锁但创办人错误，转换不等所有质量保持。",
    "342新2返回具体车手文章却不采用，新3/4采用车手仍没Final，是不同中断环节。"
  ],
  "unresolved": "较早采用与更早召回同时变化，不能把全部差值独归一个认知节点。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 7,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 7,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "299__rep1__S001__FIRST_SENTENCE",
      "319__rep1__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "299",
      "319"
    ]
  }
}
```

```json
{
  "id": "ROOT005_T2",
  "description": "对结果的主体/时间/属性关系解释产生可执行前提，错误关系会制造假冲突或用相关名称填入所求关系；修复和反例分别保留。",
  "links": [
    {
      "case_id": "299__rep1__S001__FIRST_SENTENCE",
      "local_id": "ARTICLE_DATE_BECOMES_OPENING_EVENT_AND_FALSE_CONFLICT"
    },
    {
      "case_id": "392__rep4__S003__FIRST_SENTENCE",
      "local_id": "BIBLICAL_PERSON_RENAMING_PROMOTED_TO_CITY_ALTERNATIVE"
    },
    {
      "case_id": "427__rep1__S001__FIRST_SENTENCE",
      "local_id": "DEATH_OR_ACTIVITY_YEAR_PROMOTED_TO_COMPANY_FOUNDING"
    },
    {
      "case_id": "377__rep1__S001__FIRST_SENTENCE",
      "local_id": "AVAILABLE_SIBLING_CAUSE_REPLACED_BY_PARENT_DEATH_CONDITION"
    }
  ],
  "relation": "支持前批关系解释→工作前提的上位提案，不能扩写P1_K1来覆盖。各子链的字段、接受状态和后继行动必须保留。",
  "counterexamples": [
    "299错日期新2仍沿原人名核验，新4绕查，最终都修复C；377错亲属仍妻子C。",
    "392新1错误名称来自土地非儿童，427其它支不是死亡年作成立年，均不强套同子链。"
  ],
  "unresolved": "已识别关系不对为何仍接受尚无唯一解释，不用隐藏信心填补。",
  "deterministic_counts": {
    "observed_stage_count": 4,
    "different_questions": 4,
    "original_runs": 4,
    "observed_rollouts": 6,
    "not_observed_rollouts": 9,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 1,
    "observed_local_chain_occurrences": 6,
    "not_observed_local_chain_occurrences": 9,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 1,
    "total_distinct_rollouts_in_test": 16,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "299__rep1__S001__FIRST_SENTENCE",
      "377__rep1__S001__FIRST_SENTENCE",
      "392__rep4__S003__FIRST_SENTENCE",
      "427__rep1__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "299",
      "377",
      "392",
      "427"
    ]
  }
}
```

```json
{
  "id": "ROOT005_T3",
  "description": "目标功能重建后可以省掉另一个后继工作，但核心答案保持也可能伴少证据，须按前态和具体省落点拆开。",
  "links": [
    {
      "case_id": "353__rep2__S002__FIRST_SENTENCE",
      "local_id": "AUTHOR_VERIFICATION_RESTORED_BOOK_RECHECK_OMITTED"
    },
    {
      "case_id": "377__rep1__S001__FIRST_SENTENCE",
      "local_id": "CORE_SPOUSE_ANSWER_PRESERVED_WITHOUT_EQUAL_SIBLING_EVIDENCE"
    }
  ],
  "relation": "两类不同省法的条件对照，不合并为统一可省机制；353用P已返书页减少确认，377前三少病因支持。",
  "counterexamples": [
    "353新3查真实未知年份，Search同原且生成升；377新4病因已联合返回却解释错，排出未取证子链。"
  ],
  "unresolved": "各约束支持强度不能由C alone决定，毕业年和legalfirst法律资料仍有缺证。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 6,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 1,
    "observed_local_chain_occurrences": 6,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 1,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "353__rep2__S002__FIRST_SENTENCE",
      "377__rep1__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "353",
      "377"
    ]
  }
}
```

```json
{
  "id": "ROOT005_T4",
  "description": "正确候选被恢复或维持后，未证条件继续派发真实核验；查询次数与是否提交不由候选是否重建单独决定。",
  "links": [
    {
      "case_id": "353__rep2__S002__FIRST_SENTENCE",
      "local_id": "UNVERIFIED_DEGREE_YEAR_DISPATCHES_SPECIFIC_SEARCH_ONLY_ONCE"
    },
    {
      "case_id": "673__rep1__S002__FIRST_SENTENCE",
      "local_id": "POETESS_ADOPTED_BUT_UNCLOSED_WELL_CONTINUES_DISPATCHING_WORK"
    },
    {
      "case_id": "342__rep1__S001__FIRST_SENTENCE",
      "local_id": "CORRECT_DRIVER_RESTORED_PHYSICAL_CLUE_REMAINS_QUERY_TRIGGER"
    }
  ],
  "relation": "检验P2_R3，保留新1/2未形成车手与新3/4已有车手的前态区别；所需条件不能一概辅助化。",
  "counterexamples": [
    "673全C且两支资源增加；353只有新3真查年份，其它只是意向或推断；342只有两支恢复车手，另两不算同前态。"
  ],
  "unresolved": "为什么同缺口有的核验、有的接受仍不能唯一解释；记录真实决定不声称隐藏停止阈值。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 7,
    "not_observed_rollouts": 5,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 7,
    "not_observed_local_chain_occurrences": 5,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "342__rep1__S001__FIRST_SENTENCE",
      "353__rep2__S002__FIRST_SENTENCE",
      "673__rep1__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "342",
      "353",
      "673"
    ]
  }
}
```

```json
{
  "id": "ROOT005_T5",
  "description": "查询失败后已知所求属性未知，却在提交时用泛规则、名字记号或关联名称填补；是失败终态改变的具体路径，不是正确证据遗失。",
  "links": [
    {
      "case_id": "282__rep1__S003__FIRST_SENTENCE",
      "local_id": "KNOWN_IDENTITY_UNKNOWN_ATTRIBUTE_REPLACED_WITH_UNSUPPORTED_NUMBER"
    },
    {
      "case_id": "392__rep4__S003__FIRST_SENTENCE",
      "local_id": "KNOWN_RELATION_MISMATCH_REPLACED_WITH_ASSOCIATED_NAME_AT_SUBMISSION"
    }
  ],
  "relation": "新上位候选，282未知数字与392已知非所求关系均有正式猜答，但是否先认识关系不符不同，保留子链而非仅叫无证提交。",
  "counterexamples": [
    "392新3协议停止无真实取证，排除；原两轨迹都未找到却继续至N，没有同样猜答。",
    "282新2知道Pen²不是serial仍用其它泛规则猜001，识别一种不成立关系不保证不再猜。"
  ],
  "unresolved": "本批只有两题，原始状态都N，不能推广到所有C删除退化；采样和G复盘影响未排除。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 7,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 1,
    "observed_local_chain_occurrences": 7,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 1,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "282__rep1__S003__FIRST_SENTENCE",
      "392__rep4__S003__FIRST_SENTENCE"
    ],
    "question_ids": [
      "282",
      "392"
    ]
  }
}
```

```json
{
  "id": "ROOT005_T6",
  "description": "未解决缺口触发再次真实查询，但反馈没有改变对象或取证操作；需区分固定部分匹配赛事与尚未形成对象的广搜。",
  "links": [
    {
      "case_id": "317__rep1__S005__FIRST_SENTENCE",
      "local_id": "PARTIAL_MATCH_FIXED_AND_UNSEEN_INNINGS_ASSIGNED_REMAINING_CONSTRAINTS"
    },
    {
      "case_id": "342__rep1__S001__FIRST_SENTENCE",
      "local_id": "FAILED_QUERY_FEEDBACK_DOES_NOT_CHANGE_EXECUTED_QUERY"
    }
  ],
  "relation": "与前批失败反馈未改变行动相比较，不把宽泛检索/固定实体补证直接合为一种机制。317前提早在P，删一次执行不消除触发；342空P中新形成路径。",
  "counterexamples": [
    "317新1同样恢复工作却正式20W，其余N；342正确车手恢复的两支也反复，不能全归没有对象。",
    "新方法初次核题目条件可合理，不能凭最后没查到判断所有尝试无用。"
  ],
  "unresolved": "有效入口是否存在未由现有轨迹证实，不启动新检索。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 8,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 8,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "317__rep1__S005__FIRST_SENTENCE",
      "342__rep1__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "317",
      "342"
    ]
  }
}
```

```json
{
  "id": "ROOT005_T7",
  "description": "长篇无资料候选枚举/未执行计划可被更短准备加真实取证替代，但替代证据的充分程度决定能否谈质量保持。",
  "links": [
    {
      "case_id": "319__rep1__S001__FIRST_SENTENCE",
      "local_id": "LONG_UNEXECUTED_ENUMERATION_REPLACED_BY_EARLY_REAL_EVIDENCE"
    }
  ],
  "relation": "本批新候选，只有一题；不得将单题四次写成跨题已验证，也不同于已证后再次确认。",
  "counterexamples": [
    "319新3/4省最多却有错误背景；其余无Call低成本例427新3伪来源、392新3技术停，不是本机制正支持。"
  ],
  "unresolved": "没有无G对照且G给错误候选，不能计算纯删长猜的因果量。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 4,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "319__rep1__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "319"
    ]
  }
}
```

```json
{
  "id": "ROOT005_T8",
  "description": "教师引导以已见文档语气提供实体来源时，新模型可能把它当实际返回并扩成多源一致，在零Call下错误提交。",
  "links": [
    {
      "case_id": "427__rep1__S001__FIRST_SENTENCE",
      "local_id": "TEACHER_SOURCE_NARRATIVE_TREATED_AS_REAL_MULTI_DOCUMENT_SUPPORT"
    }
  ],
  "relation": "干预条件的新风险，不能作自然Stage冗余机制或原U因果作用。与peer495假访谈来源需核不同起点，不自动合并。",
  "counterexamples": [
    "427其它三支有真实工具，与零Call不能混；319虽G给错误候选但四支都真取证且得核心数字。"
  ],
  "unresolved": "仅一题一支，G来源语气和采样不可独立分离。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 1,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 1,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "427__rep1__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "427"
    ]
  }
}
```


## unresolved

```json
{
  "case_id": "299__rep1__S001__FIRST_SENTENCE",
  "issue": "新3首次提取名字的隐藏节点不可定位，真实Query可定位；错误日期后修复没有明确提出元数据不可信原则。"
}
```

```json
{
  "case_id": "319__rep1__S001__FIRST_SENTENCE",
  "issue": "核心数值C但新3/4背景错误，原也未补齐；不能用一句质量保持概括。"
}
```

```json
{
  "case_id": "353__rep2__S002__FIRST_SENTENCE",
  "issue": "毕业年份原新均无直接资料，G未来成功语气可能补接受，CHAR差值区间。"
}
```

```json
{
  "case_id": "377__rep1__S001__FIRST_SENTENCE",
  "issue": "前三病因资料缺与新4已取错解释不同，legalfirst无独立法律登记证据。"
}
```

```json
{
  "case_id": "673__rep1__S002__FIRST_SENTENCE",
  "issue": "所有路径井关系未证且Final确定化；采用恢复不决定核验次数。"
}
```

```json
{
  "case_id": "282__rep1__S003__FIRST_SENTENCE",
  "issue": "四W皆未知数值猜答，不同泛规则/名称记号子链不混；LCL对应共享缺证。"
}
```

```json
{
  "case_id": "317__rep1__S005__FIRST_SENTENCE",
  "issue": "候选赛事本身是否正确未证，不由Gold或另一局未返推不存在；W/N无答对率变化。"
}
```

```json
{
  "case_id": "342__rep1__S001__FIRST_SENTENCE",
  "issue": "文章只回前部，不能标题当身体问题证据；新2有具体车手返回未采用已定向验证。"
}
```

```json
{
  "case_id": "392__rep4__S003__FIRST_SENTENCE",
  "issue": "新3协议停排除认知链；其它三支身份恢复后未知城市名被关联名替代。"
}
```

```json
{
  "case_id": "427__rep1__S001__FIRST_SENTENCE",
  "issue": "G明确未来实体与来源，零Call扩文档风险；63478局部工厂不能倒推Gold全题已证。"
}
```


## 限制
10题各一Stage不等于机制跨题支持都10；每个机制依显式正/反/不确定/排除分区复算。批内不同题目数不能跨批相加。FIRST_SENTENCE均ORACLE_ANCHORED，G风险、原生/CHAR模式、正式Final与中间猜测分开。上述为Codex语义审阅，不是独立人工金标准。