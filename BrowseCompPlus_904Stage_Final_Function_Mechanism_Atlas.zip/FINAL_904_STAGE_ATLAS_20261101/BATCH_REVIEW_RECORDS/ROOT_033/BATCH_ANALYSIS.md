# ROOT_033 批次归纳

10 Stage / 6题 / 7原轨迹 / 40续跑；组别{'A': 10}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "已有候选而具体身份/独立条件尚缺，实际取证补齐。",
  "members": [
    "291__rep4__S002__FIRST_SENTENCE",
    "377__rep1__S005__FIRST_SENTENCE"
  ],
  "distinction": "童星姓名P采用但出生/学校尚缺；妻名刚采用但兄弟死因未证。四支都恢复必要缺口，少的是不同原Z重确认，非U功能必然多余。"
}
```

```json
{
  "description": "新材料到条件比较或已经采用后的整体接受。",
  "members": [
    "299__rep4__S002__FIRST_SENTENCE",
    "673__rep1__S007__TERMINAL_DROP_NO_ANCHOR",
    "1046__rep2__S008__FIRST_SENTENCE"
  ],
  "distinction": "建筑比较含错误时间推算却未排除两人；女诗人明确核心井关系未证仍接受；公司已知名字和一般定罪但特定罪名未证，整体足够判断先完成再去确认。不同前提与认知动作不统一叫列表。"
}
```

```json
{
  "description": "已有主名下的具体罪名区分或最后再次外部确认。",
  "members": [
    "1046__rep2__S007__FIRST_SENTENCE",
    "1046__rep2__S009__TERMINAL_DROP_NO_ANCHOR"
  ],
  "distinction": "罪名U失败未获得bribery直接证明；末段U则新获直接复杂结构支持，不能按均为公司重复核验自动归同一无增量工作。"
}
```

```json
{
  "description": "未知对象广搜、失败处理与下一入口选择。",
  "members": [
    "319__rep2__S001__FIRST_SENTENCE",
    "1046__rep3__S001__FIRST_SENTENCE",
    "1046__rep3__S003__FIRST_SENTENCE"
  ],
  "distinction": "前两P0整体重启，第三保留两个候选排除。餐馆有真实联合证据闭合多个需求，公司S003的G提前下一入口，具体作用与空P重新探索不同。"
}
```


## comparisons

```json
{
  "id": "ROOT033_C1",
  "cases": [
    "291__rep4__S002__FIRST_SENTENCE",
    "377__rep1__S005__FIRST_SENTENCE"
  ],
  "finding": "相同A稳定都恢复了U未补的必要事实，后续重确认可取消或再执行。童星新4再查已知护士事件用于截至2023姓名差异，妻子2/3/4再查已得妻名。",
  "counter": "护士重查还承担时间对照，妻名重查可能增加来源支持，不能把R2都叫零价值。377 G172Token整列表是历史提取异常，不能当普通最小一句。"
}
```

```json
{
  "id": "ROOT033_C2",
  "cases": [
    "299__rep4__S002__FIRST_SENTENCE",
    "319__rep2__S001__FIRST_SENTENCE"
  ],
  "finding": "建筑2/3将原联合人物查拆成先业主后建筑师，Search/Actor增加；餐馆2/3/4同一真实Return同时补两个未解关系，少调用但部分生成更多。",
  "counter": "联合证据是一个真实Return实际被采用，不等多个Call并行；餐馆1发现晚且12Call，不能由根删全部C称初探无用。"
}
```

```json
{
  "id": "ROOT033_C3",
  "cases": [
    "1046__rep2__S007__FIRST_SENTENCE",
    "1046__rep2__S008__FIRST_SENTENCE"
  ],
  "finding": "相邻公司切点呈相反成本：S007删具体罪名尝试并接足够判断G，四均少查而接受；S008删整体接受接公司核验G，四更多查后晚接受。",
  "counter": "真实罪名原也未直证，停止判定/G/随机后续不可单独隔离；不能宣称隐含停止阈值已被证明改变。新1意向查罪名但实际第二Call查公司，不能四支都算罪名Search恢复。"
}
```

```json
{
  "id": "ROOT033_C4",
  "cases": [
    "1046__rep2__S007__FIRST_SENTENCE",
    "1046__rep2__S009__TERMINAL_DROP_NO_ANCHOR"
  ],
  "finding": "S007未知specific bribery未由原U解决，不能声称删除独立成功补证；末S009首次真实结构原文由U取得并用于Final，新4取消该取证却仍按规模写复杂结构，是直接条件支持损失主方案。",
  "counter": "P的大集团/27bn可间接支持复杂，N006末段新4保留研究者备选；不能把rep1S006只有罪名分量的UNC自动扩定义。"
}
```

```json
{
  "id": "ROOT033_C5",
  "cases": [
    "673__rep1__S007__TERMINAL_DROP_NO_ANCHOR",
    "1046__rep2__S009__TERMINAL_DROP_NO_ANCHOR"
  ],
  "finding": "同为G0末段，诗人四全重新完成缺口权衡并Formal断言未证井关系，其中3真实多查仍不证；公司三重新真取结构、一不查主名仍C。",
  "counter": "诗人身份可能由其他唯一生平已强支持，主名C不等井关系被证；公司前态已完成全局接受且间接结构可用，不能把两者统一归无认知工作。"
}
```

```json
{
  "id": "ROOT033_C6",
  "cases": [
    "1046__rep3__S001__FIRST_SENTENCE",
    "1046__rep3__S003__FIRST_SENTENCE"
  ],
  "finding": "同题首段P0四全恢复探索且更贵；第三段已排除两人，G直接给Evergrande入口，一/三首Return转Benko，二/四先虚构人物/原名关系派发属性工作才迟得真材料。",
  "counter": "中国/俄罗斯检索词不是已接受题限；S003新1也错人名Query却立刻转真证，只有错误首Query不足以说明持续错误前提。四C不能代表相同工作和消耗。"
}
```

```json
{
  "id": "ROOT033_C7",
  "cases": [
    "299__rep4__S002__FIRST_SENTENCE",
    "1046__rep3__S003__FIRST_SENTENCE",
    "673__rep1__S007__TERMINAL_DROP_NO_ANCHOR"
  ],
  "finding": "建筑错误时间解释可制造额外真实开业核验后纠正；公司无支持角色前提制造属性查询后换对象；诗人明确不证井却以他条件接受。具体判断影响下一实际工作/提交，不能只记关系错或重建。",
  "counter": "三种链并非同一个机制，建筑新4内部选直证时间无新增Call，诗人不查也可C，需保留纠正、增量和主名/证据质量的差别。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT033_T1",
  "description": "P已有主体后仍缺具体身份/关系，删除后真实核验恢复。",
  "links": [
    {
      "case_id": "291__rep4__S002__FIRST_SENTENCE",
      "local_id": "ADOPTED_BAHA_ANCHOR_REACQUIRES_BIRTH_AND_IDENTITY_THEN_VERIFIES_SCHOOL"
    },
    {
      "case_id": "377__rep1__S005__FIRST_SENTENCE",
      "local_id": "RETAINED_BEKO_AND_WIFE_REACQUIRE_MISSING_SIBLING_ILLNESS_RELATION"
    }
  ],
  "relation": "P1_K2，只四支实际取回而非G给名字就算P既知全部；共同功能与已完成重复确认分开。",
  "counterexamples": [
    "377少查原Z妻子并不等U死因省掉；童星学校仍要第二真实取证。"
  ],
  "unresolved": "母亲管理及金额精确条件、NUT1926共享误属性未由C自动消解。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 8,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 8,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "291__rep4__S002__FIRST_SENTENCE",
      "377__rep1__S005__FIRST_SENTENCE"
    ],
    "question_ids": [
      "291",
      "377"
    ]
  }
}
```

```json
{
  "id": "ROOT033_T2",
  "description": "实际材料采用改变真实下一查询。",
  "links": [
    {
      "case_id": "319__rep2__S001__FIRST_SENTENCE",
      "local_id": "REAL_CHAIN_OR_MENU_RELATION_CHANGES_NEXT_SPECIFIC_SEARCH_OBJECT"
    },
    {
      "case_id": "1046__rep3__S001__FIRST_SENTENCE",
      "local_id": "FIRST_TRUE_BENKO_MATERIAL_UPDATES_OBJECT_AND_NEXT_REAL_VERIFICATION"
    },
    {
      "case_id": "1046__rep3__S003__FIRST_SENTENCE",
      "local_id": "NEW_BENKO_RETURN_INTERRUPTS_UNSUPPORTED_SEARCH_PREMISE_AND_CHANGES_REAL_OBJECT"
    }
  ],
  "relation": "P2_R1跨两题，及时采用并不保证发现早或成本低；两公司原Stage还是同题同原轨迹不可当跨题独立支持。",
  "counterexamples": [
    "餐馆新1十二Search才完成，S003新2/4晚返仍立即转向，不能叫一直忽视已有证据。"
  ],
  "unresolved": "前入口的G补偿与检索组合影响不能唯一分离。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 12,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 12,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep3__S001__FIRST_SENTENCE",
      "1046__rep3__S003__FIRST_SENTENCE",
      "319__rep2__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "319",
      "1046"
    ]
  }
}
```

```json
{
  "id": "ROOT033_T3",
  "description": "未证实体角色成为具体属性任务前提，真证可中断绕行。",
  "links": [
    {
      "case_id": "1046__rep3__S003__FIRST_SENTENCE",
      "local_id": "UNSUPPORTED_FOUNDER_OR_ORIGINAL_NAME_BECOMES_ATTRIBUTE_CHECK_PREMISE"
    },
    {
      "case_id": "1046__rep3__S003__FIRST_SENTENCE",
      "local_id": "FIXED_UNVERIFIED_FOUNDER_RELATION_GAP_TRIGGERS_REAL_RETRIES_AFTER_FAILURE"
    }
  ],
  "relation": "N003与K3相连但不等同：先角色前提派发，再缺口反馈重派发。新2/4明确认知及真实属性Call支持，两局部链重叠分支不相加。",
  "counterexamples": [
    "新1错首Query但即转真证；新3无自添名字直转，均C却更少Calls。"
  ],
  "unresolved": "一题内对照非因果独立证明，具体假姓名不在G但公司/罪名方向来自G。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 2,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 4,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep3__S003__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1046"
    ]
  }
}
```

```json
{
  "id": "ROOT033_T4",
  "description": "同真实Return闭合多关系与已采用关系再确认是不同成本来源。",
  "links": [
    {
      "case_id": "319__rep2__S001__FIRST_SENTENCE",
      "local_id": "ONE_TRUE_RETURN_JOINTLY_SUPPLIES_INCIDENT_OR_CHAIN_AND_FOUNDER_RELATIONS"
    },
    {
      "case_id": "291__rep4__S002__FIRST_SENTENCE",
      "local_id": "KNOWN_NURSE_EVENT_REQUERIED_AND_USED_FOR_ASOF_NAME_ALIGNMENT"
    },
    {
      "case_id": "377__rep1__S005__FIRST_SENTENCE",
      "local_id": "ALREADY_ADOPTED_WIFE_NAME_RECONFIRMED_AFTER_SIBLING_SUPPORT_RESTORED"
    }
  ],
  "relation": "N005与R2分别记，不能把一批多个Call叫一次返回联合补证；R2存在日期/独立来源增量，非必冗余。",
  "counterexamples": [
    "319新1晚回正确数值而更多查，管理者意图没有直接引述；291护士再查使用时间对照，不止重复文字。"
  ],
  "unresolved": "题问正式management意图与记者/评论不同，原新共有证据缺口。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 7,
    "not_observed_rollouts": 5,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 7,
    "not_observed_local_chain_occurrences": 5,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "291__rep4__S002__FIRST_SENTENCE",
      "319__rep2__S001__FIRST_SENTENCE",
      "377__rep1__S005__FIRST_SENTENCE"
    ],
    "question_ids": [
      "291",
      "319",
      "377"
    ]
  }
}
```

```json
{
  "id": "ROOT033_T5",
  "description": "明确核心井关系未证但以其他匹配形成接受并Formal断言该关系。",
  "links": [
    {
      "case_id": "673__rep1__S007__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "UNCONFIRMED_DEFINING_WELL_RELATION_OVERRIDDEN_BY_OTHER_MATCHES_AT_FORMAL"
    }
  ],
  "relation": "N008四支主方案，原同缺口也接受；不强称删除新增错误，不与有独立强核心证据仅辅助数字未知一律等同。",
  "counterexamples": [
    "新3真查仍缺；其他生平可能已经唯一定位Habba，为合理备用解释。"
  ],
  "unresolved": "主名正确但题设关系无证的质量边界交研究者。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 4,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "673__rep1__S007__TERMINAL_DROP_NO_ANCHOR"
    ],
    "question_ids": [
      "673"
    ]
  }
}
```

```json
{
  "id": "ROOT033_T6",
  "description": "末次外部取证是否有新增独立条件决定其省略解释。",
  "links": [
    {
      "case_id": "1046__rep2__S009__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "PREACCEPTED_IDENTITY_SUBMITTED_WITHOUT_NEW_DIRECT_COMPLEX_STRUCTURE_CORROBORATION"
    },
    {
      "case_id": "1046__rep2__S009__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "PREACCEPTED_COMPANY_RELATION_RECONFIRMATION_REBUILT_WITH_DIRECT_STRUCTURE_ADOPTION"
    }
  ],
  "relation": "新4N006主方案，前三R2重取但有结构直证增量。定义不变，P大集团间接支持与U直接千公司资金链区分。",
  "counterexamples": [
    "S007原U未补特定罪名不能按相同公司名套成功独立条件丢失；N009只重取已有目标关系且无新条件，不适此整个U。"
  ],
  "unresolved": "如果研究者认为P规模已足直接支持复杂结构，新4应改为补强省略备选；保留精确源句供裁定。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 4,
    "not_observed_rollouts": 4,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 4,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": true,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep2__S009__TERMINAL_DROP_NO_ANCHOR"
    ],
    "question_ids": [
      "1046"
    ]
  }
}
```


## unresolved

```json
{
  "case_id": "377__rep1__S005__FIRST_SENTENCE",
  "issue": "G172Token完整多项清单属于真实历史提取异常，不能修改运行后假装最小首句；独立病因未G给但整体接受补偿较强。"
}
```

```json
{
  "case_id": "673__rep1__S007__TERMINAL_DROP_NO_ANCHOR",
  "issue": "井关系无源与其他生平唯一性两种判断保留，Formal补写故事不能当真实新增证据。"
}
```

```json
{
  "case_id": "1046__rep2__S009__TERMINAL_DROP_NO_ANCHOR",
  "issue": "结构P间接规模与U直接链条的证据充分性界限；新4N006主备方案。"
}
```

```json
{
  "case_id": "1046__rep3__S003__FIRST_SENTENCE",
  "issue": "G未证事实/方向与自添人物关系相接，不能唯一归因删除；晚到证据被采用是持续错路线的反例。"
}
```

```json
{
  "case_id": "299__rep4__S002__FIRST_SENTENCE",
  "issue": "原时间推算已有错，新1/3/4又不同日期推算，不据四C判断年份解释全部正确。"
}
```


## 限制
A全C不是为了凑数量选定结果；Stage/题/原轨迹/续跑程序去重。8FIRST与2G0分开，CHAR两案不伪造精确生成节省。多个同题不同P不当独立题或可相加节省，机械验证不是独立人工语义验收。