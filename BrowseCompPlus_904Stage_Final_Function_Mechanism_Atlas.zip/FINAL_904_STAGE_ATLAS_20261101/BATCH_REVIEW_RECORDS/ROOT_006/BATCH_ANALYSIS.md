# ROOT_006 批次归纳

10 Stage / 10题 / 10原轨迹 / 40续跑；组别{'A': 5, 'B': 5}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "从尚无对象到获得具体候选资料并使后续可以核验身份或提取所求属性。",
  "members": [
    "688__rep1__S002__FIRST_SENTENCE",
    "1095__rep1__S001__FIRST_SENTENCE",
    "1096__rep1__S001__FIRST_SENTENCE",
    "625__rep1__S001__FIRST_SENTENCE",
    "784__rep4__S001__FIRST_SENTENCE",
    "1138__rep3__S001__FIRST_SENTENCE"
  ],
  "distinction": "688沿旧球队偏向五查最后才返回人物，采用在Z；1095一次有较全身份，1096两次有词表；625原正确分作者/影响者，784原未窄化男性祖辈；1138首三并行仅证书查提供公司。多数新真实重建，G有无给实体须分。"
}
```

```json
{
  "description": "先定位一条具体证据入口，为其它独立线索随后识别所求主体提供辅助定位。",
  "members": [
    "1023__rep3__S001__FIRST_SENTENCE"
  ],
  "distinction": "U找到电影而非饰物，身份实际来自协会；替代入口可绕过U电影产品但不保证完整广告证据和提交。"
}
```

```json
{
  "description": "已有候选冲突后再查旧对象的一项具体关系，失败反馈后才转新入口。",
  "members": [
    "980__rep2__S003__FIRST_SENTENCE"
  ],
  "distinction": "P已知旧片主演年代不符，U又查Danny争端但无新正确产品；G把转印度方向提前，四新不再该旧Query。不能将全部失败取证等同原没作用。"
}
```

```json
{
  "description": "直接所求数值已采用后，反复查身份背景不配并交叉事故，仍未取得新身份。",
  "members": [
    "319__rep1__S008__FIRST_SENTENCE"
  ],
  "distinction": "正确数字已在P，多次取证未闭背景，原最终接受在Z。三N不是人数事实丢失。"
}
```

```json
{
  "description": "不充分识别已经当作前提后，继续核其属性和调查条件，却没有改正身份。",
  "members": [
    "592__rep1__S004__FIRST_SENTENCE"
  ],
  "distinction": "P已误读引语选Marcos，U十Call仍不成全关系，原也N；四新较早正式W不是失去原正确总统。"
}
```


## comparisons

```json
{
  "id": "ROOT006_C1",
  "cases": [
    "1095__rep1__S001__FIRST_SENTENCE",
    "1096__rep1__S001__FIRST_SENTENCE",
    "625__rep1__S001__FIRST_SENTENCE",
    "784__rep4__S001__FIRST_SENTENCE",
    "1138__rep3__S001__FIRST_SENTENCE"
  ],
  "finding": "相似初始发现U既可A稳定、C退化也可N改善，不能用分组代功能。各支具体发现多恢复，差异在后续约束归属/证据覆盖/剩余缺口与提交。625/784 G给动画或人物而1095/1096只有感叹词，不能将组间结果当同干预条件的纯比较。",
  "counter": "625正确分角色的新2也N；784修复祖辈的新1仍卡导演N；1138同公司恢复新1仍N。功能重建不是结果充分条件。"
}
```

```json
{
  "id": "ROOT006_C2",
  "cases": [
    "625__rep1__S001__FIRST_SENTENCE",
    "784__rep4__S001__FIRST_SENTENCE",
    "1096__rep1__S001__FIRST_SENTENCE",
    "980__rep2__S003__FIRST_SENTENCE"
  ],
  "finding": "题目约束改写能制造具体工作：625影响者出生年移到当前作者；784任一外祖辈窄成男性；1096现象的既有框架被当目标文章必需方法；980截至时间收窄当月新闻。这些都能定位到新真实Query，而非只在摘要贴错绑。",
  "counter": "不能把所有后续核验算伪任务：625台词真实未解，784导演真实未解，1096完整对比段确未回，980其它支含November不独证同误读。"
}
```

```json
{
  "id": "ROOT006_C3",
  "cases": [
    "1095__rep1__S001__FIRST_SENTENCE",
    "1023__rep3__S001__FIRST_SENTENCE",
    "1138__rep3__S001__FIRST_SENTENCE"
  ],
  "finding": "少一次独立查询可以有不同来源：1095新3首Call真联合覆盖纪录片，而新1/2只是未核/错归来源；1023新3/4电影与协会真联合执行，仍未完整广告；1138新3首批真得合同但无期限/指标。",
  "counter": "多资料联合获得不保证所有约束齐，不能以1Call或批量就断完整效率提升；1023新4还真实再查机器。"
}
```

```json
{
  "id": "ROOT006_C4",
  "cases": [
    "688__rep1__S002__FIRST_SENTENCE",
    "319__rep1__S008__FIRST_SENTENCE",
    "1023__rep3__S001__FIRST_SENTENCE",
    "1138__rep3__S001__FIRST_SENTENCE"
  ],
  "finding": "N的实际过程不一：688新1未取Ike后末轮纯计划重复；319新1/4已有数字但状态复述无Call，新2真重复Search；1023新2帽针已采用却广告重复十九Call；1138新1公司已采用却两值双查。",
  "counter": "不得统一写搜索循环或没有候选；每案第一判断/真实行动/终态和成本不同，原U也可能无新增独特产品。"
}
```

```json
{
  "id": "ROOT006_C5",
  "cases": [
    "592__rep1__S004__FIRST_SENTENCE",
    "1138__rep3__S001__FIRST_SENTENCE",
    "784__rep4__S001__FIRST_SENTENCE",
    "319__rep1__S008__FIRST_SENTENCE"
  ],
  "finding": "未闭条件转提交可得到不同质量：592错总统日期真但身份错四W；1138公司对但指标仍无证三C；784新3姓名对但导演未证，新4真补导演；319新3数字有P直接支持但背景仍缺。",
  "counter": "有限提交不是自动错误，也不是自动全质量满足；要记录所求属性直接有据、身份和辅助条件支持分别怎样。"
}
```

```json
{
  "id": "ROOT006_C6",
  "cases": [
    "980__rep2__S003__FIRST_SENTENCE",
    "688__rep1__S002__FIRST_SENTENCE",
    "784__rep4__S001__FIRST_SENTENCE"
  ],
  "finding": "错误中间判断可以被后证或题意重读截断：980新2/4错片Query仍真实回Dosti后采用；688新3算错星座仍被来源标签约束继续Ike；784早晚重读grandparents改变丈夫任务。",
  "counter": "不要求所有成功来自完全合理Query，也不将出现一次错误当必败；修复后仍可因另真实缺口N。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT006_T1",
  "description": "真实返回改变具体查询对象，能够恢复候选路线；但来源实体已见与真实行动仍分开，错误Query也可偶然回正确材料。",
  "links": [
    {
      "case_id": "688__rep1__S002__FIRST_SENTENCE",
      "local_id": "RETURNED_PLAYER_OVERRIDES_TEAM_QUERY_RESTRICTION"
    },
    {
      "case_id": "980__rep2__S003__FIRST_SENTENCE",
      "local_id": "PERSON_RELATION_USED_IN_REAL_QUERY_FINDS_MOVIE"
    }
  ],
  "relation": "继续P2_R1显式转换；688新1没取Ike排除材料同等对照，980新2/4不走具名关系发现入口为反例，不算同正链。",
  "counterexamples": [
    "688新4恢复却生成/Prompt更多；980新3具名转换迟仍更贵。",
    "980新2/4错片Query真正回Dosti后仍C，关系Query不是唯一取得正确片方法。"
  ],
  "unresolved": "转换存在不唯一解释终态或因果，G方向/召回差别需保留。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 5,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 1,
    "observed_local_chain_occurrences": 5,
    "not_observed_local_chain_occurrences": 2,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 1,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "688__rep1__S002__FIRST_SENTENCE",
      "980__rep2__S003__FIRST_SENTENCE"
    ],
    "question_ids": [
      "688",
      "980"
    ]
  }
}
```

```json
{
  "id": "ROOT006_T2",
  "description": "原题约束被转移主体或人为窄化，已有材料被视为不足，继而派发题目本未要求的真实子任务。",
  "links": [
    {
      "case_id": "625__rep1__S001__FIRST_SENTENCE",
      "local_id": "INFLUENCER_BIRTH_CONSTRAINT_ASSIGNED_TO_CURRENT_AUTHOR"
    },
    {
      "case_id": "784__rep4__S001__FIRST_SENTENCE",
      "local_id": "MATERNAL_GRANDPARENT_NARROWED_TO_MALE_CREATES_HUSBAND_TASK"
    }
  ],
  "relation": "新增细候选：625新3/4生日任务和784新2丈夫任务有明确题面反证/真实Call。784新3错说男性但实际第四Call仍查祖母年份，存在合理1919/1937矛盾核查，不计完整丈夫任务正支持。不把1096全部理论检查纳入，因为完整段确缺而有合理核验目的。",
  "counterexamples": [
    "625新2正确角色仍因台词未闭N，错绑非全部失败必要条件。",
    "784新1允许祖母仍导演N，新2晚解除限制仍C，新3实际未展开丈夫搜索，不能只凭错词/计划算机制已执行。"
  ],
  "unresolved": "任务变化明确，但不能将全部Token或结局归一个伪缺口；G给未来实体和其它真实缺口同时存在。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 3,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 1,
    "excluded_rollouts": 1,
    "observed_local_chain_occurrences": 3,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 1,
    "excluded_local_chain_occurrences": 1,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "625__rep1__S001__FIRST_SENTENCE",
      "784__rep4__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "625",
      "784"
    ]
  }
}
```

```json
{
  "id": "ROOT006_T3",
  "description": "同样已知核心对象/属性与剩余缺口，实际可选择继续真实取证、有限提交或无动作的状态复述；要按实际执行而非词语计工作。",
  "links": [
    {
      "case_id": "319__rep1__S008__FIRST_SENTENCE",
      "local_id": "KNOWN_NUMBER_BACKGROUND_GAP_REOPENS_REAL_SEARCH"
    },
    {
      "case_id": "1023__rep3__S001__FIRST_SENTENCE",
      "local_id": "ADOPTED_ACCESSORY_UNCLOSED_ADVERTISEMENT_CONTINUES_SEARCH"
    },
    {
      "case_id": "1138__rep3__S001__FIRST_SENTENCE",
      "local_id": "COMPANY_RESTORED_MISSING_VALUES_CONTINUE_OR_ALLOW_SUBMISSION"
    }
  ],
  "relation": "检验P2_R3不同下游实现，但观察方向不同：319/1023链接正支为继续核验，1138链接正支为转有限提交；统计必须保留local_id及含义，不能将一个总OBSERVED数解释成同向效果。",
  "counterexamples": [
    "319两支纯复述不是实际Search；1023新1/3/4提交但广告仍缺；1138三CFinal夸大未证指标。"
  ],
  "unresolved": "不能把该上位比较叫一个停止阈值机制，须追触发的具体任务和证据充分性。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 5,
    "not_observed_rollouts": 7,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 5,
    "not_observed_local_chain_occurrences": 7,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1023__rep3__S001__FIRST_SENTENCE",
      "1138__rep3__S001__FIRST_SENTENCE",
      "319__rep1__S008__FIRST_SENTENCE"
    ],
    "question_ids": [
      "319",
      "1023",
      "1138"
    ]
  }
}
```

```json
{
  "id": "ROOT006_T4",
  "description": "本可由同次实际返回或联合批次获得的多个证据需求，减少原逐轮取证；未获得却提前猜填的低成本必须分开。",
  "links": [
    {
      "case_id": "1095__rep1__S001__FIRST_SENTENCE",
      "local_id": "ONE_RETURN_COVERS_IDENTITY_AND_SPECIFIC_DOCUMENTARY_RELATION"
    },
    {
      "case_id": "1023__rep3__S001__FIRST_SENTENCE",
      "local_id": "JOINT_EVIDENCE_BATCH_RESTORES_WORK_WITH_FEWER_ACTOR_ROUNDS"
    },
    {
      "case_id": "1138__rep3__S001__FIRST_SENTENCE",
      "local_id": "INITIAL_CONTRACT_QUERY_ALSO_PROVIDES_TARGET_COMPANY_RELATION"
    }
  ],
  "relation": "与ROOT005已有返回覆盖/批次组织提案关联；单Call多文档与单轮多Call两子方式分别记录，非同一计数单位。",
  "counterexamples": [
    "1095其它一Call支直接证据更弱；1023新1批量却Search更多、新4机器重复；1138同批多得合同也没有期限/财务值。"
  ],
  "unresolved": "不将独立分支节省相加，也不把少Actor推成少实际工作。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 4,
    "not_observed_rollouts": 7,
    "uncertain_rollouts": 1,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 7,
    "uncertain_local_chain_occurrences": 1,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1023__rep3__S001__FIRST_SENTENCE",
      "1095__rep1__S001__FIRST_SENTENCE",
      "1138__rep3__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1023",
      "1095",
      "1138"
    ]
  }
}
```

```json
{
  "id": "ROOT006_T5",
  "description": "目标Stage的具体证据入口未再执行，但其它独立线索/教师方向可完成候选定位；省量不能全归目标功能无用。",
  "links": [
    {
      "case_id": "980__rep2__S003__FIRST_SENTENCE",
      "local_id": "WRONG_MOVIE_QUERY_RETURNS_USABLE_CORRECT_CANDIDATE"
    },
    {
      "case_id": "1023__rep3__S001__FIRST_SENTENCE",
      "local_id": "SOCIETY_ENTRY_IDENTIFIES_ACCESSORY_WITHOUT_MOVIE_RECOVERY"
    }
  ],
  "relation": "不同替代机制对照：980原旧导演查询被印度路径替代、1023电影定位被协会身份替代。不得将它们合成单一反事实可省结论。",
  "counterexamples": [
    "1023新2替代主体发现仍N；980错Query得到C不证明错误策略可靠。",
    "两者G都提供方向，不能宣称无提示纯删。"
  ],
  "unresolved": "旧失败反馈在无G是否仍会促进转向未知；完整广告关联未证。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 4,
    "not_observed_rollouts": 4,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 4,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1023__rep3__S001__FIRST_SENTENCE",
      "980__rep2__S003__FIRST_SENTENCE"
    ],
    "question_ids": [
      "980",
      "1023"
    ]
  }
}
```

```json
{
  "id": "ROOT006_T6",
  "description": "无动作的长期状态/策略复述增加生成Token，却不等真实取证次数；原U实际Call与新纯文本实现需分开。",
  "links": [
    {
      "case_id": "688__rep1__S002__FIRST_SENTENCE",
      "local_id": "UNRESOLVED_PLAYER_SEARCH_BECOMES_UNEXECUTED_STRATEGY_REPETITION"
    },
    {
      "case_id": "319__rep1__S008__FIRST_SENTENCE",
      "local_id": "CONFIRMED_ANSWER_AND_UNMATCHED_CONTEXT_REPLAY_WITHOUT_ACTION"
    }
  ],
  "relation": "两题相同执行形式，但688没取得具体球员，319已有数字且背景未配，触发前态不同。先记录两子链，不以重复字串命名代替起因。",
  "counterexamples": [
    "319新2真查仍N、新3零Call提交C；688另外三支真资料推进。重复不执行与不搜直接答不能混。"
  ],
  "unresolved": "内部为何停在复述无唯一证据；319两份同IDs不同声明seed仅留事实，不自行推缓存故障。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 3,
    "not_observed_rollouts": 5,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 3,
    "not_observed_local_chain_occurrences": 5,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "319__rep1__S008__FIRST_SENTENCE",
      "688__rep1__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "319",
      "688"
    ]
  }
}
```

```json
{
  "id": "ROOT006_T7",
  "description": "不充分身份已作为前提后，验证其真实属性会强化错误对象答案；其它不符被相似化或跨主体拼接而非限制接受。",
  "links": [
    {
      "case_id": "592__rep1__S004__FIRST_SENTENCE",
      "local_id": "UNVERIFIED_PRESIDENT_IDENTITY_TURNS_TASK_INTO_DATE_CONFIRMATION"
    },
    {
      "case_id": "592__rep1__S004__FIRST_SENTENCE",
      "local_id": "NONMATCHING_QUOTE_RELAXED_TO_SIMILAR_CONCEPT"
    },
    {
      "case_id": "592__rep1__S004__FIRST_SENTENCE",
      "local_id": "CANDIDACY_AND_DEATH_ASSIGNED_TO_DIFFERENT_PEOPLE_BUT_CHAIN_ACCEPTED"
    }
  ],
  "relation": "本批只有一题，不将三个local链算三题；与前批固定不充分候选→补属性方向相比较，保留识别原话、身份与所求日期三层。",
  "counterexamples": [
    "原也错对象未提交N，新四W不是丢失原正确产品；新2未明确相似化不强标，新1时间矛盾也不等新3已分两人仍接受。"
  ],
  "unresolved": "G提前足够作答框架可能影响停止，不能从少8Search推可靠冗余。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 4,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 3,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 8,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 4,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": true,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "592__rep1__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "592"
    ]
  }
}
```

```json
{
  "id": "ROOT006_T8",
  "description": "题目要求或推论在复盘中被移成已经证实事实，使待核条件不再阻止提交；须有连续缺证与无新值采用证据。",
  "links": [
    {
      "case_id": "1138__rep3__S001__FIRST_SENTENCE",
      "local_id": "UNVERIFIED_DURATION_UPGRADED_TO_ESTABLISHED_WITHOUT_RETURN"
    },
    {
      "case_id": "1023__rep3__S001__FIRST_SENTENCE",
      "local_id": "INFERRED_ACCESSORY_ADVERTISING_LINK_RESTATED_AS_GIVEN"
    }
  ],
  "relation": "新候选的两个不同子过程：1138未知期限成已知，1023由协会推出对象被称题目给广告。只做上位比较，尚不统一为同一细规则。",
  "counterexamples": [
    "1138新1同缺值仍一直查N；1023新2同核心已知仍继续广告N；不能从已知核心直接推都会抹去缺口。"
  ],
  "unresolved": "若将来合并定义须回查旧映射；当前不自动扩写或批量修改既有标签。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 2,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 2,
    "excluded_rollouts": 1,
    "observed_local_chain_occurrences": 2,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 2,
    "excluded_local_chain_occurrences": 1,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1023__rep3__S001__FIRST_SENTENCE",
      "1138__rep3__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1023",
      "1138"
    ]
  }
}
```


## unresolved

```json
{
  "case_id": "688__rep1__S002__FIRST_SENTENCE",
  "issue": "新1没取Ike不能当已返未用；奥运次数原新支持不足，末轮纯计划原因未知。"
}
```

```json
{
  "case_id": "980__rep2__S003__FIRST_SENTENCE",
  "issue": "G转印度补方向；另片Query可意外取正确片，不能按Query匹配代机制。"
}
```

```json
{
  "case_id": "1023__rep3__S001__FIRST_SENTENCE",
  "issue": "广告和Ruby关联仍缺，名字C与完整证据质量不同；新2正确主体不等正式提交。"
}
```

```json
{
  "case_id": "1095__rep1__S001__FIRST_SENTENCE",
  "issue": "新3一Call确覆盖纪录片，而其它两一Call没有；新增学校年/节目错归来源不被主名C掩盖。"
}
```

```json
{
  "case_id": "1096__rep1__S001__FIRST_SENTENCE",
  "issue": "完整SFL段未回，不能全把理论核查当伪任务；新4高成本主要会议入口不合。"
}
```

```json
{
  "case_id": "625__rep1__S001__FIRST_SENTENCE",
  "issue": "协议支排除认知机制；两错出生归属与一正确归属均N，台词实际未证且G补候选。"
}
```

```json
{
  "case_id": "319__rep1__S008__FIRST_SENTENCE",
  "issue": "U无新身份知识却三N，实际形式分纯复述/真重查；不补唯一必要判断，两同IDs源保留。"
}
```

```json
{
  "case_id": "784__rep4__S001__FIRST_SENTENCE",
  "issue": "祖母1919/1937矛盾有合理核验需求，男性附加限制另列；新3未闭导演有限答与新4有直接支持不同。"
}
```

```json
{
  "case_id": "1138__rep3__S001__FIRST_SENTENCE",
  "issue": "三C均未真实得到期限/135%，Final过度确认；新4最后意向没Call，Altne来源不明。"
}
```

```json
{
  "case_id": "592__rep1__S004__FIRST_SENTENCE",
  "issue": "引语原为反驳inept指控，调查只见摘要，错误总统P早存在；四W不等正确性退化。"
}
```


## 限制
本批十题各一Stage，但319与上批同题不同切点，不加作新增独立题；机制每条按显式成员去重。四支结果/支持质量/功能/成本分开，正向或对照的观察方向保留local定义，不能拿OBSERVED总数冒充同向因果效应。全部为Codex审阅，非研究者人工金标准。