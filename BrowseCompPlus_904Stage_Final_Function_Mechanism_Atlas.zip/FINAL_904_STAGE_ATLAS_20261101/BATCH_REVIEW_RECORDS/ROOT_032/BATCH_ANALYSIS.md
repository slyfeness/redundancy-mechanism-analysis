# ROOT_032 批次归纳

10 Stage / 6题 / 7原轨迹 / 40续跑；组别{'A': 10}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "未知对象的首次发现/材料采用。",
  "members": [
    "291__rep4__S001__FIRST_SENTENCE",
    "299__rep4__S001__FIRST_SENTENCE"
  ],
  "distinction": "童星U从护士Return真得答案名，G先给该名；建筑U四次才有Baron入口，G只给promising框架。两个空P切点不因四C当自主发现消失。"
}
```

```json
{
  "description": "已有具体数值但餐馆背景仍不配时，最后一次重查错误候选事故。",
  "members": [
    "319__rep1__S009__FIRST_SENTENCE"
  ],
  "distinction": "U真实RedRobin事故查询没补正确背景，数字已P；新三有限提交、一同轮不执行计划循环N，目标不恢复与结果稳定不是充分关联。"
}
```

```json
{
  "description": "为已采用身份首次取得具体所问关系或独立识别条件。",
  "members": [
    "377__rep1__S004__FIRST_SENTENCE",
    "1046__rep1__S006__FIRST_SENTENCE",
    "1046__rep2__S006__FIRST_SENTENCE"
  ],
  "distinction": "妻子姓名P无且U直接题问答案；公司名P已对但U另补早年定罪并纠正日期。事实存在、具体罪名、准确确认年不能混为一项全完成。"
}
```

```json
{
  "description": "材料到条件采用、充分性判断或已接受之后的再次认知复核。",
  "members": [
    "353__rep3__S005__TERMINAL_DROP_NO_ANCHOR",
    "1046__rep1__S005__FIRST_SENTENCE",
    "1046__rep1__S007__TERMINAL_DROP_NO_ANCHOR",
    "1046__rep2__S005__FIRST_SENTENCE"
  ],
  "distinction": "书作者已采用但MSc年未知；公司S005材料刚返尚未逐条件用、rep2还错1995/1974；公司末S007最后定罪也已明确采用。同叫比较，P状态不同不能合并解释。"
}
```


## comparisons

```json
{
  "id": "ROOT032_C1",
  "cases": [
    "291__rep4__S001__FIRST_SENTENCE",
    "299__rep4__S001__FIRST_SENTENCE"
  ],
  "finding": "空P相同却G补偿不同：童星给未来Baha答案名，定向/批量核查恢复；建筑没有人名只说首结果好，四先虚构已有结果，1/3/4假对象进Call，随后真材料改变行动后C。",
  "counter": "建筑不是零工具假源后直接Formal的N002；童星新3仍宽事件再采用，不能说四支从不重做发现。"
}
```

```json
{
  "id": "ROOT032_C2",
  "cases": [
    "377__rep1__S004__FIRST_SENTENCE",
    "1046__rep1__S006__FIRST_SENTENCE",
    "319__rep1__S009__FIRST_SENTENCE"
  ],
  "finding": "同A少查有三种不同信息后果：妻名四全恢复、省的是原Z确认；定罪一支未恢复原U成功补的独立条件；餐馆U原就没补背景、数字早已P。",
  "counter": "不能统一称省掉无用查证；定罪少了题需条件支持，妻名是必要产品重建，原失败尝试取消又不同。"
}
```

```json
{
  "id": "ROOT032_C3",
  "cases": [
    "353__rep3__S005__TERMINAL_DROP_NO_ANCHOR",
    "1046__rep1__S007__TERMINAL_DROP_NO_ANCHOR",
    "1046__rep1__S005__FIRST_SENTENCE"
  ],
  "finding": "书P已提取采用作者但年未知，四全恢复比较且一真实查两次；公司S005仅发现反馈不等比较做完，四首Call前重建；公司末P全条件已采用，一支Reasoning只查末条但Final全列。",
  "counter": "不能说所有已知候选之后的清单都没用，也不能只看短Reasoning宣称整体组织未执行。N009外部重取不可套纯认知U。"
}
```

```json
{
  "id": "ROOT032_C4",
  "cases": [
    "1046__rep1__S005__FIRST_SENTENCE",
    "1046__rep1__S006__FIRST_SENTENCE",
    "1046__rep1__S007__TERMINAL_DROP_NO_ANCHOR",
    "1046__rep2__S005__FIRST_SENTENCE",
    "1046__rep2__S006__FIRST_SENTENCE"
  ],
  "finding": "同一公司不同切点显示材料可见→逐项采用→独立定罪支持→全局接受已完成四种状态，G同含核验/复盘词不能按相同口吻统一判断补偿。",
  "counter": "同题五Stage仅一题、两原轨迹；不同P/seed/切点不能当随机控制或叠加省量。"
}
```

```json
{
  "id": "ROOT032_C5",
  "cases": [
    "1046__rep2__S005__FIRST_SENTENCE",
    "1046__rep2__S006__FIRST_SENTENCE",
    "353__rep3__S005__TERMINAL_DROP_NO_ANCHOR"
  ],
  "finding": "候选完全恢复后，未证具体罪名或毕业年仍可驱动多次真实查询，最终用其它关系/一般推定接受。书三不查一两查；公司同首Call/Doc后总3/4/5/6等不同，差异不在是否知道公司名。",
  "counter": "公司新3真正结构补证有增量，不能将全部多查判低收益；原路径特定bribery也未直证，不全归删除新增。"
}
```

```json
{
  "id": "ROOT032_C6",
  "cases": [
    "1046__rep2__S006__FIRST_SENTENCE",
    "1046__rep1__S006__FIRST_SENTENCE"
  ],
  "finding": "同一59447材料可以准确采用2014确认，也可长引后误2009。rep2S006新2转公司源解日期/结构、新3额外真结构查，并不是同一未变任务的纯重试。",
  "counter": "同Doc/同Query不等同解释；主名全C不等精确细节无误。没有足够证据把所有变化归一个信心阈值。"
}
```

```json
{
  "id": "ROOT032_C7",
  "cases": [
    "319__rep1__S009__FIRST_SENTENCE",
    "353__rep3__S005__TERMINAL_DROP_NO_ANCHOR",
    "377__rep1__S004__FIRST_SENTENCE",
    "1046__rep1__S006__FIRST_SENTENCE"
  ],
  "finding": "四C/W/N中实际动作不能用计划替：餐馆2不Call计划到长度停，3同样意向却Formal；书2说核其它书但无Call，妻子3提再证未执行，公司定罪3说需verify仍无Call。",
  "counter": "餐馆正确数值没有Formal是真N，其他实际C也不等未证条件被解决；意向是认知文本，不是实际Search或独立证据产品。"
}
```

```json
{
  "id": "ROOT032_C8",
  "cases": [
    "291__rep4__S001__FIRST_SENTENCE",
    "377__rep1__S004__FIRST_SENTENCE",
    "1046__rep1__S006__FIRST_SENTENCE",
    "1046__rep1__S007__TERMINAL_DROP_NO_ANCHOR"
  ],
  "finding": "少消耗有不同落点：童星1同批两Call少Actor不减Search，妻子三取消Z再姓名确认，公司定罪2同功能较短，公司末3少显式推理清单但Final全列。",
  "counter": "妻子1生成+1、4Prompt增；公司定罪3少查但支持缺失、末2短13却新错确认年；不按单指标泛称冗余。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT032_T1",
  "description": "保留身份锚重新取得并采用原U缺失关系。",
  "links": [
    {
      "case_id": "377__rep1__S004__FIRST_SENTENCE",
      "local_id": "RETAINED_BEKO_IDENTITY_REACQUIRES_AND_USES_MISSING_WIFE_NAME"
    },
    {
      "case_id": "1046__rep1__S006__FIRST_SENTENCE",
      "local_id": "RETAINED_COMPANY_ANCHOR_REACQUIRES_INDEPENDENT_CONVICTION_SUPPORT"
    },
    {
      "case_id": "1046__rep2__S006__FIRST_SENTENCE",
      "local_id": "RETAINED_COMPANY_ANCHOR_REBUILDS_REAL_CONVICTION_CHECK_AND_CONDITION_UPDATE"
    }
  ],
  "relation": "P1_K2三Stage/两题；身份已有但目标关系未证，A稳定多数依功能重建。",
  "counterexamples": [
    "公司rep1新3没重建仍主名C但独立条件少；妻子全部重建而后续确认/费用不同。"
  ],
  "unresolved": "法律首名依据文章顺序、具体bribery与corruption区别不能由主名正确代过。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 2,
    "original_runs": 3,
    "observed_rollouts": 11,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 11,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep1__S006__FIRST_SENTENCE",
      "1046__rep2__S006__FIRST_SENTENCE",
      "377__rep1__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "377",
      "1046"
    ]
  }
}
```

```json
{
  "id": "ROOT032_T2",
  "description": "证据材料进入具体真实查询对象，随后条件比较可恢复。",
  "links": [
    {
      "case_id": "299__rep4__S001__FIRST_SENTENCE",
      "local_id": "REAL_BUILDING_RETURN_REPLACES_FABRICATED_LEAD_AND_DISPATCHES_PERSON_CHECK"
    },
    {
      "case_id": "1046__rep2__S005__FIRST_SENTENCE",
      "local_id": "RETURNED_BENKO_SELECTED_IN_REAL_CALL_BEFORE_FULL_CONDITION_COMPARISON"
    }
  ],
  "relation": "P2_R1两题，建筑实返后纠正假对象，公司先实际选择人名再比较，G不供该处新实体。",
  "counterexamples": [
    "公司新4仍错活动年，建筑错误LegionQuery也偶得真材料；桥不保证每个字段正确。"
  ],
  "unresolved": "部分动作方向来自G，检索召回不同也影响路径，不能认唯一局部因果。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 8,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 8,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep2__S005__FIRST_SENTENCE",
      "299__rep4__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "299",
      "1046"
    ]
  }
}
```

```json
{
  "id": "ROOT032_T3",
  "description": "正确核心下独立未证条件驱动真实核验，实例可增可减。",
  "links": [
    {
      "case_id": "353__rep3__S005__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "CORRECT_AUTHOR_UNVERIFIED_MSC_YEAR_REACTIVATES_REAL_VERIFICATION"
    },
    {
      "case_id": "1046__rep1__S005__FIRST_SENTENCE",
      "local_id": "CORRECT_COMPANY_CORE_UNPROVEN_CONVICTION_DISPATCHES_REAL_CHECK"
    },
    {
      "case_id": "1046__rep2__S005__FIRST_SENTENCE",
      "local_id": "ACCEPTED_COMPANY_SPECIFIC_BRIBERY_GAP_PERSISTS_THROUGH_REAL_CHECKS"
    },
    {
      "case_id": "1046__rep2__S006__FIRST_SENTENCE",
      "local_id": "SPECIFIC_BRIBERY_GAP_REDISPATCHES_TRUE_CHECK_AFTER_CORRUPTION_SUPPORT"
    }
  ],
  "relation": "P2_R3四Stage/两题，同公司多个切点非多题。",
  "counterexamples": [
    "书另三同年缺口不查；公司rep1S006一支不查仍名C但丢独立支持；公司结构查有真实新增支持不能全归无效重复。"
  ],
  "unresolved": "未闭条件不是持续取证的充分条件，最后一般推定接受缺直接罪名支撑，停止原因不可唯一确定。",
  "deterministic_counts": {
    "observed_stage_count": 4,
    "different_questions": 2,
    "original_runs": 3,
    "observed_rollouts": 12,
    "not_observed_rollouts": 4,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 12,
    "not_observed_local_chain_occurrences": 4,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 16,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep1__S005__FIRST_SENTENCE",
      "1046__rep2__S005__FIRST_SENTENCE",
      "1046__rep2__S006__FIRST_SENTENCE",
      "353__rep3__S005__TERMINAL_DROP_NO_ANCHOR"
    ],
    "question_ids": [
      "353",
      "1046"
    ]
  }
}
```

```json
{
  "id": "ROOT032_T4",
  "description": "已经获得并采用的关系仍被再次真实确认。",
  "links": [
    {
      "case_id": "377__rep1__S004__FIRST_SENTENCE",
      "local_id": "ALREADY_OBTAINED_WIFE_NAME_TRIGGERS_ANOTHER_REAL_MARRIAGE_CONFIRMATION"
    },
    {
      "case_id": "1046__rep1__S005__FIRST_SENTENCE",
      "local_id": "ALREADY_ADOPTED_COMPANY_OR_CONVICTION_FACTS_RECHECKED_AGAIN"
    },
    {
      "case_id": "1046__rep2__S005__FIRST_SENTENCE",
      "local_id": "ALREADY_ACCEPTED_RELATIONS_DISPATCH_ADDITIONAL_CONFIRMATION"
    }
  ],
  "relation": "P2_R2三Stage/两题；未知特定罪名与已采用具体关系重取分开。",
  "counterexamples": [
    "妻子另三取消确认仍C，1生成略增；公司独立年份/德文结构源有潜在佐证价值，不能按重取自动判无用。"
  ],
  "unresolved": "法律名核查没有独立法源；公司rep2S006日期冲突求证不强认全是已知重查。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 2,
    "original_runs": 3,
    "observed_rollouts": 6,
    "not_observed_rollouts": 6,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 6,
    "not_observed_local_chain_occurrences": 6,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep1__S005__FIRST_SENTENCE",
      "1046__rep2__S005__FIRST_SENTENCE",
      "377__rep1__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "377",
      "1046"
    ]
  }
}
```

```json
{
  "id": "ROOT032_T5",
  "description": "主体P已采用，原U新增的早年定罪支持新未补而主名正确；类别是否完整适用保留争议。",
  "links": [
    {
      "case_id": "1046__rep1__S006__FIRST_SENTENCE",
      "local_id": "PREACCEPTED_COMPANY_SUBMITTED_WITH_INDEPENDENT_CONVICTION_CRITERION_UNRESTORED"
    }
  ],
  "relation": "新3N006为UNC而非正例：原U直证corruption定罪、Z采用，但具体bribery并未直接证明，不能把独立条件分量当完整条件自动扩定义。证据丢失事实本身保留。",
  "counterexamples": [
    "餐馆原U失败不符合；书MSc原U没有查到确年不符合；妻名原U直接所求且四全恢复。"
  ],
  "unresolved": "G整体复盘可能推动停止；局部独立条件的分量是否纳N006需研究者裁，未改V007或宣称完整质量保持。",
  "deterministic_counts": {
    "observed_stage_count": 0,
    "different_questions": 0,
    "original_runs": 0,
    "observed_rollouts": 0,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 1,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 0,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 1,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [],
    "question_ids": []
  }
}
```

```json
{
  "id": "ROOT032_T6",
  "description": "一次真实Return联合供应原分开查的出生身份与护士事件。",
  "links": [
    {
      "case_id": "291__rep4__S001__FIRST_SENTENCE",
      "local_id": "ONE_TRUE_RETURN_JOINTLY_SUPPORTS_BIRTH_IDENTITY_AND_NURSE_EVENT"
    }
  ],
  "relation": "N005三支但G提前给答案名；1同批第二Call不省Search，2/4才少Search。",
  "counterexamples": [
    "3第二Return事件已知，不因共现再算两个未解需求同时关闭；不能由1同批结果虚构先看后查。"
  ],
  "unresolved": "候选/答案G关键补偿，金额与管理条件还缺精确解释，不列无泄漏严格可省。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 3,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 3,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "291__rep4__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "291"
    ]
  }
}
```

```json
{
  "id": "ROOT032_T7",
  "description": "无G已完成全部采用后，显式重复复核可以聚焦最后条件而Final组织保留。",
  "links": [
    {
      "case_id": "1046__rep1__S007__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "PREACCEPTED_FULL_EVIDENCE_PERMITS_FOCUSED_LAST_CONDITION_REVIEW_WITH_FULL_FINAL"
    }
  ],
  "relation": "开放一Stage一题一支，不套N009纯外部再取定义，不以Final完整列表推隐含思考完全省。",
  "counterexamples": [
    "另三仍全清单，其中两生成更长；书G0末段全部恢复且全更长。"
  ],
  "unresolved": "仅可说显式重复减少，认知是否内部省略不可观察。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 1,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 1,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep1__S007__TERMINAL_DROP_NO_ANCHOR"
    ],
    "question_ids": [
      "1046"
    ]
  }
}
```

```json
{
  "id": "ROOT032_T8",
  "description": "假源叙述进入真实检索与未执行计划循环，作为不同开放链保留。",
  "links": [
    {
      "case_id": "299__rep4__S001__FIRST_SENTENCE",
      "local_id": "NONEXISTENT_RETURN_NARRATIVE_SHAPES_ACTUAL_QUERY_BEFORE_TRUE_DISCOVERY"
    },
    {
      "case_id": "319__rep1__S009__FIRST_SENTENCE",
      "local_id": "UNRESOLVED_IDENTITY_GAP_REPEATEDLY_REACTIVATES_UNEXECUTED_PLANS"
    }
  ],
  "relation": "前者虚构对象→真Call→后真证纠正，后者缺口→意向→重复旧状态→无Call长度止；不是同一种重复搜索。",
  "counterexamples": [
    "建筑2也假源但不查假对象；餐馆3也有未执行意向却能Formal。前批980r4S1新2有相同单轮无Call重计划作为第二题候选支持，未未经逐例比对自动注册。"
  ],
  "unresolved": "G成功框架/采样与模型为何不发工具尚不能唯一解释，不强套N002或真实返回循环K3。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 4,
    "not_observed_rollouts": 4,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 4,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "299__rep4__S001__FIRST_SENTENCE",
      "319__rep1__S009__FIRST_SENTENCE"
    ],
    "question_ids": [
      "299",
      "319"
    ]
  }
}
```


## unresolved

```json
{
  "case_id": "291__rep4__S001__FIRST_SENTENCE",
  "issue": "关键未来答案Baha引导、母亲管理无直接证、450索取与150实际区分、学校归属误扩。"
}
```

```json
{
  "case_id": "299__rep4__S001__FIRST_SENTENCE",
  "issue": "空P假源后实际错误对象查询，随后纠正全C；不能因最终正确抹掉来源错误或把G当直接给假实体。"
}
```

```json
{
  "case_id": "319__rep1__S009__FIRST_SENTENCE",
  "issue": "正确数字已P、一支无Call重复计划N，强独特事故是否足以给限定答案的N008主备方案保留。"
}
```

```json
{
  "case_id": "1046__rep1__S006__FIRST_SENTENCE",
  "issue": "一支未恢复真实定罪支持，不能把charges替conviction或C当完整质量；另三实际恢复但时间解释不同。"
}
```

```json
{
  "case_id": "1046__rep1__S007__TERMINAL_DROP_NO_ANCHOR",
  "issue": "新3Reasoning短核但Final全列，不能声称认知完全不做；新2推理2014却Final2010。"
}
```

```json
{
  "case_id": "1046__rep2__S006__FIRST_SENTENCE",
  "issue": "3结构查实际有补强，新增成本不全无效；具体bribery始终未直证，原也缺，多个Stage同题不当独立支持。"
}
```


## 限制
按冻结身份程序复算Stage/题/原轨迹/续跑，全部A不人为补B。FIRST与G0分开，CHAR一例不算伪精确生成；独立删支节省不相加，同题多切点不视随机控制或独立题。证据引用/统计PASS不是研究者人工语义金标准。