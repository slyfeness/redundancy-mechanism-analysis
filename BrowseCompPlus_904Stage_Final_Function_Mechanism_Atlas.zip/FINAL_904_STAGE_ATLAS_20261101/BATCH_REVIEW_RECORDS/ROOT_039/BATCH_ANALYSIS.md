# ROOT_039 批次归纳

10 Stage / 3题 / 5原轨迹 / 40续跑；组别{'A': 10}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "已有核心候选后首次取独立条件直接证据，或持续尝试但未取到。",
  "members": [
    "1096__rep4__S005__FIRST_SENTENCE",
    "1138__rep2__S002__FIRST_SENTENCE",
    "1138__rep4__S002__FIRST_SENTENCE",
    "1239__rep3__S003__FIRST_SENTENCE"
  ],
  "distinction": "会议成功补参会、人口成功补132，与两个金融四/六查值仍不足不同；只有同一Search名称不等相同产物。"
}
```

```json
{
  "description": "补证完成或不足后实际展开整体接受、停止与答案组织。",
  "members": [
    "1239__rep2__S004__TERMINAL_DROP_NO_ANCHOR",
    "1096__rep4__S006__TERMINAL_DROP_NO_ANCHOR",
    "1138__rep2__S003__TERMINAL_DROP_NO_ANCHOR",
    "1138__rep4__S003__TERMINAL_DROP_NO_ANCHOR"
  ],
  "distinction": "前两新增人口/参会真证已到后认知收束，金融是承认缺135仍以两事件接受并Formal过称；不是无工具就无实际认知。"
}
```

```json
{
  "description": "初始入口获取与首次返回后的逐条件采用。",
  "members": [
    "1239__rep3__S001__FIRST_SENTENCE",
    "1239__rep3__S002__FIRST_SENTENCE"
  ],
  "distinction": "S1空P真实入口获取植物，S2材料已返但未采用的认知匹配；两切点不同，不把检索到/采用混为同已知状态。"
}
```


## comparisons

```json
{
  "id": "ROOT039_C1",
  "cases": [
    "1138__rep2__S002__FIRST_SENTENCE",
    "1138__rep4__S002__FIRST_SENTENCE"
  ],
  "finding": "同为查财务值，rep2新1持续16Call/13Actor到guard无Final，其它三正常提交；rep4新3零Call受G未来年报/接受框架后直接答，其它三查4/2/3次再交。主体都或多数C，取证执行和停止截然不同。",
  "counter": "原两U均未取得135，不把未恢复已知不存在的直接证明当新损失；rep4G带未有来源，rep2G只是公司接受姿态。"
}
```

```json
{
  "id": "ROOT039_C2",
  "cases": [
    "1096__rep4__S005__FIRST_SENTENCE",
    "1239__rep3__S003__FIRST_SENTENCE",
    "1138__rep4__S002__FIRST_SENTENCE"
  ],
  "finding": "未解条件继续驱动真实核查可成功获得参会/人口后停止，也可财务目录反复不足后直接接受；是否有实际新信息和如何进入接受是决定质量/消耗的可见中间环节。",
  "counter": "不是所有重试都没用，也不是最后接受主体就能称三项全核；同批多Call不能伪反馈。"
}
```

```json
{
  "id": "ROOT039_C3",
  "cases": [
    "1239__rep2__S004__TERMINAL_DROP_NO_ANCHOR",
    "1096__rep4__S006__TERMINAL_DROP_NO_ANCHOR",
    "1138__rep2__S003__TERMINAL_DROP_NO_ANCHOR",
    "1138__rep4__S003__TERMINAL_DROP_NO_ANCHOR"
  ],
  "finding": "四个末G0U都是真整体判断/组织，四新各完整重建且零新Call，主要是文字变短；金融rep2新3还更长。",
  "counter": "没有动作分歧就不编隐藏判断机制；同认知恢复可更省或更费，Prompt重放单列，不叫功能被取消。"
}
```

```json
{
  "id": "ROOT039_C4",
  "cases": [
    "1239__rep3__S001__FIRST_SENTENCE",
    "1239__rep3__S002__FIRST_SENTENCE",
    "1239__rep3__S003__FIRST_SENTENCE"
  ],
  "finding": "同一题不同切点：初入口新2两并发Call后略过人口，少Actor却Search不降；首次采用四都先认知后真实人口；人口U四都重查且生成更长。",
  "counter": "不能从主体C或同题Perfect推固定冗余，也不能将S1后继人口没做误归U本已获得的人口证据。"
}
```

```json
{
  "id": "ROOT039_C5",
  "cases": [
    "1138__rep2__S003__TERMINAL_DROP_NO_ANCHOR",
    "1138__rep4__S003__TERMINAL_DROP_NO_ANCHOR",
    "1138__rep4__S002__FIRST_SENTENCE"
  ],
  "finding": "两特异事件可保持主体答案，但原新都可将未见135推成Formal已确认；rep4S2零Call还G提前提年报来源，末G0同过称说明不能全归教师。",
  "counter": "证据不足不等指标本身为假，强身份可正确；N002只确G所称来源缺失且无真返回的一条，不能所有确认过称都归它。"
}
```

```json
{
  "id": "ROOT039_C6",
  "cases": [
    "1239__rep3__S002__FIRST_SENTENCE",
    "1096__rep4__S006__TERMINAL_DROP_NO_ANCHOR"
  ],
  "finding": "前置比较及补证后判断都重建时，较短文本不等完整比较实例合并；末纯收束也同。",
  "counter": "前批存在真N004，仅按每条实际比较位置和次数，不按模板或字长。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT039_T1",
  "description": "已有核心锚点后取并采用缺失关系。",
  "links": [
    {
      "case_id": "1096__rep4__S005__FIRST_SENTENCE",
      "local_id": "ADOPTED_CORE_PAPER_RECOVERS_MISSING_CONFERENCE_PROGRAMME_AND_USES_RELATION"
    }
  ],
  "relation": "K2四真恢复参会节目，第三多失败批与旧词查。",
  "counterexamples": [
    "金融U从未取135，仅目录不是原直接证据恢复。"
  ],
  "unresolved": "论文理论仍间接；G整体核对与seed影响。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 4,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1096__rep4__S005__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1096"
    ]
  }
}
```

```json
{
  "id": "ROOT039_T2",
  "description": "真实不足反馈再派真实具体Query。",
  "links": [
    {
      "case_id": "1096__rep4__S005__FIRST_SENTENCE",
      "local_id": "PRECUT_FAILED_CONFERENCE_FEEDBACK_OR_NEW_FAILURE_LEADS_TO_REAL_RETRY_UNTIL_SUCCESS"
    },
    {
      "case_id": "1138__rep4__S002__FIRST_SENTENCE",
      "local_id": "RETURNED_DIRECTORY_INSUFFICIENCY_THEN_NEXT_REAL_QUERY"
    }
  ],
  "relation": "K3一可有限成功、一目录持续不足，两者真实反馈/新执行不可只叫循环。",
  "counterexamples": [
    "金融rep4新3零Call计划撤回不算；金融rep2新1尾E16只guard尚未送下一Actor，不作已经消费。"
  ],
  "unresolved": "工具参数不同/相同不自动判断新工作价值。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 7,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 7,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1096__rep4__S005__FIRST_SENTENCE",
      "1138__rep4__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1096",
      "1138"
    ]
  }
}
```

```json
{
  "id": "ROOT039_T3",
  "description": "稳定核心残余缺口真实核查及有效退出。",
  "links": [
    {
      "case_id": "1138__rep4__S002__FIRST_SENTENCE",
      "local_id": "SPECIFIC_FINANCIAL_GAP_REACTIVATES_REAL_CHECKS_DESPITE_PREACCEPTED_COMPANY"
    },
    {
      "case_id": "1239__rep3__S003__FIRST_SENTENCE",
      "local_id": "PREACCEPTED_SPECIES_RESIDUAL_POPULATION_GAP_DISPATCHES_REAL_CHECK"
    }
  ],
  "relation": "R3金融三真查未补、人口四真查成功；缺口同类触发不等必失败。",
  "counterexamples": [
    "金融新3直接Formal；人口同题其它切点有没查而C但支持少。"
  ],
  "unresolved": "真正停止阈值不可由文本唯一得，保缺口-行动及接受原文而不编心理。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 7,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 7,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1138__rep4__S002__FIRST_SENTENCE",
      "1239__rep3__S003__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1138",
      "1239"
    ]
  }
}
```

```json
{
  "id": "ROOT039_T4",
  "description": "G未来来源叙述在无新返回条件下扩成Formal确认。",
  "links": [
    {
      "case_id": "1138__rep4__S002__FIRST_SENTENCE",
      "local_id": "TEACHER_FUTURE_REPORT_SOURCE_WITH_NO_REAL_NEW_RETURN_BECOMES_FORMAL_CONFIRMATION"
    }
  ],
  "relation": "N002仅新3，P无年报16916而G给来源，随后零Call却确认135/期限；主体本来已有强证不等这些值已见。",
  "counterexamples": [
    "另三真取目录仍过称，机制来源不同；两个G0末路径也可Formal过称，不称G唯一原因。"
  ],
  "unresolved": "G事实和接受框架效应不能与seed分离。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 1,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 1,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1138__rep4__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1138"
    ]
  }
}
```

```json
{
  "id": "ROOT039_T5",
  "description": "真实返回转下一个具体人口查询，与认知功能恢复。",
  "links": [
    {
      "case_id": "1239__rep3__S001__FIRST_SENTENCE",
      "local_id": "RETURNED_PLANT_REGION_ENTERS_NEXT_SPECIFIC_POPULATION_CALL"
    },
    {
      "case_id": "1239__rep3__S002__FIRST_SENTENCE",
      "local_id": "VISIBLE_RETURN_ADOPTION_REBUILT_BEFORE_REGION_QUERY"
    }
  ],
  "relation": "R1同题两Stage七支，原P可见/采用有别，第二U全前置重建不是N004。",
  "counterexamples": [
    "根S1新2Formal前没有人口真实Call不算该行动链；P0根近重采样。"
  ],
  "unresolved": "同题不作跨题支持，G后继方向补偿保留。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 7,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 7,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1239__rep3__S001__FIRST_SENTENCE",
      "1239__rep3__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1239"
    ]
  }
}
```


## unresolved

```json
{
  "case_id": "1138__rep2__S002__FIRST_SENTENCE",
  "issue": "13真实轮、晚相同Reasoning和16Call尾guard已定向核；N007以弱身份假定频率接受不强套强两事件公司。"
}
```

```json
{
  "case_id": "1138__rep4__S002__FIRST_SENTENCE",
  "issue": "新2五Doc片段完全同但score不同，完整Return不逐字同；保直接校正。"
}
```

```json
{
  "case_id": "1239__rep3__S003__FIRST_SENTENCE",
  "issue": "四真补且全增生成，不以A判冗余，Prompt首重放217单列。"
}
```


## 限制
A组10Stage跨3题40关联分支；四次同题不当四独立题，教师ORACLE和G0分开，未完成定义兼容最终总计不以当前shortID即定机制支持。