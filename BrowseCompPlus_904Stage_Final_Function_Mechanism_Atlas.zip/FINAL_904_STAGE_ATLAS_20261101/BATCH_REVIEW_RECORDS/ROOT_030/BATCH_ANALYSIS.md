# ROOT_030 批次归纳

10 Stage / 9题 / 9原轨迹 / 40续跑；组别{'A': 7, 'B': 3}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "主体已采用时补尚未直接证明的具体识别条件，区分真补数据与失败重试。",
  "members": [
    "261__rep4__S009__FIRST_SENTENCE",
    "291__rep3__S003__FIRST_SENTENCE",
    "299__rep3__S003__FIRST_SENTENCE",
    "1023__rep3__S005__FIRST_SENTENCE"
  ],
  "distinction": "261表格查询只再返摘要；291学校两关系和299业主日期真实新得、四都恢复；1023首次机器取证具名/年代，四由广告附带年部分替代，不能只叫辅助核验相同。"
}
```

```json
{
  "description": "已取得并采用的书目关系再次外部确认。",
  "members": [
    "353__rep2__S004__FIRST_SENTENCE"
  ],
  "distinction": "原新目标26789完整片段同SHA且切前已采用，未补真正尚缺MSc年份；三新直接用P不重查，一新重查失败又多查作者才回用P。"
}
```

```json
{
  "description": "未确认身份或不合题候选的属性/关系探索，尝试未产出完整身份。",
  "members": [
    "319__rep1__S005__FIRST_SENTENCE",
    "980__rep2__S007__FIRST_SENTENCE",
    "1046__rep4__S002__FIRST_SENTENCE"
  ],
  "distinction": "319事故人数已P、只是连锁背景桥缺；980争端误限定当月且P已有Sun线索；1046初搜Adani仅待核，U并未成功排除。三原U不同失败产物，不能由后成功/退化倒推U已得关键正确知识。"
}
```

```json
{
  "description": "所选电影/子答案已采用但共演关系尚缺，继续取证或返回子答案确认。",
  "members": [
    "1247__rep4__S004__FIRST_SENTENCE"
  ],
  "distinction": "首作在P真实查实不证明主体电影身份；原U只单边TV，三N中一条已转首作而仅被guard阻正式提交，另两仍实查。"
}
```

```json
{
  "description": "正确主体与制造史已采用后，真实核广告关系但仍未得完整原文。",
  "members": [
    "1023__rep3__S006__FIRST_SENTENCE"
  ],
  "distinction": "与S005不同，机器证据/具名人已留P，删广告三Call但四仍重做三/四次广告，相对原全后缀五次的实例压缩。"
}
```


## comparisons

```json
{
  "id": "ROOT030_C1",
  "cases": [
    "261__rep4__S009__FIRST_SENTENCE",
    "291__rep3__S003__FIRST_SENTENCE",
    "299__rep3__S003__FIRST_SENTENCE"
  ],
  "finding": "同已采用主体，未解条件有实质差别。261原再查没有目标数值，新两零工具C、两重做仍没数据C；学校和业主资料原确实新补，四新都取回后C。",
  "counter": "不能以A稳定判辅助核验普遍没用；真实补证功能恢复和失败尝试取消两条机制分开，G接受语气/条件证据质量仍分列。"
}
```

```json
{
  "id": "ROOT030_C2",
  "cases": [
    "353__rep2__S004__FIRST_SENTENCE",
    "291__rep3__S003__FIRST_SENTENCE",
    "299__rep3__S003__FIRST_SENTENCE"
  ],
  "finding": "重取材料的前态决定含义：书的目标关系在P已取得并采用且原重返片段相同；学校/业主目标在P未证，即使已有名字仍需真查。",
  "counter": "书新2同P仍重取失败、追加作者查询才回P，不能由已有事实必然预测取消；学校三支生成更多，功能恢复也不等省。跨批270已年龄/299已年份可比，但不把同题另Stage算独立题。"
}
```

```json
{
  "id": "ROOT030_C3",
  "cases": [
    "319__rep1__S005__FIRST_SENTENCE",
    "980__rep2__S007__FIRST_SENTENCE",
    "1046__rep4__S002__FIRST_SENTENCE"
  ],
  "finding": "有效新入口的共同桥是实际材料→具体对象采用→真实下一Call：菜单→Spur，P争端名字→实际Sun查询联合片/兄弟，结构材料→Benko/改名。",
  "counter": "319新3也完成桥并接受却N，980实际Bollywood域查询本身不够，1046其它三没Benko材料不能称忽视。桥不是充分正确性条件，时间和预算重要。"
}
```

```json
{
  "id": "ROOT030_C4",
  "cases": [
    "980__rep2__S007__FIRST_SENTENCE",
    "1046__rep4__S002__FIRST_SENTENCE",
    "1247__rep4__S004__FIRST_SENTENCE"
  ],
  "finding": "未闭约束到Formal有不同失效：980年龄冲突仍closest旧片、1046频繁出现覆盖出生/成立冲突、1247查实首作替上游同剧身份并捏共同关系。",
  "counter": "1046新2最终正式拒匹配W，不是错误接受；1247新2有接受转首作却未Formal；980新4无Formal。不能按W/N或候选提及统一标签。"
}
```

```json
{
  "id": "ROOT030_C5",
  "cases": [
    "319__rep1__S005__FIRST_SENTENCE",
    "1247__rep4__S004__FIRST_SENTENCE"
  ],
  "finding": "功能恢复/甚至完整接受后还真查，后继Actor因context被挡，导致N而非从未形成答案判断。319新3已全身份/人数接受仍E13；1247新2已认1917/首作再E6。",
  "counter": "319仍存在评论者logo当管理话语的局部精度，1247主体原本W；不能说这些N本来必将正确提交，也不把未消费末Return当此前判断来源。"
}
```

```json
{
  "id": "ROOT030_C6",
  "cases": [
    "1023__rep3__S005__FIRST_SENTENCE",
    "1023__rep3__S006__FIRST_SENTENCE"
  ],
  "finding": "相邻切点同核心C的省法不同：删机器时四以广告Return恢复机器年但不恢复具名人，三支少机器Call、一支加广告填回；删广告时机器完整留P，四仍重做广告但总实例较少。",
  "counter": "同题两个Stage只一个独立题；部分证据恢复不强并N006，广告未闭不N005。G一个方向一个充分性判断均有补偿，不把Call下降全归U无用。"
}
```

```json
{
  "id": "ROOT030_C7",
  "cases": [
    "261__rep4__S009__FIRST_SENTENCE",
    "1247__rep4__S004__FIRST_SENTENCE",
    "1023__rep3__S005__FIRST_SENTENCE",
    "1023__rep3__S006__FIRST_SENTENCE"
  ],
  "finding": "答案组织把未知关系写确定需具体产品：261需全文验证→六表/13.53肯定，1247不同演员不同剧→共同剧，帽针likely续句→完整确定引文。",
  "counter": "帽针一支保likely、新1可先错解释后识别截断，原也广告缺；这几条开放共同证据状态问题不等一个统一因果，更不能硬并名称迁移N001或无工具G假源N002。"
}
```

```json
{
  "id": "ROOT030_C8",
  "cases": [
    "353__rep2__S004__FIRST_SENTENCE",
    "319__rep1__S005__FIRST_SENTENCE",
    "980__rep2__S007__FIRST_SENTENCE"
  ],
  "finding": "G不新增事实也可影响工作：书在名字内截句异常且给found框架，餐馆G称没数字但P已经2，980G转阶层却四首Call仍争端。",
  "counter": "不把G自身算自主新判断/已执行Call；0工具与有工具恢复都可能同G，无法单一归因。"
}
```

```json
{
  "id": "ROOT030_C9",
  "cases": [
    "1046__rep4__S002__FIRST_SENTENCE",
    "1023__rep3__S006__FIRST_SENTENCE",
    "319__rep1__S005__FIRST_SENTENCE"
  ],
  "finding": "少生成可以伴更多工具/Prompt和N；少工具也可更多生成。Adani新4、餐馆新3/4和帽针新2提供真实反向账。",
  "counter": "精确/CHAR区间分开，不累加独立分支差；原N→W不自动改善，四C不自动全部解释无误。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT030_T1",
  "description": "保留已采用身份锚，真实重新获得原目标缺失条件。",
  "links": [
    {
      "case_id": "291__rep3__S003__FIRST_SENTENCE",
      "local_id": "RETAINED_PERSON_ANCHOR_REACQUIRES_AND_USES_MISSING_TWO_SCHOOL_EVENTS"
    },
    {
      "case_id": "299__rep3__S003__FIRST_SENTENCE",
      "local_id": "RETAINED_BUILDING_OWNER_ANCHOR_REACQUIRES_MISSING_BIOGRAPHY_AND_OPENING_DATES"
    }
  ],
  "relation": "P1_K2两题，两项条件并非P已证；四重建不支持原功能无用。",
  "counterexamples": [
    "353目标事实已P，三个不重取；261取回仍无数据而两不重查；同姓名不保证有效材料和结果。"
  ],
  "unresolved": "G肯定语气存在，不能与恢复成功唯一分离。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 8,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 8,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "291__rep3__S003__FIRST_SENTENCE",
      "299__rep3__S003__FIRST_SENTENCE"
    ],
    "question_ids": [
      "291",
      "299"
    ]
  }
}
```

```json
{
  "id": "ROOT030_T2",
  "description": "正确核心下残余条件驱动真实补证。",
  "links": [
    {
      "case_id": "261__rep4__S009__FIRST_SENTENCE",
      "local_id": "ADOPTED_PAPER_NUMERIC_GAP_REBUILDS_TRUE_UNSUCCESSFUL_VERIFICATION"
    },
    {
      "case_id": "291__rep3__S003__FIRST_SENTENCE",
      "local_id": "UNVERIFIED_SCHOOL_RELATIONS_SURVIVE_ACCEPTANCE_GUIDE_AND_DISPATCH_TRUE_CHECK"
    },
    {
      "case_id": "299__rep3__S003__FIRST_SENTENCE",
      "local_id": "STABLE_BUILDING_IDENTITY_UNPROVEN_OWNER_DATES_TRIGGER_REAL_VERIFICATION"
    },
    {
      "case_id": "1023__rep3__S005__FIRST_SENTENCE",
      "local_id": "CORRECT_HATPIN_IDENTITY_AND_UNCLOSED_AD_GAP_CONTINUE_REAL_SEARCH"
    },
    {
      "case_id": "1023__rep3__S006__FIRST_SENTENCE",
      "local_id": "PREACCEPTED_HATPIN_AND_REMAINING_AD_RELATION_REBUILD_REAL_VERIFICATION"
    }
  ],
  "relation": "P2_R3五Stage/四题，区分Return真实补缺与仍摘要/截断，两个帽针切点不当两题。",
  "counterexamples": [
    "261前两不实际查询，意向不计；1247选片未证不归正确核心，旧Adani也不归。"
  ],
  "unresolved": "条件可能合理仍未补齐，不能用不断搜索直接判冗余。",
  "deterministic_counts": {
    "observed_stage_count": 5,
    "different_questions": 4,
    "original_runs": 4,
    "observed_rollouts": 18,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 18,
    "not_observed_local_chain_occurrences": 2,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 20,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1023__rep3__S005__FIRST_SENTENCE",
      "1023__rep3__S006__FIRST_SENTENCE",
      "261__rep4__S009__FIRST_SENTENCE",
      "291__rep3__S003__FIRST_SENTENCE",
      "299__rep3__S003__FIRST_SENTENCE"
    ],
    "question_ids": [
      "261",
      "291",
      "299",
      "1023"
    ]
  }
}
```

```json
{
  "id": "ROOT030_T3",
  "description": "具体证据选择/采用接到真实具名后继行动。",
  "links": [
    {
      "case_id": "319__rep1__S005__FIRST_SENTENCE",
      "local_id": "SPECIFIC_MENU_RETURN_CHANGES_CHAIN_IDENTITY_AND_ACTUAL_FOLLOWUP_QUERY"
    },
    {
      "case_id": "980__rep2__S007__FIRST_SENTENCE",
      "local_id": "RETAINED_FEUD_NAMES_SELECTED_IN_ACTUAL_CALL_AND_REAL_JOINT_RELATION_ADOPTED"
    },
    {
      "case_id": "1046__rep4__S002__FIRST_SENTENCE",
      "local_id": "NEW_STRUCTURE_EVIDENCE_UPDATES_REAL_PERSON_AND_COMPANY_VERIFICATION_OBJECT"
    }
  ],
  "relation": "P2_R1三题，同深层动作桥、不同来源/人物关系；不能按说搜索或域关键词计。",
  "counterexamples": [
    "319新3桥已恢复仍N；980新2角色解释排斥、新3末返未用、新4早返仍泛搜；1046其它无相关Return。"
  ],
  "unresolved": "源到行动不是足以预测C，材料匹配及提交时机另作。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 5,
    "not_observed_rollouts": 7,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 5,
    "not_observed_local_chain_occurrences": 7,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep4__S002__FIRST_SENTENCE",
      "319__rep1__S005__FIRST_SENTENCE",
      "980__rep2__S007__FIRST_SENTENCE"
    ],
    "question_ids": [
      "319",
      "980",
      "1046"
    ]
  }
}
```

```json
{
  "id": "ROOT030_T4",
  "description": "单一真实返回同时闭合原独立影片发现和兄弟争端关系核查。",
  "links": [
    {
      "case_id": "980__rep2__S007__FIRST_SENTENCE",
      "local_id": "ONE_SPECIFIC_FEUD_RETURN_COMBINES_FILM_DISCOVERY_AND_BROTHER_DIRECTOR_LINK"
    }
  ],
  "relation": "N005新1，本批仅一Stage一题一支，和前批多题联合补证比较但不手加跨批数。",
  "counterexamples": [
    "另三单争端/印度域Query没有电影桥，不能把共同Doc出现当条件已闭；帽针广告加机器年不完整关闭广告。"
  ],
  "unresolved": "演员角色/生日具体说明质量另留，不把联合核心关系支持当全Final无误。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 1,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 1,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "980__rep2__S007__FIRST_SENTENCE"
    ],
    "question_ids": [
      "980"
    ]
  }
}
```

```json
{
  "id": "ROOT030_T5",
  "description": "反复命中被实际用于接受未证/冲突主体。",
  "links": [
    {
      "case_id": "980__rep2__S007__FIRST_SENTENCE",
      "local_id": "RETRIEVAL_FREQUENCY_USED_TO_JUSTIFY_PARTIAL_FILM_ACCEPTANCE"
    },
    {
      "case_id": "1046__rep4__S002__FIRST_SENTENCE",
      "local_id": "REPEATED_CASE_MENTIONS_OVERRIDE_KNOWN_BIRTH_AND_FOUNDING_CONFLICT_AT_ACCEPTANCE"
    }
  ],
  "relation": "N007两题各一明确支，接受理由与Formal齐。",
  "counterexamples": [
    "980新2mostfamous不是检索频率；1046新2频繁考虑却正式拒匹配，4重复无Formal，均不能照标。"
  ],
  "unresolved": "频率只是明示接受理由之一，不声称唯一内因。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 2,
    "not_observed_rollouts": 4,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 2,
    "observed_local_chain_occurrences": 2,
    "not_observed_local_chain_occurrences": 4,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 2,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep4__S002__FIRST_SENTENCE",
      "980__rep2__S007__FIRST_SENTENCE"
    ],
    "question_ids": [
      "980",
      "1046"
    ]
  }
}
```

```json
{
  "id": "ROOT030_T6",
  "description": "部分符合或已查实的子答案跨过完整身份条件接受。",
  "links": [
    {
      "case_id": "319__rep1__S005__FIRST_SENTENCE",
      "local_id": "UNIQUE_INCIDENT_ATTRIBUTE_ACCEPTED_WITH_BACKGROUND_IDENTITY_UNRESOLVED"
    },
    {
      "case_id": "980__rep2__S007__FIRST_SENTENCE",
      "local_id": "KNOWN_AGE_CONFLICT_OVERRIDDEN_BY_CLOSEST_PARTIAL_PLOT_AT_FORMAL"
    },
    {
      "case_id": "1046__rep4__S002__FIRST_SENTENCE",
      "local_id": "PARTIAL_DEBT_AND_BRIBERY_SIMILARITY_PROMOTED_OVER_EXPLICIT_IDENTITY_CONFLICT"
    },
    {
      "case_id": "1247__rep4__S004__FIRST_SENTENCE",
      "local_id": "VERIFIED_SUBANSWER_OVERRIDES_UNCLOSED_FILM_IDENTITY_AT_FORMAL"
    }
  ],
  "relation": "N008四题，319强独特事故主归留歧义，电影/公司硬冲突较清楚；同机制不同证据强度不抹平。",
  "counterexamples": [
    "1046新2正式拒答无错误接受；1247新2有判断却guard无Formal；319新2/4真补背景。"
  ],
  "unresolved": "1247首作子关系有真证但主体未证，较细链同题多rep支持非新增不同题。",
  "deterministic_counts": {
    "observed_stage_count": 4,
    "different_questions": 4,
    "original_runs": 4,
    "observed_rollouts": 5,
    "not_observed_rollouts": 5,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 6,
    "observed_local_chain_occurrences": 5,
    "not_observed_local_chain_occurrences": 5,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 6,
    "total_distinct_rollouts_in_test": 16,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep4__S002__FIRST_SENTENCE",
      "1247__rep4__S004__FIRST_SENTENCE",
      "319__rep1__S005__FIRST_SENTENCE",
      "980__rep2__S007__FIRST_SENTENCE"
    ],
    "question_ids": [
      "319",
      "980",
      "1046",
      "1247"
    ]
  }
}
```

```json
{
  "id": "ROOT030_T7",
  "description": "已知目标事实/完整接受之后真实再确认；分别看新增佐证价值和预算。",
  "links": [
    {
      "case_id": "319__rep1__S005__FIRST_SENTENCE",
      "local_id": "ACCEPTED_INCIDENT_AND_CHAIN_STILL_TRIGGER_ONE_MORE_REAL_CONFIRMATION"
    },
    {
      "case_id": "353__rep2__S004__FIRST_SENTENCE",
      "local_id": "KNOWN_BOOK_CONFIRMATION_FAILURE_DISPATCHES_ANOTHER_AUTHOR_CHECK_BEFORE_OLD_EVIDENCE_USED"
    },
    {
      "case_id": "1046__rep4__S002__FIRST_SENTENCE",
      "local_id": "MATCHED_ORIGINAL_COMPANY_NAME_RECHECKED_AFTER_ALL_CRITERIA_ACCEPTED"
    },
    {
      "case_id": "1247__rep4__S004__FIRST_SENTENCE",
      "local_id": "ALREADY_ACCEPTED_DIRECTOR_DEBUT_RECONFIRMED_WITH_SHARED_SHOW_UNRESOLVED"
    }
  ],
  "relation": "P2_R2四题：重复关系、失败额外取证、真独立德文佐证、子答案确认不能替主体四子链并列。",
  "counterexamples": [
    "未知广告/学校补证不因已有核心接受就R2；353三直接答不发生；319末多Call后无Final不证明本来必C。"
  ],
  "unresolved": "可靠性佐证有价值不能全说无用，额外Call也可能阻下一Actor需记实际边界。",
  "deterministic_counts": {
    "observed_stage_count": 4,
    "different_questions": 4,
    "original_runs": 4,
    "observed_rollouts": 5,
    "not_observed_rollouts": 8,
    "uncertain_rollouts": 2,
    "excluded_rollouts": 1,
    "observed_local_chain_occurrences": 5,
    "not_observed_local_chain_occurrences": 8,
    "uncertain_local_chain_occurrences": 2,
    "excluded_local_chain_occurrences": 1,
    "total_distinct_rollouts_in_test": 16,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep4__S002__FIRST_SENTENCE",
      "1247__rep4__S004__FIRST_SENTENCE",
      "319__rep1__S005__FIRST_SENTENCE",
      "353__rep2__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "319",
      "353",
      "1046",
      "1247"
    ]
  }
}
```

```json
{
  "id": "ROOT030_T8",
  "description": "固定候选未知属性/关系的失败处理后再次真实查询。",
  "links": [
    {
      "case_id": "1046__rep4__S002__FIRST_SENTENCE",
      "local_id": "FIXED_ADANI_ATTRIBUTE_GAPS_REDISPATCH_REAL_SEARCH_AFTER_FAILED_RETURNS"
    },
    {
      "case_id": "1247__rep4__S004__FIRST_SENTENCE",
      "local_id": "UNVERIFIED_1917_SHARED_TV_RELATION_DISPATCHES_FURTHER_REAL_CHECKS"
    }
  ],
  "relation": "P1_K3两题，未完全匹配对象不当正确核心R3；不同结果W/拒答/N不是一个结果预测。",
  "counterexamples": [
    "1046新3继续广查但不固定Adani，真新材料后转对象C；1247新3较早停止W，2已转首作仍N。"
  ],
  "unresolved": "检索仍有可能新增有效证据，不由重复断言已穷尽。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 7,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 7,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep4__S002__FIRST_SENTENCE",
      "1247__rep4__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1046",
      "1247"
    ]
  }
}
```

```json
{
  "id": "ROOT030_T9",
  "description": "已采用关系可直接沿P使用，取消相同关系外部再次获取。",
  "links": [
    {
      "case_id": "353__rep2__S004__FIRST_SENTENCE",
      "local_id": "ADOPTED_BOOK_RELATION_PRESERVED_WITHOUT_RETRIEVING_IDENTICAL_SUPPORT_AGAIN"
    }
  ],
  "relation": "本批书3支，跨批270已年龄/299已范围G0有对应开放比较，准备按窄条件登记候选，不称全类型Stage冗余。",
  "counterexamples": [
    "书新2同P仍重取失败而增加；291/299本批目标条件在P未证不能归；261原失败Query取消又不同。"
  ],
  "unresolved": "书G名字内部截断异常、其它共享毕业年缺口，官方来源新佐证可靠性价值不能由核心C抹去。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 3,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 3,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "353__rep2__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "353"
    ]
  }
}
```

```json
{
  "id": "ROOT030_T10",
  "description": "未知在答案组织中变确定断言，或真实错误返回解释被部分修正。",
  "links": [
    {
      "case_id": "261__rep4__S009__FIRST_SENTENCE",
      "local_id": "ACKNOWLEDGED_UNVERIFIED_TABLE_DATA_BECOMES_DEFINITE_FINAL_SUPPORT"
    },
    {
      "case_id": "1247__rep4__S004__FIRST_SENTENCE",
      "local_id": "INDEPENDENT_ACTOR_TV_EDGES_REWRITTEN_AS_SHARED_SHOW_IN_FINAL"
    },
    {
      "case_id": "1023__rep3__S005__FIRST_SENTENCE",
      "local_id": "HYPOTHESIZED_SLOGAN_BECOMES_DEFINITE_COMPLETE_QUOTATION_WITHOUT_NEW_SUPPORT"
    },
    {
      "case_id": "1023__rep3__S006__FIRST_SENTENCE",
      "local_id": "CLAIMED_RETURN_SUPPORT_PARTLY_CORRECTED_TO_RECOGNIZED_TRUNCATION"
    }
  ],
  "relation": "开放比较三个题多种证据状态转换，末组件方向是部分纠正而非同一失真；只比较不注册一个泛幻觉机制。",
  "counterexamples": [
    "帽针likely续句与确定引用分开，261新1caveat保留；1247新4明确独立边不合成；不能模板复制。"
  ],
  "unresolved": "同样证据不足的不同产物转换未证明共同唯一内因，继续保具体链。",
  "deterministic_counts": {
    "observed_stage_count": 4,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 5,
    "not_observed_rollouts": 9,
    "uncertain_rollouts": 1,
    "excluded_rollouts": 1,
    "observed_local_chain_occurrences": 5,
    "not_observed_local_chain_occurrences": 9,
    "uncertain_local_chain_occurrences": 1,
    "excluded_local_chain_occurrences": 1,
    "total_distinct_rollouts_in_test": 16,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1023__rep3__S005__FIRST_SENTENCE",
      "1023__rep3__S006__FIRST_SENTENCE",
      "1247__rep4__S004__FIRST_SENTENCE",
      "261__rep4__S009__FIRST_SENTENCE"
    ],
    "question_ids": [
      "261",
      "1023",
      "1247"
    ]
  }
}
```


## unresolved

```json
{
  "case_id": "353__rep2__S004__FIRST_SENTENCE",
  "issue": "首句在书名内部感叹号截断，必须保提取异常；MSc年份无证与C分开。"
}
```

```json
{
  "case_id": "319__rep1__S005__FIRST_SENTENCE",
  "issue": "G假失败反馈与P已知2冲突；3正确接受后仍无Formal，不能由N推没有判断或原功能未恢复。"
}
```

```json
{
  "case_id": "1247__rep4__S004__FIRST_SENTENCE",
  "issue": "新2有真实Eternals/GoT替代线索但非完整Gold链；年度票房与上映年误绑留原P，不能只讨论TV。"
}
```

```json
{
  "case_id": "1046__rep4__S002__FIRST_SENTENCE",
  "issue": "原U没成功排除，new2最终Formal拒答非接受错误实体，CHAR只保守区间。"
}
```

```json
{
  "case_id": "1023__rep3__S005__FIRST_SENTENCE",
  "issue": "广告新证部分恢复机器年无Howe，不强扩大N006；自拟查询fists不等Finalhatpins被真实查实。"
}
```

```json
{
  "case_id": "1023__rep3__S006__FIRST_SENTENCE",
  "issue": "新2同主体C但holder附答和广告无证，四仍真查并非接受G强制Final。"
}
```


## 限制
十Stage九不同题、四十真实续跑，帽针同题两Stage不当两题；A/B冻结分组七A三B非按结果重新挑样。教师方向/接受/失败反馈、采样、工具组合/预算均保留，FIRST/TERMINAL不混。本批全部FIRST，机械引用/统计PASS不等独立人工语义金标准。