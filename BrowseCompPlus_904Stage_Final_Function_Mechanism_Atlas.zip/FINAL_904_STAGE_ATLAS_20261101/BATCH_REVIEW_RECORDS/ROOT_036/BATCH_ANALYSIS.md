# ROOT_036 批次归纳

10 Stage / 4题 / 5原轨迹 / 40续跑；组别{'A': 10}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "已采用身份后取得一个此前缺少的独立条件证据。",
  "members": [
    "1095__rep4__S003__FIRST_SENTENCE",
    "1096__rep1__S006__FIRST_SENTENCE",
    "1096__rep1__S007__FIRST_SENTENCE"
  ],
  "distinction": "Clarke U真正补纪录片关系；Hart S6原U失败、Z才补会议，S7 U真正补会议。不能把三者都写成删掉一份已有证明。"
}
```

```json
{
  "description": "已采用身份下继续检索未证数值，处理失败与接受。",
  "members": [
    "1138__rep1__S003__FIRST_SENTENCE"
  ],
  "distinction": "公司身份/事件已经稳定，135与期限无直接值证；继续查询不是遗失公司，正式回答声称确认也不是返回真的含值。"
}
```

```json
{
  "description": "首次发现未知目标及关联条件，或处理问题框架与候选资格。",
  "members": [
    "1239__rep2__S001__FIRST_SENTENCE",
    "1096__rep2__S001__FIRST_SENTENCE",
    "1096__rep2__S002__FIRST_SENTENCE"
  ],
  "distinction": "植物一次实际Return可同时提供物种和人口，论文也可同Return闭论文/参会；但同批多Call不等一个Return。论文有一支将背景SFL错误移为文章框架的硬要求，另支仅合理核验仍存歧义。"
}
```

```json
{
  "description": "整合已得条件、选择关键词或再访问已采用的同一关系。",
  "members": [
    "1095__rep4__S004__TERMINAL_DROP_NO_ANCHOR",
    "1096__rep1__S008__FIRST_SENTENCE",
    "1096__rep1__S009__TERMINAL_DROP_NO_ANCHOR"
  ],
  "distinction": "Clarke无G完整认知再生成但零Call；Hart末段无G四支主动重查同词序。Hart S8少字仍有取证前整合，不能硬说前比较被取消。"
}
```


## comparisons

```json
{
  "id": "ROOT036_C1",
  "cases": [
    "1095__rep4__S003__FIRST_SENTENCE",
    "1096__rep1__S007__FIRST_SENTENCE"
  ],
  "finding": "两U都新补独立条件。Clarke四支不重取片子证明而C；Hart1/4无会议证明也C，2/3真实补成功且更少交互。",
  "counter": "主答案C不能替独立条件证据验收；Hart的原S6本次失败不能登记同样U证据损失。"
}
```

```json
{
  "id": "ROOT036_C2",
  "cases": [
    "1096__rep1__S006__FIRST_SENTENCE",
    "1096__rep1__S007__FIRST_SENTENCE"
  ],
  "finding": "S6 G换会议入口，三支真实97254成功、一支由题目结构推参与。S7泛SFL失败可被针对作者查询修复，也可在失败后直接答旧词。",
  "counter": "S7新3后截点仅一次Call，但P已有失败及处理，完整P→新窗口仍有真实重试，不因单新Call否定。"
}
```

```json
{
  "id": "ROOT036_C3",
  "cases": [
    "1096__rep1__S008__FIRST_SENTENCE",
    "1096__rep1__S009__TERMINAL_DROP_NO_ANCHOR",
    "1095__rep4__S004__TERMINAL_DROP_NO_ANCHOR"
  ],
  "finding": "Hart S8四支重现取证前的论文/词序整合，查后还判断，生成较短但Prompt增加；S9无G仍真实同词序查询，Clarke无G则只有复盘。",
  "counter": "同样C与末段不代表同样工作省掉；不能套N004或N009，前者前认知没有全消失，后者外部重查没有消失。"
}
```

```json
{
  "id": "ROOT036_C4",
  "cases": [
    "1096__rep2__S001__FIRST_SENTENCE",
    "1096__rep2__S002__FIRST_SENTENCE"
  ],
  "finding": "S2新3明确把题目背景框架变成文章必须FROM SFL，因cognitive不符转向实际替代检索，后来才纠正原句范围。S1新1和S2新4核验背景未必等同该错读。",
  "counter": "只有具体原文语法范围、排除倾向与真实Call三者支持时记强正例；普通检验学术背景不强归错约束。"
}
```

```json
{
  "id": "ROOT036_C5",
  "cases": [
    "1096__rep2__S001__FIRST_SENTENCE",
    "1239__rep2__S001__FIRST_SENTENCE"
  ],
  "finding": "论文新4先真实得到未知其指的Lancaster排名，后论文作者单位识别后才将旧排名用于该约束；植物新2首Return两个文档被共同用于物种/人口。",
  "counter": "前例是迟到关系连接，不是排名未返也不是排名从G来；同一题仅一支开放链不注册跨题新机制。植物新3首批双Call不假造逐次决策。"
}
```

```json
{
  "id": "ROOT036_C6",
  "cases": [
    "1138__rep1__S003__FIRST_SENTENCE",
    "1096__rep1__S006__FIRST_SENTENCE"
  ],
  "finding": "公司新2已知两项强事件仍17次实际追指标，末三相同Return和已消费后推理不变，Actor20止；论文具体作者入口却可补会议后正常提交。",
  "counter": "未知条件继续派发取证不必全是低收益，必须按是否真取得新关系区分。公司新4已明确身份仍新增三实际查，不补造停止阈值。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT036_T1",
  "description": "已有采用身份在失去U新独立佐证时仍可提交同一主体。",
  "links": [
    {
      "case_id": "1095__rep4__S003__FIRST_SENTENCE",
      "local_id": "PREACCEPTED_IDENTITY_SUBMITTED_WITHOUT_NEW_DIRECT_DOCUMENTARY_CORROBORATION"
    },
    {
      "case_id": "1096__rep1__S007__FIRST_SENTENCE",
      "local_id": "PREACCEPTED_PAPER_ANSWER_SUBMITTED_WITHOUT_U_NEW_CONFERENCE_CORROBORATION"
    }
  ],
  "relation": "N006两题六支，保持C但缺去片子或会议的新增直接支持，不能当全部质量保持。",
  "counterexamples": [
    "Hart S7另两支真会议补回，S6原U没有取得会议证明故不适用此U证据丢失归因。"
  ],
  "unresolved": "已有身份的其它特异条件是否已经充分，不以缺一个辅助条件就断言身份接受错误。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 6,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 6,
    "not_observed_local_chain_occurrences": 2,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1095__rep4__S003__FIRST_SENTENCE",
      "1096__rep1__S007__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1095",
      "1096"
    ]
  }
}
```

```json
{
  "id": "ROOT036_T2",
  "description": "稳定论文身份后通过针对性新入口恢复缺失关系。",
  "links": [
    {
      "case_id": "1096__rep1__S006__FIRST_SENTENCE",
      "local_id": "ADOPTED_PAPER_REACQUIRES_MISSING_CONFERENCE_PROOF_EXCEPT_QUESTION_INFERENCE_PATH"
    },
    {
      "case_id": "1096__rep1__S007__FIRST_SENTENCE",
      "local_id": "KNOWN_PAPER_UNPROVEN_AUTHOR_CONFERENCE_RELATION_RESTORED_BY_TRUE_PROGRAM"
    }
  ],
  "relation": "K2，同一题不同切点5支真97254并采用；工作恢复仍可少Call/字，不等原功能无用。",
  "counterexamples": [
    "S6新1用题意推会议，S7新1/4直接旧词提交而没取得关系。"
  ],
  "unresolved": "S6恢复的是原Z成功的目标，原U失败反馈的具体效用单列，不倒灌为U成功产品。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 5,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 5,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1096__rep1__S006__FIRST_SENTENCE",
      "1096__rep1__S007__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1096"
    ]
  }
}
```

```json
{
  "id": "ROOT036_T3",
  "description": "同一已采用词序再查与全条件比较再生成。",
  "links": [
    {
      "case_id": "1096__rep1__S006__FIRST_SENTENCE",
      "local_id": "KNOWN_PAPER_RETRIEVED_AGAIN_WHILE_OR_AFTER_OTHER_RELATION_CHECKED"
    },
    {
      "case_id": "1096__rep1__S008__FIRST_SENTENCE",
      "local_id": "KNOWN_ORDERED_KEYWORDS_EXPLICITLY_RECOGNIZED_THEN_RETRIEVED_AGAIN"
    },
    {
      "case_id": "1096__rep1__S009__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "ALREADY_EXPLICITLY_SELECTED_ORDERED_KEYWORD_RETRIEVAL_REGENERATED_WITHOUT_GUIDE"
    },
    {
      "case_id": "1096__rep2__S002__FIRST_SENTENCE",
      "local_id": "ALREADY_SELECTED_KEYWORD_ORDER_REQUERIED_AFTER_OTHER_CONDITIONS_CHECKED"
    }
  ],
  "relation": "R2仅一题多Stage，不加跨题数。无G末段主动再查表明真实功能重建；精确词序复核与未知学术框架分开。",
  "counterexamples": [
    "S8四少生成但全有真实重查、Prompt增加；S2新4未知理论关系查询不因同文章算重复已知词。"
  ],
  "unresolved": "确认相同真关系的收益未受独立干预检验，不以重复直接判无用。",
  "deterministic_counts": {
    "observed_stage_count": 4,
    "different_questions": 1,
    "original_runs": 2,
    "observed_rollouts": 12,
    "not_observed_rollouts": 4,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 12,
    "not_observed_local_chain_occurrences": 4,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 16,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1096__rep1__S006__FIRST_SENTENCE",
      "1096__rep1__S008__FIRST_SENTENCE",
      "1096__rep1__S009__TERMINAL_DROP_NO_ANCHOR",
      "1096__rep2__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1096"
    ]
  }
}
```

```json
{
  "id": "ROOT036_T4",
  "description": "真实失败反馈后的下一实际取证及其退出差别。",
  "links": [
    {
      "case_id": "1096__rep1__S006__FIRST_SENTENCE",
      "local_id": "FAILED_CONFERENCE_FEEDBACK_REACTIVATES_TRUE_SPECIFIC_RELATION_QUERY"
    },
    {
      "case_id": "1096__rep1__S007__FIRST_SENTENCE",
      "local_id": "PRE_CUT_FAILED_CONFERENCE_FEEDBACK_REACTIVATES_NEW_REAL_ATTEMPT"
    },
    {
      "case_id": "1138__rep1__S003__FIRST_SENTENCE",
      "local_id": "FAILED_METRIC_FEEDBACK_REACTIVATES_QUERY_WITHOUT_NEW_VALUE_EVIDENCE"
    },
    {
      "case_id": "1239__rep2__S001__FIRST_SENTENCE",
      "local_id": "POPULATION_GAP_SURVIVES_SPECIES_WEIGHTED_QUERY_THEN_TRUE_REGION_QUERY_CLOSES_IT"
    }
  ],
  "relation": "K3三题，包含成功换入口、仍未闭合便答、真实重复耗尽Actor。不是所有重试都循环。",
  "counterexamples": [
    "植物新1变成地区入口真取得人口；Hart新3首次新Call成功，历史失败在P；公司新2值无进展并非身份未恢复。"
  ],
  "unresolved": "能看清何处重复派发，但不同支为何决定退出仍部分未确定。",
  "deterministic_counts": {
    "observed_stage_count": 4,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 11,
    "not_observed_rollouts": 5,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 11,
    "not_observed_local_chain_occurrences": 5,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 16,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1096__rep1__S006__FIRST_SENTENCE",
      "1096__rep1__S007__FIRST_SENTENCE",
      "1138__rep1__S003__FIRST_SENTENCE",
      "1239__rep2__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1096",
      "1138",
      "1239"
    ]
  }
}
```

```json
{
  "id": "ROOT036_T5",
  "description": "一个真实Return中的多个未知关系同时被采用。",
  "links": [
    {
      "case_id": "1239__rep2__S001__FIRST_SENTENCE",
      "local_id": "ONE_REAL_FIRST_RETURN_SUPPLIES_UNKNOWN_SPECIES_IDENTITY_AND_POPULATION_RELATION"
    },
    {
      "case_id": "1096__rep2__S001__FIRST_SENTENCE",
      "local_id": "ONE_REAL_RETURN_SUPPLIES_UNKNOWN_PAPER_AND_ITS_AUTHOR_CONFERENCE_LINK"
    }
  ],
  "relation": "N005两题各一支，物种/人口与论文/作者会议真实同Return并实际采用。",
  "counterexamples": [
    "论文新1会议早可见但尚未连接候选，后来再查；植物新3同批多Call不等单Return。"
  ],
  "unresolved": "联合证据可减少独立关系核验，但植物新2另有地方名称查，不能推总Search一定最低。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 2,
    "not_observed_rollouts": 6,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 2,
    "not_observed_local_chain_occurrences": 6,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1096__rep2__S001__FIRST_SENTENCE",
      "1239__rep2__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1096",
      "1239"
    ]
  }
}
```

```json
{
  "id": "ROOT036_T6",
  "description": "原题框架解释改变文章资格和下一实际检索。",
  "links": [
    {
      "case_id": "1096__rep2__S001__FIRST_SENTENCE",
      "local_id": "SFL_VERSUS_ALTERNATIVE_FRAMEWORK_INTERPRETATION_REOPENS_ELIGIBILITY_SEARCH"
    },
    {
      "case_id": "1096__rep2__S002__FIRST_SENTENCE",
      "local_id": "FRAMEWORK_CLAUSE_SCOPE_REASSIGNED_TO_ARTICLE_DRIVES_ALTERNATIVE_RETRIEVAL"
    }
  ],
  "relation": "K1 S2新3强支持，S1新1及S2新4留UNC；同题范围解释与独立背景核验不能混为一类。",
  "counterexamples": [
    "S2新1/2在获得论文后正常补会议/排名，不因未见直接SFL对照而排除；强正例末又修正，最终仍C且成本多。"
  ],
  "unresolved": "错读作用可观察，是否足以解释整段额外成本不能完全排除采样和G。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 1,
    "not_observed_rollouts": 5,
    "uncertain_rollouts": 2,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 1,
    "not_observed_local_chain_occurrences": 5,
    "uncertain_local_chain_occurrences": 2,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1096__rep2__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1096"
    ]
  }
}
```

```json
{
  "id": "ROOT036_T7",
  "description": "实际返回材料转成后继真实查询对象。",
  "links": [
    {
      "case_id": "1239__rep2__S001__FIRST_SENTENCE",
      "local_id": "REAL_SPECIES_AND_REGION_MATERIAL_CHANGES_NEXT_SPECIFIC_VERIFICATION_OBJECT"
    },
    {
      "case_id": "1096__rep2__S001__FIRST_SENTENCE",
      "local_id": "RETURNED_PAPER_AUTHOR_OR_FRAMEWORK_USED_IN_NEXT_REAL_SPECIFIC_QUERY"
    },
    {
      "case_id": "1096__rep2__S002__FIRST_SENTENCE",
      "local_id": "REAL_ARTICLE_INFORMATION_USED_FOR_NEXT_SPECIFIC_AUTHOR_OR_FINAL_PAPER_QUERY"
    }
  ],
  "relation": "R1两题，论文S2新3桥在后期修正并选择再查原文，不伪造首次获得即接受；植物动物猜测未变成错误具名查询。",
  "counterexamples": [
    "旧排名到新单位的迟到连接在一支开放，不假称首次排名即采用；单纯答案重述不算Query桥。"
  ],
  "unresolved": "首段P0与动作G不可推纯删除，来源事件/原seed路径不同。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 12,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 12,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1096__rep2__S001__FIRST_SENTENCE",
      "1096__rep2__S002__FIRST_SENTENCE",
      "1239__rep2__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1096",
      "1239"
    ]
  }
}
```

```json
{
  "id": "ROOT036_T8",
  "description": "公司身份已稳定仍有实际数值任务，正式确认可超出返回。",
  "links": [
    {
      "case_id": "1138__rep1__S003__FIRST_SENTENCE",
      "local_id": "PREACCEPTED_COMPANY_UNPROVEN_METRIC_CONTINUES_TO_DISPATCH_REAL_VERIFICATION"
    },
    {
      "case_id": "1138__rep1__S003__FIRST_SENTENCE",
      "local_id": "UNSEEN_REQUIRED_VALUES_PROMOTED_TO_DOCUMENTED_PROOF_AT_FORMAL"
    },
    {
      "case_id": "1138__rep1__S003__FIRST_SENTENCE",
      "local_id": "CONFIDENT_IDENTITY_SELECTION_DOES_NOT_END_SPECIFIC_ATTRIBUTE_SEARCH"
    }
  ],
  "relation": "R3四支；三个Formal将未见值说已确认，第四实际17Search后N。新4明确身份后仍查三次，独立开放链不强注册新跨题机制。",
  "counterexamples": [
    "新2无Formal，不声称其正式确认值；新1Prompt稍减但生成增加，不能笼统所有成本增加。"
  ],
  "unresolved": "特异事件可能足够唯一识别主体，未见数字不自动等同N008身份不充分；真正停止差异不能用隐藏信心补齐。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 4,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 1,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 8,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 1,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": true,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1138__rep1__S003__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1138"
    ]
  }
}
```


## unresolved

```json
{
  "case_id": "1096__rep1__S008__FIRST_SENTENCE",
  "issue": "取证前仍有不同范围的整合，未硬纳N004；全条件前后两次是否部分合并留局部歧义。"
}
```

```json
{
  "case_id": "1096__rep2__S001__FIRST_SENTENCE",
  "issue": "旧排名后来关系绑定仅一支；背景SFL核验与错读范围区分，不能强增机制。"
}
```

```json
{
  "case_id": "1096__rep2__S002__FIRST_SENTENCE",
  "issue": "新3范围错读强证、新4背景核验UNC，Formal理论等价超证据另记。"
}
```

```json
{
  "case_id": "1138__rep1__S003__FIRST_SENTENCE",
  "issue": "未知值一直缺证却三C一N，不能按主体正确忽视断言，也不能反向声称原失败U必需。"
}
```

```json
{
  "case_id": "1095__rep4__S003__FIRST_SENTENCE",
  "issue": "片子独立直接证据未恢复但主名四C，已有其它匹配是否充分待研究者。"
}
```


## 限制
全A本批不强补B；同题多切点不视多独立题，首段P0和G补偿保留。成本按真实切点和G一次入账；CHAR保守区间不伪精确。检查PASS只机械一致性，不冒充人工金标准。