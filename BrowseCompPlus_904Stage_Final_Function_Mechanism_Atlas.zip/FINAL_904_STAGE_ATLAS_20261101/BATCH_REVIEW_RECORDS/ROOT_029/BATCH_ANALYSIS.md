# ROOT_029 批次归纳

10 Stage / 10题 / 10原轨迹 / 40续跑；组别{'A': 6, 'B': 4}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "已经返回的身份/条件材料转成比较、采用或完整接受。",
  "members": [
    "261__rep4__S008__FIRST_SENTENCE",
    "270__rep3__S008__TERMINAL_DROP_NO_ANCHOR",
    "319__rep1__S004__FIRST_SENTENCE",
    "1023__rep3__S004__FIRST_SENTENCE"
  ],
  "distinction": "261首次具体作者/刊号对应，270完整纯认知接受但事实判断P已有，319当前事故数字P已采用且U比较店背景，1023当前协会证据才首次采用帽针。四类都不能只按总结名称等同。"
}
```

```json
{
  "description": "具体对象核验，补缺或排除，改变可接受范围。",
  "members": [
    "299__rep3__S002__FIRST_SENTENCE",
    "1046__rep2__S002__FIRST_SENTENCE"
  ],
  "distinction": "299建筑身份已知而人物日期未知，真查补证；1046泛探索中的Lee候选真查并排除，非已正确主体补独立条件。"
}
```

```json
{
  "description": "首次组织题目与选择外部取证入口。",
  "members": [
    "291__rep3__S001__FIRST_SENTENCE",
    "78__rep4__S001__FIRST_SENTENCE",
    "1247__rep1__S001__FIRST_SENTENCE"
  ],
  "distinction": "三组P0，291G给正确人名，78与1247G无实体却称已有结果；原291/78成功而1247原N，不能按删除一次初搜认定都损失正确采用。"
}
```

```json
{
  "description": "放弃旧搜索入口，改查领域关系以寻找新电影线索。",
  "members": [
    "980__rep2__S004__FIRST_SENTENCE"
  ],
  "distinction": "U实际Hindi/BollywoodQuery带回Sunny/Suneel争端但直接反馈未采用，Z才接Bobby/Dosti；删后四没有真实恢复此领域动作，即使一支写计划也不算Call。"
}
```


## comparisons

```json
{
  "id": "ROOT029_C1",
  "cases": [
    "270__rep3__S008__TERMINAL_DROP_NO_ANCHOR",
    "1023__rep3__S004__FIRST_SENTENCE",
    "261__rep4__S008__FIRST_SENTENCE"
  ],
  "finding": "同A稳定有不同恢复结构：270无G四重建纯接受且生成全增，1023四恢复比较并真查帽针、三支后续更短一支更长，261只有4把原补证前后两比较合成一次。",
  "counter": "少Search不能归U0Call消失；认知重建也不排除表达/后续压缩。261刊号证据不等发表年份已证，不能宣称再查刊年均多余。"
}
```

```json
{
  "id": "ROOT029_C2",
  "cases": [
    "291__rep3__S001__FIRST_SENTENCE",
    "299__rep3__S002__FIRST_SENTENCE",
    "1023__rep3__S004__FIRST_SENTENCE"
  ],
  "finding": "291两支一个真实Return同时关闭出生/双学校需求，299两支联合两人生卒，均实际采用；1023新3广告Return仅补1832机器年而无具体发明人，属于部分替代。",
  "counter": "全部一Call里出现多信息不自动N005。291G人名先给，发现与验证压缩分开；299人物日期仍靠真实新返；1023广告关系始终没闭合。"
}
```

```json
{
  "id": "ROOT029_C3",
  "cases": [
    "78__rep4__S001__FIRST_SENTENCE",
    "1247__rep1__S001__FIRST_SENTENCE"
  ],
  "finding": "P0的已有结果G可在新自主首Call前扩写未输入关系，78新1完全零工具FormalW，1247四都有真实Call，不把同来源伪叙事强并N002零工具子型。",
  "counter": "78新2取得真实Benin材料却解释错，3返后未采用，4没返；1247真查实各导演首作却对象未证。不能将所有新关系错误归完全没有真实证据。"
}
```

```json
{
  "id": "ROOT029_C4",
  "cases": [
    "1046__rep2__S002__FIRST_SENTENCE",
    "1247__rep1__S001__FIRST_SENTENCE"
  ],
  "finding": "自选对象/条件升为排他标准：1046新2实际返奥地利Signa因不符韩国排掉；1247新2实际1917符合票房却非自选Spielberg而排，新1将任一Oscar改为BestDirector。",
  "counter": "Signa线索非完整Immofina答案，1917也未证全条件；错的是核验范围/排除逻辑，不宣称当时答案已全明确。1046新3解除范围采用BenkoC，1247新1仍探索无Final，误条件不同后果。"
}
```

```json
{
  "id": "ROOT029_C5",
  "cases": [
    "980__rep2__S004__FIRST_SENTENCE",
    "319__rep1__S004__FIRST_SENTENCE",
    "1247__rep1__S001__FIRST_SENTENCE"
  ],
  "finding": "同样保留部分已证关系不能保证身份判断充分。980三已知出生冲突仍接受老片、第四也W且关键争端后返没用；1247三查实导演首作却电影身份未证；319三只取独特事故人数而不闭合连锁背景仍C。",
  "counter": "319事故和地点独特、核心答案直接充分，其部分身份接受是否与弱电影关系同类须保歧义；没有用C/W倒推机制是否发生，也不把背景未证都称相同严重缺口。"
}
```

```json
{
  "id": "ROOT029_C6",
  "cases": [
    "980__rep2__S004__FIRST_SENTENCE",
    "1046__rep2__S002__FIRST_SENTENCE",
    "1023__rep3__S004__FIRST_SENTENCE"
  ],
  "finding": "从可见到行动的桥要分原U和原Z：980U带回关系但原也延后采用，新3/4关系晚返未改行动；1046新3真实采用公司→核查，2错排；1023四P资料即时恢复采用→真实帽针Query。",
  "counter": "资料未返的路径不能说忽略，计划新入口不是真动作，首Query同但结果解释不同也不能按Query预测成功；帽针全C仍有共同广告证据缺口。"
}
```

```json
{
  "id": "ROOT029_C7",
  "cases": [
    "299__rep3__S002__FIRST_SENTENCE",
    "1247__rep1__S001__FIRST_SENTENCE",
    "270__rep3__S008__TERMINAL_DROP_NO_ANCHOR"
  ],
  "finding": "成本维度可反向：1247四工具/Prompt降但生成全增，N→W不改善；270零工具仍生成全增；299成功四真实补证但两省两费且CHAR差范围。",
  "counter": "不将同题四费用相加，不将新Formal当质量提升，不将CHAR1046成功支跨零净差伪作精确节省。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT029_T1",
  "description": "外部材料被实际采用并改变具名真查询。",
  "links": [
    {
      "case_id": "319__rep1__S004__FIRST_SENTENCE",
      "local_id": "EXACT_RETURNED_MENU_RELATION_CHANGES_CHAIN_QUERY_AND_RESOLVES_BRANCH_BRIDGE"
    },
    {
      "case_id": "1046__rep2__S002__FIRST_SENTENCE",
      "local_id": "REAL_LEE_REJECTION_REBUILT_THEN_NEW_COMPANY_RETURN_CHANGES_QUERY"
    },
    {
      "case_id": "1023__rep3__S004__FIRST_SENTENCE",
      "local_id": "AVAILABLE_SOCIETY_EVIDENCE_READOPTED_AND_USED_IN_TRUE_HATPIN_QUERY"
    }
  ],
  "relation": "P2_R1三个题，不同前态：Spur链关系新补，Benko真新对象，帽针旧P直接证据重采用。",
  "counterexamples": [
    "319另三未恢复连锁身份仍人数C；1046一支同识Lee冲突却错筛新线索；980末关系已返却无行动更新。"
  ],
  "unresolved": "行动桥不是充分正确性条件；来源P或新返、主体答案直接/间接关系都需分列。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 6,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 1,
    "excluded_rollouts": 3,
    "observed_local_chain_occurrences": 6,
    "not_observed_local_chain_occurrences": 2,
    "uncertain_local_chain_occurrences": 1,
    "excluded_local_chain_occurrences": 3,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1023__rep3__S004__FIRST_SENTENCE",
      "1046__rep2__S002__FIRST_SENTENCE",
      "319__rep1__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "319",
      "1023",
      "1046"
    ]
  }
}
```

```json
{
  "id": "ROOT029_T2",
  "description": "同一真实返回覆盖原独立多个补证需求。",
  "links": [
    {
      "case_id": "291__rep3__S001__FIRST_SENTENCE",
      "local_id": "ONE_TRUE_RETURN_COVERS_BIRTH_IDENTITY_AND_TWO_SCHOOL_EVENTS"
    },
    {
      "case_id": "299__rep3__S002__FIRST_SENTENCE",
      "local_id": "JOINT_BIOGRAPHY_RETURN_REPLACES_SEPARATE_ARCHITECT_AND_OWNER_CALLS"
    }
  ],
  "relation": "N005两题，各有真实联合支持及实际采用，非字符串共现；四支去重分组由程序算。",
  "counterexamples": [
    "1023新3只有机器年无具名发明人，不能按两缺口全部完成；299另两支仍分开查。"
  ],
  "unresolved": "291母亲actor≠经理、双学校事件错误仍独立记，联合关闭所列需求不代表整Final充分。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 4,
    "not_observed_rollouts": 4,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 4,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "291__rep3__S001__FIRST_SENTENCE",
      "299__rep3__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "291",
      "299"
    ]
  }
}
```

```json
{
  "id": "ROOT029_T3",
  "description": "一次补证后完整比较承接原补证前后的两次认知工作。",
  "links": [
    {
      "case_id": "261__rep4__S008__FIRST_SENTENCE",
      "local_id": "ONE_POST_LOOKUP_COMPARISON_RESTORES_PRE_AND_POST_COMPARISON_WORK"
    }
  ],
  "relation": "N004新4保持真实数值核验而比较移后，本批仅一个Stage/一题，不伪算跨题新发现。",
  "counterexamples": [
    "270四都重新完整接受且文本更多，不能因没有Call称比较压缩；2611/3特定刊关系未恢复不等相同功能更短。"
  ],
  "unresolved": "G数值缺口提醒影响顺序，非无引导因果。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 1,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 1,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "261__rep4__S008__FIRST_SENTENCE"
    ],
    "question_ids": [
      "261"
    ]
  }
}
```

```json
{
  "id": "ROOT029_T4",
  "description": "身份未闭合，部分事实或已经查实的次级答案被用作接受依据。",
  "links": [
    {
      "case_id": "980__rep2__S004__FIRST_SENTENCE",
      "local_id": "KNOWN_BIRTH_CONFLICT_AND_UNPROVED_FEUD_OVERRIDDEN_BY_PARTIAL_PLOT_MATCH"
    },
    {
      "case_id": "1247__rep1__S001__FIRST_SENTENCE",
      "local_id": "VERIFIED_DIRECTOR_DEBUT_SUBSTITUTES_FOR_UNRESOLVED_FILM_IDENTITY"
    },
    {
      "case_id": "319__rep1__S004__FIRST_SENTENCE",
      "local_id": "AVAILABLE_INCIDENT_ATTRIBUTE_PRIORITIZED_OVER_UNRESOLVED_CHAIN_IDENTITY"
    }
  ],
  "relation": "N008下保留不同细链：部分情节近似、次级首作验证、独特事故所求数字；319主归但强证边界单列，不把三题当同样弱证。",
  "counterexamples": [
    "1247新1同有首作却保持身份缺口不断查N；319新2真补连锁关系仍同C；1023强协会主体剩广告缺口不自动N008。"
  ],
  "unresolved": "次级答案确认替代上游身份的更细链目前本题三支，需后续不同题比对，不能提前注册普遍新机制。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 10,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 10,
    "not_observed_local_chain_occurrences": 2,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1247__rep1__S001__FIRST_SENTENCE",
      "319__rep1__S004__FIRST_SENTENCE",
      "980__rep2__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "319",
      "980",
      "1247"
    ]
  }
}
```

```json
{
  "id": "ROOT029_T5",
  "description": "假设或限定被提升为题目筛选条件，阻断其他对象继续核验。",
  "links": [
    {
      "case_id": "1046__rep2__S002__FIRST_SENTENCE",
      "local_id": "HYPOTHETICAL_REGION_BECOMES_FALSE_EXCLUSION_CRITERION_FOR_REAL_SIGNА_LEAD"
    },
    {
      "case_id": "1247__rep1__S001__FIRST_SENTENCE",
      "local_id": "SELF_ASSUMED_DIRECTOR_FILTERS_OUT_REAL_ALTERNATIVE_FILM"
    },
    {
      "case_id": "1247__rep1__S001__FIRST_SENTENCE",
      "local_id": "ANY_OSCAR_WIN_REPLACED_BY_BEST_DIRECTOR_REQUIREMENT"
    }
  ],
  "relation": "P1_K1有不同误范围；1247两个组件不重复算其同一支，distinct测试必须去重。",
  "counterexamples": [
    "1046新3可采用异国线索，1247新4明确不限导演类别仍错接受；约束错误不解释所有失败。"
  ],
  "unresolved": "晚误拒仅解释后续一段行动，不把之前全部Token差归该判断。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 4,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 1,
    "excluded_rollouts": 4,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 1,
    "excluded_local_chain_occurrences": 4,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": true,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1046__rep2__S002__FIRST_SENTENCE",
      "1247__rep1__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "1046",
      "1247"
    ]
  }
}
```

```json
{
  "id": "ROOT029_T6",
  "description": "正确核心采用后，残余关系缺口驱动真实核验与接受。",
  "links": [
    {
      "case_id": "261__rep4__S008__FIRST_SENTENCE",
      "local_id": "PAPER_IDENTITY_STABLE_NUMERIC_AND_JOURNAL_GAPS_DISPATCH_TRUE_CHECKS"
    },
    {
      "case_id": "1023__rep3__S004__FIRST_SENTENCE",
      "local_id": "IDENTITY_RESTORED_UNCLOSED_AD_RELATION_CONTINUES_REAL_VERIFICATION"
    }
  ],
  "relation": "P2_R3两题实际需求，不能称重复核验都无价值；261刊年/表数尚缺，帽针完整广告截断。",
  "counterexamples": [
    "270无新工具不适用实际核验；78/1247主体错误不归正确核心；1023新1多查但C且更费，不是多查必N。"
  ],
  "unresolved": "可观察末接受与Query停止，却不唯一知道为何此轮认为足够。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 8,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 8,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1023__rep3__S004__FIRST_SENTENCE",
      "261__rep4__S008__FIRST_SENTENCE"
    ],
    "question_ids": [
      "261",
      "1023"
    ]
  }
}
```

```json
{
  "id": "ROOT029_T7",
  "description": "P0来源叙事引导被扩写为无真实结果支持的事实。",
  "links": [
    {
      "case_id": "78__rep4__S001__FIRST_SENTENCE",
      "local_id": "EMPTY_HISTORY_GUIDE_SOURCE_NARRATIVE_EXPANDED_TO_FAKE_DYNASTIC_FACTS_WITHOUT_SEARCH"
    },
    {
      "case_id": "1247__rep1__S001__FIRST_SENTENCE",
      "local_id": "EMPTY_HISTORY_GUIDE_RESULTS_NARRATIVE_PRECEDES_UNGROUNDED_CANDIDATE_SELECTION"
    }
  ],
  "relation": "来源叙事开放比较，严格N002只有78新1零工具Formal，其余都有真实查询不得放宽。",
  "counterexamples": [
    "相同P0G四次不同实体/行动，不能认定G本身给具体答案；291G给真实答案姓名是另一类信息泄漏。"
  ],
  "unresolved": "整题重采样和教师叙事不可分，无无G组不作纯因果。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 5,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 2,
    "observed_local_chain_occurrences": 5,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 2,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1247__rep1__S001__FIRST_SENTENCE",
      "78__rep4__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "78",
      "1247"
    ]
  }
}
```

```json
{
  "id": "ROOT029_T8",
  "description": "认知采用恢复后，后续执行顺序和证据充分性仍不同。",
  "links": [
    {
      "case_id": "1023__rep3__S004__FIRST_SENTENCE",
      "local_id": "AD_QUERY_INCIDENTAL_MACHINE_YEAR_REPLACES_ONLY_PART_OF_SEPARATE_MACHINE_WORK"
    },
    {
      "case_id": "270__rep3__S008__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "ALREADY_ACCEPTED_FACTS_REGENERATE_FULL_COGNITIVE_COMPARISON_WITHOUT_NEW_TOOL"
    }
  ],
  "relation": "开放反对重建=路线/成本相同：帽针变证据入口部分替代，年龄四同知识无新Call而更长。不是同新机制强合两工作。",
  "counterexamples": [
    "帽针3少机器Call但缺人名，年龄完全已有事实可充分答却仍生更多文字；成本减不等功能消失。"
  ],
  "unresolved": "先保具体差异，等待跨题同细链而非从结果保持构造单一冗余解释。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 5,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 5,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "1023__rep3__S004__FIRST_SENTENCE",
      "270__rep3__S008__TERMINAL_DROP_NO_ANCHOR"
    ],
    "question_ids": [
      "270",
      "1023"
    ]
  }
}
```


## unresolved

```json
{
  "case_id": "319__rep1__S004__FIRST_SENTENCE",
  "issue": "N008强独特事故人数与连锁背景未闭的边界保留主方案/备选；不能只因最后C删掉观察或把事故强证说弱猜。"
}
```

```json
{
  "case_id": "1247__rep1__S001__FIRST_SENTENCE",
  "issue": "查实次级首作跨过未证主体的细链目前一题三支，反例一支N；存在错误获奖事实、G假来源和全题重采样混杂。"
}
```

```json
{
  "case_id": "1023__rep3__S004__FIRST_SENTENCE",
  "issue": "广告关系原新均未完整获得；3机器年真实但发明人未证，不能宣称质量无损或N005全部关闭。"
}
```

```json
{
  "case_id": "1046__rep2__S002__FIRST_SENTENCE",
  "issue": "CHAR原2462—2659宽区间，新3净生成跨零；真实Signa只候选线索非完整答案，地区错排只证后段。"
}
```

```json
{
  "case_id": "261__rep4__S008__FIRST_SENTENCE",
  "issue": "39924刊号不证发表年，已核上传2025与题目发表窗不同；同Query/Return仍可采用不同，不能关键词判断。"
}
```


## 限制
本批六A四B来自现有剩余分配，无预定平衡强换样本；十Stage十题四十续跑，FIRST与末段G0分开，采样/G/预算与质量混杂保留；机械通过不等独立人工语义金标准。