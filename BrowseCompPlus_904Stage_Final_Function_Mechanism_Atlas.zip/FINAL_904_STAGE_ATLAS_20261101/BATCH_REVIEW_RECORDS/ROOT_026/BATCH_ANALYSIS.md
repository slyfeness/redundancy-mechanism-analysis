# ROOT_026 批次归纳

10 Stage / 10题 / 10原轨迹 / 40续跑；组别{'A': 5, 'B': 5}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "已经有正确身份后完整条件接受与答案组织，或以已确认关系安排具体条件核查。",
  "members": [
    "257__rep3__S005__TERMINAL_DROP_NO_ANCHOR",
    "270__rep3__S005__FIRST_SENTENCE"
  ],
  "distinction": "257P已采用1986与出版社别名，U纯比较；四G0重做比较，其中两又真查已知别名。270P47但城市日期无证，U三失败取证；四都重做城市功能，次数/批次和最后生日核查各异。两种A不是同样重复确认可省。"
}
```

```json
{
  "description": "把已返回的候选材料采用为接下来具体查询对象。",
  "members": [
    "78__rep4__S002__FIRST_SENTENCE",
    "261__rep4__S005__FIRST_SENTENCE",
    "291__rep2__S002__FIRST_SENTENCE"
  ],
  "distinction": "78P Ovon材料未采用，U纯采用与父亲/学校安排；261正确论文旧Return未采用，U实际再次取证后采用；291U实际补身份生日，Z再补学校。三A新功能普遍恢复，但291新3一真实返回同时供两待查关系，才有独立补查减少的具体落点。"
}
```

```json
{
  "description": "候选未知情况下作真实开放取证，产物可能发现正确对象，也可能只是失败反馈。",
  "members": [
    "353__rep4__S003__FIRST_SENTENCE",
    "688__rep3__S003__FIRST_SENTENCE",
    "689__rep4__S007__FIRST_SENTENCE",
    "773__rep3__S002__FIRST_SENTENCE",
    "873__rep3__S001__FIRST_SENTENCE"
  ],
  "distinction": "688U最后取得Ike，Z才采用；其余四个U未获得合题身份，不能把原后继后来见过的正确片段或原C泛化为U已给正确判断。873P0初始十Call，是重启情形，不当成熟信息状态删除对照。"
}
```


## comparisons

```json
{
  "id": "ROOT026_C1",
  "cases": [
    "78__rep4__S002__FIRST_SENTENCE",
    "261__rep4__S005__FIRST_SENTENCE",
    "688__rep3__S003__FIRST_SENTENCE"
  ],
  "finding": "返回与采用再与真实行动分开。78新四条均实际恢复身份核验但一条UNC；261四条采用论文并真查都C却数表仍未证；6881/4也采用Ike并查全名，但多届奥运仍驱动取证直到N。",
  "counter": "同一材料到行动更新既不保证Final，也不保证更省。688U只获得材料、Z采用，不能把后继接受倒写入U；78G预给Benin/父亲行动而688G只有found框架，补偿不同。"
}
```

```json
{
  "id": "ROOT026_C2",
  "cases": [
    "257__rep3__S005__TERMINAL_DROP_NO_ANCHOR",
    "291__rep2__S002__FIRST_SENTENCE",
    "270__rep3__S005__FIRST_SENTENCE"
  ],
  "finding": "A结果保持的成本来源不同。257比较四重建，两零Call两新Call，只有部分生成少且Prompt都因重放略增；291新3真返回同时有生日/学校并使用，少原独立学校查询；270城市四恢复，2四次城市比U三次更多但批处理/少末生日使Actor少。",
  "counter": "四次C不等相同路线或同一冗余机制；功能重建不排除组织压缩，更多目标查询也不妨某维更省。不同支省量不相加。"
}
```

```json
{
  "id": "ROOT026_C3",
  "cases": [
    "353__rep4__S003__FIRST_SENTENCE",
    "689__rep4__S007__FIRST_SENTENCE",
    "773__rep3__S002__FIRST_SENTENCE"
  ],
  "finding": "失败取证重做后，接受依据不同。3532以题材日期替代作者条件W；6893先分清奖项又恢复错绑，生年冲突仍部分接受W；7731/2/4以衣物可回答性替代案件身份W。相应其它支可能正式拒答或继续到N。",
  "counter": "共同的部分标准覆盖身份有明确接受原文，不是凭Wrong结果归类。6892/4拒答W、3533拒答W、7733N不命中该接受，状态同W也可不同工作。"
}
```

```json
{
  "id": "ROOT026_C4",
  "cases": [
    "688__rep3__S003__FIRST_SENTENCE",
    "773__rep3__S002__FIRST_SENTENCE"
  ],
  "finding": "同样未提交可从不同中间环节来。6881/4已正确采用但奥运未闭；6883固定Calathes；6882末10K无Call计划。7733保持日期冲突却仍含white的复合Query到上限。",
  "counter": "不能统一叫未读证据或没重建；6883生成较短但Search/Prompt增，6882大增Token主因不是多次真实Search。"
}
```

```json
{
  "id": "ROOT026_C5",
  "cases": [
    "689__rep4__S007__FIRST_SENTENCE",
    "873__rep3__S001__FIRST_SENTENCE"
  ],
  "finding": "B原N多数变W可以只是结束方式变化。689有两正式拒答、一错人接受、一N；873四正式未给27，1/3还把题面概述省略误当来源原文缺项，2/4保留未知或库外可能。",
  "counter": "B不能直接作原U重要性或删除改善依据；原U两案都失败，873还是P0重启。没有正确目标博客，不能套已返未采用。"
}
```

```json
{
  "id": "ROOT026_C6",
  "cases": [
    "353__rep4__S003__FIRST_SENTENCE",
    "291__rep2__S002__FIRST_SENTENCE"
  ],
  "finding": "真实新入口可以减少后继工作，但证据闭合程度不同。3531literal重做失败，再gossip得书查作者，省原长资格年号泛查；2913身份Return还给学校，直接使用而免第二独立查。",
  "counter": "353作者精确MSc年仍未证，N→C不是全约束闭合；291母亲管理未证，核心答案C与辅助支持质量单列。不是一次多字段片段就自动N005，须确有原独立需求/步骤被覆盖。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT026_T1",
  "description": "材料采用进入真实具体行动，恢复不保证正常提交。",
  "links": [
    {
      "case_id": "688__rep3__S003__FIRST_SENTENCE",
      "local_id": "LATE_CORRECT_RETURN_ADOPTION_STILL_BECOMES_REAL_IKE_QUERY"
    },
    {
      "case_id": "353__rep4__S003__FIRST_SENTENCE",
      "local_id": "AFTER_LITERAL_FAILURE_TRUE_GOSSIP_ENTRY_RETURNS_BOOK_AND_CHANGES_AUTHOR_QUERY"
    },
    {
      "case_id": "689__rep4__S007__FIRST_SENTENCE",
      "local_id": "VISIBLE_BOOKMONTH_CANDIDATE_USED_FOR_TRUE_HYPOTHESIS_CHECK_NOT_CONFIRMED_TIME"
    }
  ],
  "relation": "P2_R1：6881/4正确身份后N；3531新书/作者C；6894部分奖项候选只待核而非确认TIME，最后拒答W。",
  "counterexamples": [
    "不能把6893自身知识错绑当当前真实Return的正确提取；6882/3没恢复正确人，不强凑四同链。"
  ],
  "unresolved": "采用可能正确或仅合法假设，质量/额外核验须另看，U取得材料与Z采用不可倒置。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 4,
    "not_observed_rollouts": 8,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 8,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "353__rep4__S003__FIRST_SENTENCE",
      "688__rep3__S003__FIRST_SENTENCE",
      "689__rep4__S007__FIRST_SENTENCE"
    ],
    "question_ids": [
      "353",
      "688",
      "689"
    ]
  }
}
```

```json
{
  "id": "ROOT026_T2",
  "description": "正确核心采用后剩余条件真实派发，成功与停止不由主体恢复自动决定。",
  "links": [
    {
      "case_id": "688__rep3__S003__FIRST_SENTENCE",
      "local_id": "RECOVERED_IKE_IDENTITY_STILL_LEAVES_MULTI_OLYMPICS_DISPATCH_GAP"
    },
    {
      "case_id": "353__rep4__S003__FIRST_SENTENCE",
      "local_id": "SPECIFIC_GOOD_AUTHOR_STILL_TRIGGERS_REAL_MSC_YEAR_CHECK"
    }
  ],
  "relation": "P2_R3：6881/4具体奥运、3531精确学年，均真实执行。",
  "counterexamples": [
    "688身份全名已恢复却N，3531仍C但学年未得；不能一概核验必要或多余。"
  ],
  "unresolved": "原U独特改变停止行为未被唯一识别，不猜隐藏信心阈值。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 3,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 5,
    "observed_local_chain_occurrences": 3,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 5,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "353__rep4__S003__FIRST_SENTENCE",
      "688__rep3__S003__FIRST_SENTENCE"
    ],
    "question_ids": [
      "353",
      "688"
    ]
  }
}
```

```json
{
  "id": "ROOT026_T3",
  "description": "固定具体对象未闭属性反馈后仍派真实查询，额外输入与少字可共存。",
  "links": [
    {
      "case_id": "353__rep4__S003__FIRST_SENTENCE",
      "local_id": "OLD_CARROLL_ATTRIBUTES_REPEATEDLY_CHECKED_WITHOUT_IDENTITY_SUPPORT"
    },
    {
      "case_id": "688__rep3__S003__FIRST_SENTENCE",
      "local_id": "FIXED_CALATHES_RELATION_GAP_REISSUES_WITHOUT_OBJECT_UPDATE"
    },
    {
      "case_id": "773__rep3__S002__FIRST_SENTENCE",
      "local_id": "KEPT_TIME_CONFLICT_STILL_REISSUES_WHITE_CONSTRAINED_CASE_QUERY"
    }
  ],
  "relation": "P1_K3：Carroll作者资格、Calathes选秀/奥运、部分案件身份/white组合不同具体需求，不只字符串相同。",
  "counterexamples": [
    "3533真转Julie不归固定旧人；6882最后纯计划非本链；7731/2/4最终早接受不是同样预算重复。"
  ],
  "unresolved": "不把检索未得当不存在证明，不给全部重复都无价值结论。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 4,
    "not_observed_rollouts": 8,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 8,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "353__rep4__S003__FIRST_SENTENCE",
      "688__rep3__S003__FIRST_SENTENCE",
      "773__rep3__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "353",
      "688",
      "773"
    ]
  }
}
```

```json
{
  "id": "ROOT026_T4",
  "description": "一次真实身份Return实际覆盖生日与学校两个未解需求，减少原独立学校查询。",
  "links": [
    {
      "case_id": "291__rep2__S002__FIRST_SENTENCE",
      "local_id": "ONE_TRUE_IDENTITY_RETURN_SUPPLIES_AND_USES_BIRTH_AND_SCHOOL_NEEDS"
    }
  ],
  "relation": "N005仅新3，一Call多个真实Doc可共同供证，明确使用两者；原U身份生日、Z学校各真实Call。",
  "counterexamples": [
    "另三条仍各走独立查询；单篇本来联合一次或信息未被采用不够此机制。"
  ],
  "unresolved": "母亲管理原新未证，不能把核心C当全要求证据保持；成本四维分账。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 1,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 1,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "291__rep2__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "291"
    ]
  }
}
```

```json
{
  "id": "ROOT026_T5",
  "description": "部分身份标准被提升为充分接受，已知冲突或关键身份条件未闭。",
  "links": [
    {
      "case_id": "353__rep4__S003__FIRST_SENTENCE",
      "local_id": "TOPIC_DATE_ACCEPTANCE_WITH_THREE_UNVERIFIED_AUTHOR_CONSTRAINTS"
    },
    {
      "case_id": "689__rep4__S007__FIRST_SENTENCE",
      "local_id": "WRONG_AWARD_ANCHOR_PROMOTED_TO_ENOUGH_IDENTITY_DESPITE_BIRTH_CONFLICT"
    },
    {
      "case_id": "773__rep3__S002__FIRST_SENTENCE",
      "local_id": "SHIRT_ATTRIBUTE_OR_MOST_RELEVANT_RECORD_PROMOTED_TO_FULL_CASE_IDENTITY"
    }
  ],
  "relation": "N008：3532题材日期、6893假TIME锚、7731/2/4衣物/时间借口，各有明确接受原文和正式错误对象/属性。",
  "counterexamples": [
    "3531强书作者身份仅精确学年缺不硬并，3533/6892/4拒答W不正；7733有同材料但无Formal排除。"
  ],
  "unresolved": "各案接受依据不同，原U都非已成功的正确身份判断；B状态变化不自动证明被删功能必要。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 5,
    "not_observed_rollouts": 4,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 3,
    "observed_local_chain_occurrences": 5,
    "not_observed_local_chain_occurrences": 4,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 3,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "353__rep4__S003__FIRST_SENTENCE",
      "689__rep4__S007__FIRST_SENTENCE",
      "773__rep3__S002__FIRST_SENTENCE"
    ],
    "question_ids": [
      "353",
      "689",
      "773"
    ]
  }
}
```

```json
{
  "id": "ROOT026_T6",
  "description": "同一奖项区别曾识别，后被自身知识错绑覆盖并改变对象核验与提交。",
  "links": [
    {
      "case_id": "689__rep4__S007__FIRST_SENTENCE",
      "local_id": "SELF_ASSERTED_TIME_BINDING_DIRECTS_WRONG_PERSON_CHECK_DESPITE_LATER_DISTINCTION"
    }
  ],
  "relation": "P1_K1新3；新4同书BookMonth待核→真实查人→持续承认不是TIME，构成同题反例。",
  "counterexamples": [
    "错误Final的Princeton/Jason关系不可自动说导致此前额外任务；要有真查询证据。"
  ],
  "unresolved": "知道区别与区别持续约束后续不同；无法从单组确定错绑恢复的内部原因。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 1,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 1,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "689__rep4__S007__FIRST_SENTENCE"
    ],
    "question_ids": [
      "689"
    ]
  }
}
```

```json
{
  "id": "ROOT026_T7",
  "description": "相同N终态下实际成本增量来自不同执行部位。",
  "links": [
    {
      "case_id": "688__rep3__S003__FIRST_SENTENCE",
      "local_id": "LAST_LONG_GREEK_PLANNING_EXPANDS_GENERATION_WITHOUT_NEW_SEARCH"
    },
    {
      "case_id": "689__rep4__S007__FIRST_SENTENCE",
      "local_id": "AWARD_LOOKUP_FAILURE_RETRIES_WITHOUT_CONCRETE_AUTHOR_UPDATE"
    }
  ],
  "relation": "开放叶：6882末10000纯生成，6891九真实查询但背景更短，不能以都重复或都无Final合成单机制。",
  "counterexamples": [
    "6883少558生成却多3Search与116231Prompt，6891Search同9，省937—938生成不等少工具。"
  ],
  "unresolved": "缺未发新Call的唯一内部原因，明确不从计划文本补真实事件。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 2,
    "not_observed_rollouts": 6,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 2,
    "not_observed_local_chain_occurrences": 6,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "688__rep3__S003__FIRST_SENTENCE",
      "689__rep4__S007__FIRST_SENTENCE"
    ],
    "question_ids": [
      "688",
      "689"
    ]
  }
}
```

```json
{
  "id": "ROOT026_T8",
  "description": "未找到来源后的缺证处理，不同于具体候选部分身份接受。",
  "links": [
    {
      "case_id": "873__rep3__S001__FIRST_SENTENCE",
      "local_id": "PROMPT_SUMMARY_OMISSION_SUBSTITUTES_FOR_UNREAD_SOURCE_ABSENCE"
    },
    {
      "case_id": "873__rep3__S001__FIRST_SENTENCE",
      "local_id": "FEWER_FAILED_LOOKUPS_END_IN_EXPLICIT_UNKNOWN_WITHOUT_SOLVING_SOURCE_IDENTITY"
    }
  ],
  "relation": "开放两分量：1/3把题面省略当来源缺项，2/4只未知或库外可能；不强套N008、N003或已有M标签。",
  "counterexamples": [
    "四W都更短却非同证据结论，2加粗24—25仍限定首篇不得错提答案。"
  ],
  "unresolved": "首StageP0、reconsiderG无事实但有框架，归因限制强；不能以短检索失败证明库中不存在。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 4,
    "not_observed_rollouts": 4,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 4,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": true,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "873__rep3__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "873"
    ]
  }
}
```

```json
{
  "id": "ROOT026_T9",
  "description": "候选频繁出现可能参与接受，但与材料可回答性竞争，保留歧义。",
  "links": [
    {
      "case_id": "773__rep3__S002__FIRST_SENTENCE",
      "local_id": "REPEATED_KARLIE_NAME_MAY_SUPPORT_ACCEPTANCE_BUT_ATTRIBUTE_RELEVANCE_COMPETES"
    }
  ],
  "relation": "N007新1unc，不加入确定支持；明确most relevant足以支持N008，不能以出现次数偷换独立因果。",
  "counterexamples": [
    "3同名材料也常返却未提交，2/4另有时间/唯一衣物理由。"
  ],
  "unresolved": "不强行用同个W覆盖所有细粒度接受依据。",
  "deterministic_counts": {
    "observed_stage_count": 0,
    "different_questions": 0,
    "original_runs": 0,
    "observed_rollouts": 0,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 1,
    "excluded_rollouts": 1,
    "observed_local_chain_occurrences": 0,
    "not_observed_local_chain_occurrences": 2,
    "uncertain_local_chain_occurrences": 1,
    "excluded_local_chain_occurrences": 1,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [],
    "question_ids": []
  }
}
```


## unresolved

```json
{
  "case_id": "78__rep4__S002__FIRST_SENTENCE",
  "issue": "原材料采用恢复但G补对象/父亲方向，一UNC把当前/祖父角色放反，不改旧评价；学历关系部分仍混用。"
}
```

```json
{
  "case_id": "257__rep3__S005__TERMINAL_DROP_NO_ANCHOR",
  "issue": "完整接受重建，2支额外别名确认；题外版本细节及Prompt重放92不混原U新增证据。"
}
```

```json
{
  "case_id": "261__rep4__S005__FIRST_SENTENCE",
  "issue": "论文身份四恢复且C，精确数字/六表与期刊另一篇仍缺，部分Formal直接肯定；不自动N008。"
}
```

```json
{
  "case_id": "270__rep3__S005__FIRST_SENTENCE",
  "issue": "城市功能四恢复但次数/批次与末生日查不同，四C并未证城市日期，不能把所有核验视省掉。"
}
```

```json
{
  "case_id": "291__rep2__S002__FIRST_SENTENCE",
  "issue": "新3两需求共同供证可定位，但母亲管理还未证；2无源weekend→管理解释不作强错误派工。"
}
```

```json
{
  "case_id": "353__rep4__S003__FIRST_SENTENCE",
  "issue": "成功1同Query重做后另入口取得正确书，不说U失败本身变成正确身份；学年暂推断随即真查，不硬当稳定假前提。"
}
```

```json
{
  "case_id": "688__rep3__S003__FIRST_SENTENCE",
  "issue": "身份恢复仍N与身份没恢复N分开，纯10K计划与真实Call增加分开；原提交所需奥运条件也未全直接证。"
}
```

```json
{
  "case_id": "689__rep4__S007__FIRST_SENTENCE",
  "issue": "BookMonth与TIME纠错后又失效有原文，不能漏掉修复；两拒答W与错身份W分开。"
}
```

```json
{
  "case_id": "773__rep3__S002__FIRST_SENTENCE",
  "issue": "P已日期冲突，四新重做早年需求；红Return无身份闭合，频次N007仅unc。"
}
```

```json
{
  "case_id": "873__rep3__S001__FIRST_SENTENCE",
  "issue": "空P重启、四失败结束方式变化，不认检索穷尽；新2加粗首篇值不当次篇采纳。"
}
```


## 限制
十Stage十题十原轨迹四十续跑，A/B各五，9首句1末段G0，精确与CHAR分开；873P0标重启，G仅一次计费。原CWN和UNC沿用封存口径，证据质量单列，N→W不可称正确性改善。多分量按case/repeat去重，非互斥，独立分支节省不得相加。Codex语义自审不是独立研究者金标准。