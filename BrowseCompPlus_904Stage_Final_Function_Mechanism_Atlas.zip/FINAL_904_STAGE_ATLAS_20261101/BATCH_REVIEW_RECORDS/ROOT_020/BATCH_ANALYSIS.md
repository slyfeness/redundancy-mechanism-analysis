# ROOT_020 批次归纳

10 Stage / 10题 / 10原轨迹 / 40续跑；组别{'A': 5, 'B': 5}。

以下机制是本人逐案裁定后的过程解释；统计由显式成员复算，非研究者独立人工金标准。


## functions

```json
{
  "description": "正确人物/关系已部分采用，对明确缺口真实取证并直接解释。",
  "members": [
    "69__rep4__S005__FIRST_SENTENCE"
  ],
  "distinction": "新闻/人名已在P但学历/配偶关系未取得；四条恢复联合真实补证，生成减少不等输入减少。"
}
```

```json
{
  "description": "已有核心或材料之后，将局部解释、全条件比较与接受组织起来。",
  "members": [
    "78__rep2__S009__TERMINAL_DROP_NO_ANCHOR",
    "87__rep4__S004__FIRST_SENTENCE"
  ],
  "distinction": "78已有名字及够答决定，原U纯认知无Call，四支认知都重建且两支额外家系查；87专家补证前后完整比较可合并后置，不能按少字或多Call判断认知实例。"
}
```

```json
{
  "description": "首次把材料转为具体人物/书以及所问角色，再引出定向取证。",
  "members": [
    "191__rep4__S001__FIRST_SENTENCE",
    "257__rep1__S005__FIRST_SENTENCE"
  ],
  "distinction": "191空P发现Tim，257已有情节未采用、U采用书与原出版社角色；两G都提前给正确答案实体，四C不证明首次发现/更新冗余。"
}
```

```json
{
  "description": "候选人物已知，真实取得此前没有的关键关系并用于答案对象。",
  "members": [
    "228__rep1__S010__FIRST_SENTENCE"
  ],
  "distinction": "人物/毕业校不等建筑校，U首次真得并采用Stanford桥；删后查相同人物仍没取得桥，不能判FULL重建。"
}
```

```json
{
  "description": "初次拆题与查询计划，实际工具未执行就停止。",
  "members": [
    "55__rep3__S001__TERMINAL_DROP_NO_ANCHOR"
  ],
  "distinction": "唯一Stage从空P重启，三C不是删掉有害判断；原没有人物或后继，必须RESTART_NOT_PROVEN_STAGE_SKIP。"
}
```

```json
{
  "description": "失败的一次具体对象/证据入口试探，未形成有效状态更新。",
  "members": [
    "342__rep1__S004__FIRST_SENTENCE",
    "353__rep1__S007__FIRST_SENTENCE"
  ],
  "distinction": "342具体Ken身体尝试、353主题+科技年限扩展找其它书；失败功能可重建但路线/接受仍不同，不把失败无新事实自动称无用。"
}
```

```json
{
  "description": "换证据入口获得其它公司材料，但没有将它变成候选行动。",
  "members": [
    "427__rep1__S004__FIRST_SENTENCE"
  ],
  "distinction": "广查面积真返Guerlain却未用；新2具名厂区查也返同文仍旧对象。入口可见、材料充分和实际采用分开。"
}
```


## comparisons

```json
{
  "id": "ROOT020_C1",
  "cases": [
    "191__rep4__S001__FIRST_SENTENCE",
    "257__rep1__S005__FIRST_SENTENCE",
    "69__rep4__S005__FIRST_SENTENCE"
  ],
  "finding": "A中答案保持有不同前提。191空P/257无正确出版社，G直接给原U才产生的实体；69人物已在P、G只普通承接，四支真补此前关系。不能将三例四C都解作前文已经完成。",
  "counter": "191节目关系间接且额外日期任务，257三支交互更贵，69四支Prompt都升；正确率保持不意味着事实完整或全部资源减少。"
}
```

```json
{
  "id": "ROOT020_C2",
  "cases": [
    "78__rep2__S009__TERMINAL_DROP_NO_ANCHOR",
    "87__rep4__S004__FIRST_SENTENCE"
  ],
  "finding": "同是删认知比较，78四支完整认知功能都恢复，只短表达或新增家系Call；87三支把前后两完整比较集中补证后一次，另支仍两次。必须数完整实际比较，不用Call数或篇幅代替。",
  "counter": "87新4少一次完整比较却多故事Call/Prompt；78两支无工具更短却认知完整，反对所有短化都称实例压缩。"
}
```

```json
{
  "id": "ROOT020_C3",
  "cases": [
    "257__rep1__S005__FIRST_SENTENCE",
    "228__rep1__S010__FIRST_SENTENCE"
  ],
  "finding": "两U都建立题目要求的关系；257四新均重新拿到原版书目，关系快慢决定后续补证多少；228四新都缺真实捐赠桥，母校/合作关系被填入捐赠目的地，真实建筑任务由此生成。区分缺证与已有材料尚未形成正确角色解释。",
  "counter": "257G给正确实体/228G只allconstraints框架，不能把两者当纯信息状态受控对照；228新3说非等价也没解除查询前提。"
}
```

```json
{
  "id": "ROOT020_C4",
  "cases": [
    "353__rep1__S007__FIRST_SENTENCE",
    "427__rep1__S004__FIRST_SENTENCE",
    "55__rep3__S001__TERMINAL_DROP_NO_ANCHOR"
  ],
  "finding": "都可能有未闭关系但接受依据不同。353主题/日期代作者资格、427后代/产品代完整公司身份，部分身份匹配被明确视足够并W；55评者已有书评签名直接支持，缺的是刊物卷次等关联，三C不能不分前提硬并同一弱身份机制。",
  "counter": "两B各一条同候选/缺口继续真查N；55新4错绑卷表又产生额外缺口，不能以有Final或有缺口就判断相同。"
}
```

```json
{
  "id": "ROOT020_C5",
  "cases": [
    "342__rep1__S004__FIRST_SENTENCE",
    "228__rep1__S010__FIRST_SENTENCE",
    "427__rep1__S004__FIRST_SENTENCE"
  ],
  "finding": "知道关系/警告不等约束行动。342新3正确Porsche时间关系能说出但真查Ford；228新3说合作不等捐赠仍查Webster；427新2真返另一公司工厂仍查Underwood。反面342新1把P旧正确关系用到Richard真Query。",
  "counter": "Porsche解释已展开、Webster是非等价警告、Guerlain只是可见片段，各中间状态不同，不把三者都说忽略已确认答案。"
}
```

```json
{
  "id": "ROOT020_C6",
  "cases": [
    "55__rep3__S001__TERMINAL_DROP_NO_ANCHOR",
    "342__rep1__S004__FIRST_SENTENCE",
    "353__rep1__S007__FIRST_SENTENCE",
    "427__rep1__S004__FIRST_SENTENCE"
  ],
  "finding": "B包含空停重启、失败对象试探、失败广搜和未采用入口，原U价值不由3/4变化率决定。55三C全增耗，342一C身体仍缺，353/427 N变W仍未成功；四次终态须与实际工作分开。",
  "counter": "同一功能重建可C/W/N，甚至同N不同真实工作；不能用B定义直接宣称关键不可省。"
}
```


## mechanism_tests

```json
{
  "id": "ROOT020_T1",
  "description": "G首次给原U才发现/确定的答案实体，后续真取证但自主发现受补偿。",
  "links": [
    {
      "case_id": "191__rep4__S001__FIRST_SENTENCE",
      "local_id": "UNKNOWN_PERSON_DISCOVERY_REPLACED_BY_GUIDED_NAME"
    }
  ],
  "relation": "与257出版G审计比较；不注册为模型自主机制，不由四C认冗余。",
  "counterexamples": [
    "69人名原在P而G普通承接，不能同算首次实体补偿。"
  ],
  "unresolved": "G/采样/删除对省广搜贡献不能分离。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 4,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "191__rep4__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "191"
    ]
  }
}
```

```json
{
  "id": "ROOT020_T2",
  "description": "预留正确人物和具体缺口，真联合补原U关系并使用。",
  "links": [
    {
      "case_id": "69__rep4__S005__FIRST_SENTENCE",
      "local_id": "ADOPTED_PERSON_AND_EXPLICIT_GAPS_RESTORE_REAL_JOINT_EVIDENCE"
    }
  ],
  "relation": "P1_K2；原本也联合补关系，不按一次新返回多事实硬加N005。",
  "counterexamples": [
    "四C生成均少，Prompt却全多，功能恢复/成本分列。"
  ],
  "unresolved": "局部合并比较是否造成字数减少需实际实例证据，不从长度猜。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 4,
    "not_observed_rollouts": 0,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 4,
    "not_observed_local_chain_occurrences": 0,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "69__rep4__S005__FIRST_SENTENCE"
    ],
    "question_ids": [
      "69"
    ]
  }
}
```

```json
{
  "id": "ROOT020_T3",
  "description": "完整比较实例补证后合并，与单次完整认知恢复区分。",
  "links": [
    {
      "case_id": "87__rep4__S004__FIRST_SENTENCE",
      "local_id": "FULL_PRECOMPARISON_CONSOLIDATED_AFTER_LINGUIST_RETURN"
    }
  ],
  "relation": "N004，1/3/4一次证后完整比较，2仍前后两次；对照78四条认知重建不并此类。",
  "counterexamples": [
    "新4额外Search/高Prompt不排除少一次完整比较；新2更短不等少实例。"
  ],
  "unresolved": "G恰盖后继全推理是动作补偿，保留异常而非严格可省。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 3,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 3,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "87__rep4__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "87"
    ]
  }
}
```

```json
{
  "id": "ROOT020_T4",
  "description": "正确主体已采用后，残余关系仍实际派发取证。",
  "links": [
    {
      "case_id": "78__rep2__S009__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "KNOWN_NAME_RESIDUAL_LINEAGE_NEED_DISPATCHES_REAL_CHECK"
    },
    {
      "case_id": "55__rep3__S001__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "SOURCED_REVIEWER_RETAINED_WHILE_VOLUME_BRIDGE_DISPATCHES_CHECKS"
    }
  ],
  "relation": "P2_R3，分别家系与期刊卷次，姓名有独立支持；不以辅助二字说无需查。",
  "counterexamples": [
    "78另两只认知仍C，55新1有姓名仍N；额外查是否使接受更充分未必可定位。"
  ],
  "unresolved": "55原仅重启不能将后继机制归原U独特作用。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 6,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 6,
    "not_observed_local_chain_occurrences": 2,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "55__rep3__S001__TERMINAL_DROP_NO_ANCHOR",
      "78__rep2__S009__TERMINAL_DROP_NO_ANCHOR"
    ],
    "question_ids": [
      "55",
      "78"
    ]
  }
}
```

```json
{
  "id": "ROOT020_T5",
  "description": "材料/角色采用变真实定向Query，正确与错误解释可共享行动衔接。",
  "links": [
    {
      "case_id": "257__rep1__S005__FIRST_SENTENCE",
      "local_id": "ORIGINAL_EDITION_RELATION_RESTORED_THEN_REAL_FOUNDING_QUERY"
    },
    {
      "case_id": "228__rep1__S010__FIRST_SENTENCE",
      "local_id": "PARTNERSHIP_RETURN_REALIZED_AS_WEBSTER_BUILDING_QUERY"
    },
    {
      "case_id": "342__rep1__S004__FIRST_SENTENCE",
      "local_id": "RETAINED_PORSCHE_TIME_RELATION_REENTERED_REAL_RICHARD_QUERY"
    }
  ],
  "relation": "P2_R1不改定义；257关系恢复后查正确角色，228错误扩展也真实驱动动作，342只有一支正确关系变实查。",
  "counterexamples": [
    "257新2先G Query后才闭关系，不把先前动作倒排为采用后；342新3能说正确关系不真查；228新1临时Webster采用依据不足unc。"
  ],
  "unresolved": "可见关系推进行动不保证关系正确，也不保证全题提交。",
  "deterministic_counts": {
    "observed_stage_count": 3,
    "different_questions": 3,
    "original_runs": 3,
    "observed_rollouts": 7,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 3,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 7,
    "not_observed_local_chain_occurrences": 2,
    "uncertain_local_chain_occurrences": 3,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 12,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "228__rep1__S010__FIRST_SENTENCE",
      "257__rep1__S005__FIRST_SENTENCE",
      "342__rep1__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "228",
      "257",
      "342"
    ]
  }
}
```

```json
{
  "id": "ROOT020_T6",
  "description": "固定具体对象/关系未闭，反馈后继续真实核验；实际缺口与错误前提均可驱动。",
  "links": [
    {
      "case_id": "257__rep1__S005__FIRST_SENTENCE",
      "local_id": "DUAL_EDITION_RELATION_STAYS_OPEN_DESPITE_BIBLIOGRAPHY_RETURN"
    },
    {
      "case_id": "55__rep3__S001__TERMINAL_DROP_NO_ANCHOR",
      "local_id": "FIXED_FIRST_VOLUME_GAP_REPEATEDLY_REISSUES_REAL_QUERIES"
    },
    {
      "case_id": "228__rep1__S010__FIRST_SENTENCE",
      "local_id": "ASSUMED_BUILDING_AFFILIATION_REMAINS_FIXED_GAP_TARGET"
    },
    {
      "case_id": "342__rep1__S004__FIRST_SENTENCE",
      "local_id": "FIXED_PHYSICAL_OR_RACE_GAP_REISSUES_REAL_WORK"
    },
    {
      "case_id": "353__rep1__S007__FIRST_SENTENCE",
      "local_id": "UNRESOLVED_AUTHOR_BIOGRAPHY_CONTINUES_DISPATCHING_REAL_CHECKS"
    },
    {
      "case_id": "427__rep1__S004__FIRST_SENTENCE",
      "local_id": "FIXED_UNDERWOOD_ATTRIBUTES_CONTINUE_DISPATCHING_CHECKS"
    }
  ],
  "relation": "P1_K3，具体关系/前提分开保留，不以同缺口字样一并认定全部Query无用。",
  "counterexamples": [
    "257新4快速版次解除则无此多轮；342新2对象切换多保unc；新3同完整返回七次与其它不同入口有限核验不是同一个执行原子。"
  ],
  "unresolved": "同关系持续只是可见链，中间失败反馈为何不换前提不能猜内部原因；退出标准仍单独核。",
  "deterministic_counts": {
    "observed_stage_count": 6,
    "different_questions": 6,
    "original_runs": 6,
    "observed_rollouts": 20,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 1,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 20,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 1,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 24,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "228__rep1__S010__FIRST_SENTENCE",
      "257__rep1__S005__FIRST_SENTENCE",
      "342__rep1__S004__FIRST_SENTENCE",
      "353__rep1__S007__FIRST_SENTENCE",
      "427__rep1__S004__FIRST_SENTENCE",
      "55__rep3__S001__TERMINAL_DROP_NO_ANCHOR"
    ],
    "question_ids": [
      "55",
      "228",
      "257",
      "342",
      "353",
      "427"
    ]
  }
}
```

```json
{
  "id": "ROOT020_T7",
  "description": "未完成身份条件时，将局部主题/日期或后代/产品匹配提升为足够接受标准并Formal。",
  "links": [
    {
      "case_id": "353__rep1__S007__FIRST_SENTENCE",
      "local_id": "PARTIAL_THEME_DATE_MATCH_REPLACES_UNRESOLVED_AUTHOR_CRITERIA_AT_FORMAL"
    },
    {
      "case_id": "427__rep1__S004__FIRST_SENTENCE",
      "local_id": "PARTIAL_COMPANY_FEATURES_PROMOTED_TO_SUFFICIENT_CRITERIA"
    }
  ],
  "relation": "N008依原定义增精确成员；同题多个Stage不增独立题数。",
  "counterexamples": [
    "各新2说相关却继续N；55有独立评者签名且附加桥未知，不仅gap+Final硬并。"
  ],
  "unresolved": "本批该叶全W，但不能从候选定义推出必错，保留后续跨题反例。",
  "deterministic_counts": {
    "observed_stage_count": 2,
    "different_questions": 2,
    "original_runs": 2,
    "observed_rollouts": 6,
    "not_observed_rollouts": 2,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 6,
    "not_observed_local_chain_occurrences": 2,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 8,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "353__rep1__S007__FIRST_SENTENCE",
      "427__rep1__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "353",
      "427"
    ]
  }
}
```

```json
{
  "id": "ROOT020_T8",
  "description": "重复返回的一致出现被明确用作身份接受依据，并真实Formal。",
  "links": [
    {
      "case_id": "427__rep1__S004__FIRST_SENTENCE",
      "local_id": "REPEATED_UNDERWOOD_RETRIEVAL_USED_AS_FORMAL_IDENTITY_SUPPORT"
    }
  ],
  "relation": "N007；新1和新4完整末轮明确频率理由，新3可能是内容匹配unc，新2无Formal不命中。",
  "counterexamples": [
    "353新3onlybook/core未必频率理由，不强双归；其它427分支unc不因本次清楚反向修改。"
  ],
  "unresolved": "N007为何相信与N008什么算够可能上下游重叠，保持两字段去重而非同实例相加。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 2,
    "not_observed_rollouts": 1,
    "uncertain_rollouts": 1,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 2,
    "not_observed_local_chain_occurrences": 1,
    "uncertain_local_chain_occurrences": 1,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "427__rep1__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "427"
    ]
  }
}
```

```json
{
  "id": "ROOT020_T9",
  "description": "asof被误成须特定当日仍活跃，实际增加额外检查。",
  "links": [
    {
      "case_id": "191__rep4__S001__FIRST_SENTENCE",
      "local_id": "ASOF_RECAST_AS_EXACT_DATE_ONGOING_ACTIVITY_CHECK"
    }
  ],
  "relation": "N003；新4明确派真Call，新3只文字确认不命中。",
  "counterexamples": [
    "新增日期查仍C且比原便宜，错误子任务不必致错或净增耗。"
  ],
  "unresolved": "不能把所有当期事实核验说不必要，本例是历史资格持续性被额外要求。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 1,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 1,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "191__rep4__S001__FIRST_SENTENCE"
    ],
    "question_ids": [
      "191"
    ]
  }
}
```

```json
{
  "id": "ROOT020_T10",
  "description": "已采用故事在专家补证够答后又真查，完整比较更少与取证更多同时发生。",
  "links": [
    {
      "case_id": "87__rep4__S004__FIRST_SENTENCE",
      "local_id": "KNOWN_STORY_REOPENED_AFTER_EXPERT_ACCEPTANCE"
    }
  ],
  "relation": "P2_R2，补证必要性与已知故事再查分开，原U本身无Call。",
  "counterexamples": [
    "另三无额外故事查；新4仍少生成却多Prompt/Search，不能只报一项节省。"
  ],
  "unresolved": "新增查未独立加强哪些关系需保留未知，不直接叫无收益。",
  "deterministic_counts": {
    "observed_stage_count": 1,
    "different_questions": 1,
    "original_runs": 1,
    "observed_rollouts": 1,
    "not_observed_rollouts": 3,
    "uncertain_rollouts": 0,
    "excluded_rollouts": 0,
    "observed_local_chain_occurrences": 1,
    "not_observed_local_chain_occurrences": 3,
    "uncertain_local_chain_occurrences": 0,
    "excluded_local_chain_occurrences": 0,
    "total_distinct_rollouts_in_test": 4,
    "status_overlap_across_component_links": false,
    "counting_note": "Rollout counts deduplicate case_id and repeat; local-chain occurrences count each explicit component. Statuses across different components need not be exclusive.",
    "observed_cases": [
      "87__rep4__S004__FIRST_SENTENCE"
    ],
    "question_ids": [
      "87"
    ]
  }
}
```


## unresolved

```json
{
  "case_id": "69__rep4__S005__FIRST_SENTENCE",
  "issue": "四支实际补证恢复；生成少但输入全增，局部国籍推断经Return纠正不等独立排除错误候选。"
}
```

```json
{
  "case_id": "78__rep2__S009__TERMINAL_DROP_NO_ANCHOR",
  "issue": "家系仍推断，两支额外查后接受依据不够精确，不能因多查认更充分。"
}
```

```json
{
  "case_id": "87__rep4__S004__FIRST_SENTENCE",
  "issue": "G覆盖后继完整推理，人物故事张力与额外Search保留；比较后置不等全部省。"
}
```

```json
{
  "case_id": "191__rep4__S001__FIRST_SENTENCE",
  "issue": "G首次答案实体，节目奖项错作呈现支持，四C不证发现可省。"
}
```

```json
{
  "case_id": "257__rep1__S005__FIRST_SENTENCE",
  "issue": "G正确出版社；新1情节错接、新3来源归错、新2出版角色延迟但最终C，均不能抹。"
}
```

```json
{
  "case_id": "55__rep3__S001__TERMINAL_DROP_NO_ANCHOR",
  "issue": "空P重启，原工具文本未执行；三C仍卷次/职位未证，新增路径不能归原计划坏判断。"
}
```

```json
{
  "case_id": "228__rep1__S010__FIRST_SENTENCE",
  "issue": "四新缺39643，毕业/合作/捐赠角色错误转化；警告曾出现仍不约束Query，因果归属有限。"
}
```

```json
{
  "case_id": "342__rep1__S004__FIRST_SENTENCE",
  "issue": "CHAR仅区间；Ken恢复与否都可能N，唯一C仍身体未证，正确材料到行动须实查。"
}
```

```json
{
  "case_id": "353__rep1__S007__FIRST_SENTENCE",
  "issue": "没有正确书返回，CHAR区间；三W是接受条件放宽，一N真查不是空转，独立题数不增。"
}
```

```json
{
  "case_id": "427__rep1__S004__FIRST_SENTENCE",
  "issue": "新2真实再次见Guerlain厂区仍旧对象；该文不证全部Gold条件，新4数字假设变事实另开放。"
}
```


## 限制
十Stage/十题/十原轨迹/四十续跑，A/B各五，八首句两末段。342/353/427共十二续跑CHAR保守区间，其余原生精确；G原生/局部重编码来源分列。W/N互变不当成功，原Stage/轨迹/评价只读。支持按题和case/repeat去重，链可重叠。不是独立人工金标准或纯删除因果证明。